# Hostinger Deployment Guide for Raheel Humanize

> **FIX FOR: `ERROR: Entry file not found 105`**
>
> If you saw this error on Hostinger, it happens because Hostinger's Node.js builder expects a compiled `.js` entry file (`server.js`, `app.js`, or `index.js`).
> We have added all three entry files (`server.js`, `app.js`, and `index.js`) to the root directory!
> In Hostinger hPanel under **Application startup file**, simply enter:
> `server.js` (or `app.js` or `index.js`).

---

## Option 1: Hostinger Node.js Application (Recommended for Cloud / Business Hosting)

Hostinger's **hPanel** has a built-in **Node.js** selector allowing you to run full-stack Express + React apps.

### Step 1: Upload Your Files
1. In Hostinger **hPanel**, go to **Websites** → select your domain → **File Manager** (or connect via Git/FTP).
2. Upload the project files to your domain directory (e.g. `/home/u123456789/domains/yourdomain.com/nodejs` or `public_html`).
   > *Tip: You do not need to upload `node_modules`. They will be installed directly on Hostinger.*

### Step 2: Configure Node.js in Hostinger hPanel
1. In hPanel, go to **Advanced** → **Node.js**.
2. Click **Create Application** and configure:
   - **Node.js version:** `18.x` or `20.x`
   - **Application mode:** `Production`
   - **Application root:** `/` (or directory where your files are uploaded)
   - **Application URL:** your domain name
   - **Application startup file:** `server.js` (or `app.js` or `index.js`)
3. Click **Create**.

### Step 3: Install Dependencies and Build
1. In the Node.js application management page, open the **Terminal / Console** or click **Run NPM Install**.
2. Run the build command:
   ```bash
   npm install
   npm run build
   ```
3. Add your Environment Variables in the **Environment variables** section:
   - `GEMINI_API_KEY`: `your_gemini_api_key_here`
   - `NODE_ENV`: `production`

### Step 4: Start Application
- Click **Start / Restart Application** in hPanel.
- Your app is now live with 0.0% AI text humanization, PDF/DOCX downloads, and payment receiving!

---

## Option 2: Hostinger Static Web Hosting (`public_html` via `.htaccess`)

If you are using Hostinger Shared Hosting (Apache / LiteSpeed):
1. Run `npm run build` locally.
2. Open the generated `dist/` directory.
3. Upload all files from `dist/` into your Hostinger `public_html/` folder.
4. Ensure the `.htaccess` file (included in this repository) is placed in `public_html/`.
   - The `.htaccess` file automatically routes all virtual React routes (`/`, `/detector`, `/auth`) to `index.html` with zero 404 errors.

---

## Option 3: Hostinger VPS Hosting (Ubuntu + Nginx + PM2)

If you have a Hostinger VPS:
1. SSH into your VPS:
   ```bash
   ssh root@your_vps_ip
   ```
2. Install Node.js (v20):
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
   sudo apt-get install -y nodejs git
   ```
3. Clone or upload your project:
   ```bash
   cd /var/www/raheel-humanize
   npm install
   npm run build
   ```
4. Start with PM2 using the included `ecosystem.config.cjs`:
   ```bash
   npm install -g pm2
   pm2 start ecosystem.config.cjs
   pm2 save
   pm2 startup
   ```
5. Configure Nginx Reverse Proxy (`/etc/nginx/sites-available/default`):
   ```nginx
   server {
       listen 80;
       server_name yourdomain.com www.yourdomain.com;

       location / {
           proxy_pass http://127.0.0.1:3000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```
6. Restart Nginx:
   ```bash
   sudo systemctl restart nginx
   ```
