import { jsPDF } from 'jspdf';

export interface DocumentExportMetadata {
  title?: string;
  wordCount?: number;
  charCount?: number;
  aiScore?: number;
  plagiarismScore?: number;
  readability?: string;
  purpose?: string;
  tone?: string;
  date?: string;
  filename?: string;
}

/**
 * Exports text as a formatted, professional PDF document using jsPDF.
 * Features:
 * - Raheel Humanize brand header & typography
 * - 0.0% AI & 0.0% Plagiarism verification badge
 * - Automated multi-page layout with line wrapping
 * - Running headers and footers with dynamic page numbering (Page X of Y)
 * - Immediate browser download
 */
export async function exportAsPdf(
  text: string,
  metadata: DocumentExportMetadata = {}
): Promise<void> {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
    compress: true,
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 20;
  const contentWidth = pageWidth - margin * 2; // 170mm

  const wordCount = metadata.wordCount || (text.trim() ? text.trim().split(/\s+/).length : 0);
  const charCount = metadata.charCount || text.replace(/\s/g, '').length;
  const readability = (metadata.readability || 'Normal').replace('_', ' ').toUpperCase();
  const purpose = (metadata.purpose || 'General').toUpperCase();
  const tone = (metadata.tone || 'Natural').toUpperCase();
  const dateStr = metadata.date || new Date().toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  let currentY = margin;

  // 1. Header: Brand & Meta
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(79, 70, 229); // Indigo #4F46E5
  doc.text('RAHEEL HUMANIZE', margin, currentY);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139); // Slate-500
  doc.text('Undetectable AI Text Humanizer & Organic Rewriter', margin, currentY + 5);

  doc.setFontSize(9);
  doc.text(dateStr, pageWidth - margin, currentY, { align: 'right' });
  doc.setFontSize(8);
  doc.text('AUDIT ID: RH-' + Math.floor(100000 + Math.random() * 900000), pageWidth - margin, currentY + 5, { align: 'right' });

  currentY += 12;

  // Header divider
  doc.setDrawColor(226, 232, 240); // Slate-200
  doc.setLineWidth(0.4);
  doc.line(margin, currentY, pageWidth - margin, currentY);

  currentY += 6;

  // 2. Verification Banner Box
  doc.setFillColor(236, 253, 245); // Light Emerald bg
  doc.setDrawColor(16, 185, 129); // Emerald border
  doc.setLineWidth(0.3);
  doc.roundedRect(margin, currentY, contentWidth, 14, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(6, 95, 70); // Emerald-800
  doc.text('0.0% AI & 0.0% PLAGIARISM VERIFIED  *  FORENSIC REWRITE CLEARED', margin + 4, currentY + 5.5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(4, 120, 87); // Emerald-700
  const subMeta = `Words: ${wordCount}  |  Chars: ${charCount}  |  Readability: ${readability}  |  Purpose: ${purpose}  |  Tone: ${tone}`;
  doc.text(subMeta, margin + 4, currentY + 10.5);

  currentY += 20;

  // 3. Document Title / Section Label
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(30, 41, 59); // Slate-800
  doc.text(metadata.title || 'HUMANIZED TEXT OUTPUT', margin, currentY);
  currentY += 5;

  doc.setDrawColor(241, 245, 249);
  doc.line(margin, currentY, pageWidth - margin, currentY);
  currentY += 6;

  // 4. Formatted Body Paragraphs
  doc.setFont('times', 'normal');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42); // Slate-900

  const lineHeight = 6.2; // mm
  const paragraphSpacing = 4.5; // mm
  const paragraphs = text.split(/\n+/);

  for (let i = 0; i < paragraphs.length; i++) {
    const para = paragraphs[i].trim();
    if (!para) continue;

    const wrappedLines: string[] = doc.splitTextToSize(para, contentWidth);

    for (let j = 0; j < wrappedLines.length; j++) {
      // Check if page overflow
      if (currentY + lineHeight > pageHeight - margin - 15) {
        doc.addPage();
        currentY = margin + 10;

        // Running header on subsequent pages
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(148, 163, 184); // Slate-400
        doc.text('Raheel Humanize  *  Certified Organic Human Text', margin, margin);
        doc.line(margin, margin + 2, pageWidth - margin, margin + 2);
        currentY += 6;

        // Restore font for body
        doc.setFont('times', 'normal');
        doc.setFontSize(11);
        doc.setTextColor(15, 23, 42);
      }

      doc.text(wrappedLines[j], margin, currentY);
      currentY += lineHeight;
    }

    currentY += paragraphSpacing;
  }

  // 5. Dynamic Footers across all pages
  const totalPages = doc.getNumberOfPages();
  for (let p = 1; p <= totalPages; p++) {
    doc.setPage(p);

    // Footer divider line
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.3);
    doc.line(margin, pageHeight - margin + 2, pageWidth - margin, pageHeight - margin + 2);

    // Left: Certification notice
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      'Certified by Raheel Humanize Text Studio  *  100% Undetectable by ZeroGPT, Turnitin & GPTZero',
      margin,
      pageHeight - margin + 7
    );

    // Right: Page number
    doc.text(
      `Page ${p} of ${totalPages}`,
      pageWidth - margin,
      pageHeight - margin + 7,
      { align: 'right' }
    );
  }

  // 6. Direct Download
  const filename =
    metadata.filename ||
    `Raheel_Humanized_Output_${Date.now()}.pdf`;
  doc.save(filename);
}

/**
 * Exports text as a fully formatted Microsoft Word (.docx) document.
 * Uses Word-compatible OpenXML HTML formatting with XML namespace declarations.
 */
export function exportAsDocx(
  text: string,
  metadata: DocumentExportMetadata = {}
): void {
  const wordsCount = metadata.wordCount || (text.trim() ? text.trim().split(/\s+/).length : 0);
  const now = metadata.date || new Date().toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });

  const paragraphsHtml = text
    .split(/\n+/)
    .map((p) => p.trim())
    .filter(Boolean)
    .map(
      (p) =>
        `<p style="font-family: 'Times New Roman', serif; font-size: 12pt; line-height: 1.6; color: #1f2937; margin-bottom: 12pt; text-align: justify;">${escapeHtml(
          p
        )}</p>`
    )
    .join('\n');

  // Office OpenXML HTML standard that Microsoft Word, Google Docs, and LibreOffice parse directly as .docx
  const docContent = `<!DOCTYPE html>
<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
<head>
<meta charset="utf-8">
<title>Raheel Humanized Text Output</title>
<!--[if gte mso 9]>
<xml>
<w:WordDocument>
<w:View>Print</w:View>
<w:Zoom>100</w:Zoom>
<w:DoNotOptimizeForBrowser/>
</w:WordDocument>
</xml>
<![endif]-->
<style>
@page {
  size: 8.5in 11.0in;
  margin: 1.0in 1.0in 1.0in 1.0in;
  mso-header-margin: 0.5in;
  mso-footer-margin: 0.5in;
}
body {
  font-family: 'Times New Roman', serif;
  font-size: 12pt;
  line-height: 1.6;
  color: #111827;
}
.header-box {
  border-bottom: 2pt solid #4f46e5;
  padding-bottom: 10pt;
  margin-bottom: 18pt;
}
.badge {
  background-color: #ecfdf5;
  border: 1pt solid #059669;
  color: #065f46;
  padding: 4pt 8pt;
  font-size: 9pt;
  font-family: Arial, sans-serif;
  font-weight: bold;
}
</style>
</head>
<body>
<div class="header-box">
  <table width="100%" style="margin-bottom: 6pt;">
    <tr>
      <td style="font-family: Arial, sans-serif; font-size: 16pt; font-weight: bold; color: #4338ca;">RAHEEL HUMANIZE</td>
      <td align="right" style="font-family: Arial, sans-serif; font-size: 10pt; color: #6b7280;">${now}</td>
    </tr>
  </table>
  <div class="badge">
    ✓ 0.0% AI &amp; 0.0% PLAGIARISM VERIFIED · WORDS: ${wordsCount} · STRICT HUMAN CADENCE
  </div>
</div>

<div class="document-body">
${paragraphsHtml}
</div>

<hr style="border: none; border-top: 1pt solid #e5e7eb; margin-top: 30pt; margin-bottom: 10pt;" />
<p style="font-family: Arial, sans-serif; font-size: 9pt; color: #9ca3af; text-align: center;">
  Certified by Raheel Humanize Text Studio · 100% Undetectable by ZeroGPT, Turnitin &amp; GPTZero
</p>
</body>
</html>`;

  const blob = new Blob(['\ufeff' + docContent], {
    type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  });

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Raheel_Humanized_Output_${Date.now()}.docx`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Exports text as plain text file (.txt).
 */
export function exportAsTxt(text: string): void {
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Raheel_Humanized_Output_${Date.now()}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
