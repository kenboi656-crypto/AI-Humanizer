import { User } from 'firebase/auth';
import {
  db,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  handleFirestoreError,
  OperationType,
} from '../firebase/firestore';

export interface UserProfileData {
  uid: string;
  id?: string; // alias for backwards compatibility
  name: string;
  email: string;
  photoURL: string | null;
  role: 'user' | 'admin';
  plan: 'free' | 'pro' | 'enterprise' | 'pakistan_lifetime';
  emailVerified: boolean;
  createdAt: string;
  updatedAt: string;
  phone?: string;
  countryCode?: string;
  isPakistani?: boolean;
  billingCycle?: 'monthly' | 'annually';
  hasPaid?: boolean;
  humanizationsUsed?: number;
  humanizedWordsCount?: number;
}

const COLLECTION_NAME = 'users';

/**
 * Fetches user profile document from Firestore.
 */
export async function getUserProfile(uid: string): Promise<UserProfileData | null> {
  const userRef = doc(db, COLLECTION_NAME, uid);
  try {
    const snap = await getDoc(userRef);
    if (!snap.exists()) return null;
    const data = snap.data() as UserProfileData;
    return {
      ...data,
      uid,
      id: uid,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `${COLLECTION_NAME}/${uid}`);
  }
}

/**
 * Creates a brand-new user profile in Firestore after registration.
 * Guarantees default role: "user" and prevents frontend privilege escalation.
 */
export async function createUserProfile(
  user: User,
  additionalData: Partial<UserProfileData> = {}
): Promise<UserProfileData> {
  const uid = user.uid;
  const userRef = doc(db, COLLECTION_NAME, uid);

  const isPak =
    additionalData.countryCode === '+92' ||
    (user.phoneNumber || '').includes('+92') ||
    additionalData.isPakistani === true;

  const timestamp = new Date().toISOString();

  // Strict role safety: users can never create themselves as admin
  const newProfile: UserProfileData = {
    uid,
    id: uid,
    name: additionalData.name?.trim() || user.displayName || user.email?.split('@')[0] || 'User',
    email: user.email || additionalData.email || '',
    photoURL: user.photoURL || null,
    role: 'user', // strictly forced default role
    plan: isPak ? 'pakistan_lifetime' : 'free',
    emailVerified: user.emailVerified,
    createdAt: timestamp,
    updatedAt: timestamp,
    phone: additionalData.phone || user.phoneNumber || '',
    countryCode: additionalData.countryCode || (isPak ? '+92' : '+1'),
    isPakistani: isPak,
    hasPaid: isPak,
    humanizationsUsed: 0,
    humanizedWordsCount: 0,
  };

  try {
    await setDoc(userRef, newProfile);
    return newProfile;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `${COLLECTION_NAME}/${uid}`);
  }
}

/**
 * Handles Google sign-in profile resolution:
 * Checks if profile exists. If missing, creates initial profile.
 * If present, updates emailVerified / photoURL without overwriting existing data.
 */
export async function syncGoogleUserProfile(user: User): Promise<UserProfileData> {
  const uid = user.uid;
  const existing = await getUserProfile(uid);

  if (existing) {
    // Only update non-destructive fields
    const updates: Partial<UserProfileData> = {
      emailVerified: user.emailVerified,
      updatedAt: new Date().toISOString(),
    };
    if (user.photoURL && !existing.photoURL) {
      updates.photoURL = user.photoURL;
    }
    if (user.displayName && (!existing.name || existing.name === 'User')) {
      updates.name = user.displayName;
    }

    try {
      await updateDoc(doc(db, COLLECTION_NAME, uid), updates);
      return { ...existing, ...updates };
    } catch (err) {
      console.warn('Non-fatal Google profile sync update warning:', err);
      return existing;
    }
  }

  // Create brand new profile for first-time Google sign-in
  return createUserProfile(user, {
    name: user.displayName || undefined,
    photoURL: user.photoURL || undefined,
  });
}

/**
 * Updates allowed user profile fields.
 * Explicitly strips any attempts to modify 'role' from the frontend.
 */
export async function updateUserProfile(
  uid: string,
  updates: Partial<UserProfileData>
): Promise<void> {
  const safeUpdates = { ...updates };
  // Never allow client to escalate role
  delete safeUpdates.role;
  delete safeUpdates.uid;
  delete safeUpdates.id;
  delete safeUpdates.createdAt;

  safeUpdates.updatedAt = new Date().toISOString();

  const userRef = doc(db, COLLECTION_NAME, uid);
  try {
    await updateDoc(userRef, safeUpdates);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${COLLECTION_NAME}/${uid}`);
  }
}
