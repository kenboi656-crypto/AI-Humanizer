export { app, auth, db, googleProvider } from '../firebase/config';
export {
  handleFirestoreError,
  OperationType,
  serverTimestamp,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  query,
  where,
  getDocs,
} from '../firebase/firestore';
export type { FirestoreErrorInfo } from '../firebase/firestore';
