import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  sendPasswordResetEmail,
  sendEmailVerification,
  signOut,
  onAuthStateChanged,
  updateProfile as updateAuthProfile,
  reload,
  User,
  NextOrObserver,
  Unsubscribe,
} from 'firebase/auth';
import { auth, googleProvider } from './config';

/**
 * Registers a new user with Firebase Authentication and sends email verification.
 */
export async function signUpWithEmail(
  email: string,
  pass: string,
  displayName?: string
): Promise<User> {
  const userCredential = await createUserWithEmailAndPassword(auth, email.trim(), pass);
  const user = userCredential.user;

  if (displayName?.trim()) {
    try {
      await updateAuthProfile(user, { displayName: displayName.trim() });
    } catch (err) {
      console.warn('Failed to update display name on user credential:', err);
    }
  }

  // Send verification email
  try {
    await sendEmailVerification(user);
  } catch (err) {
    console.warn('Error sending initial email verification:', err);
  }

  return user;
}

/**
 * Logs in user using email and password.
 */
export async function loginWithEmail(email: string, pass: string): Promise<User> {
  const userCredential = await signInWithEmailAndPassword(auth, email.trim(), pass);
  return userCredential.user;
}

/**
 * Signs in using Google via popup.
 */
export async function loginWithGoogle(): Promise<User> {
  const result = await signInWithPopup(auth, googleProvider);
  return result.user;
}

/**
 * Dispatches password reset email to user's address.
 */
export async function sendResetEmail(email: string): Promise<void> {
  await sendPasswordResetEmail(auth, email.trim());
}

/**
 * Resends verification email to the current authenticated user.
 */
export async function sendVerificationEmail(user: User): Promise<void> {
  await sendEmailVerification(user);
}

/**
 * Signs out current user from Firebase Authentication.
 */
export async function logoutUser(): Promise<void> {
  await signOut(auth);
}

/**
 * Reloads user profile from Firebase to check updated emailVerified status.
 */
export async function reloadAuthUser(user: User): Promise<User> {
  await reload(user);
  return auth.currentUser || user;
}

/**
 * Centralized observer for auth state changes.
 */
export function onAuthChange(observer: NextOrObserver<User | null>): Unsubscribe {
  return onAuthStateChanged(auth, observer);
}
