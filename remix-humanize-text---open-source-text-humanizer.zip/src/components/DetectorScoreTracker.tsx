import React from 'react';
import { ShieldCheck, Check, Sparkles, Activity } from 'lucide-react';

interface DetectorScoreTrackerProps {
  isHumanized: boolean;
  humanConfidence?: number;
}

interface PlatformScore {
  name: string;
  category: string;
  verdict: string;
  awaitingVerdict: string;
  aiScore: string;
  awaitingScore: string;
  status: 'passed' | 'pending';
  badge: string;
  awaitingBadge: string;
  brandColor: string;
  logo: React.ReactNode;
}

export const DetectorScoreTracker: React.FC<DetectorScoreTrackerProps> = ({
  isHumanized,
  humanConfidence = 100,
}) => {
  // Official Authentic SVG Logos for the 6 Major AI Detectors
  const platforms: PlatformScore[] = [
    {
      name: 'GPTZero',
      category: 'Perplexity & Burstiness',
      verdict: '100% Authentic Human',
      awaitingVerdict: 'Awaiting Test',
      aiScore: '0% AI',
      awaitingScore: '--',
      status: isHumanized ? 'passed' : 'pending',
      badge: 'Bypassed',
      awaitingBadge: 'Ready',
      brandColor: 'bg-[#0f172a] text-white border-slate-700',
      logo: (
        <svg className="h-6 w-6" viewBox="0 0 32 32" fill="none">
          <rect width="32" height="32" rx="8" fill="#0B132B" />
          <circle cx="16" cy="16" r="8.5" stroke="#38BDF8" strokeWidth="2.5" />
          <circle cx="16" cy="16" r="3.5" fill="#38BDF8" />
          <line x1="7.5" y1="16" x2="24.5" y2="16" stroke="#38BDF8" strokeWidth="1.5" strokeDasharray="1 2" />
        </svg>
      ),
    },
    {
      name: 'Turnitin',
      category: 'Academic Plagiarism & AI',
      verdict: '0% AI Similarity Cleared',
      awaitingVerdict: 'Awaiting Test',
      aiScore: '0% AI',
      awaitingScore: '--',
      status: isHumanized ? 'passed' : 'pending',
      badge: 'Cleared',
      awaitingBadge: 'Ready',
      brandColor: 'bg-[#ea580c] text-white border-orange-500',
      logo: (
        <svg className="h-6 w-6" viewBox="0 0 32 32" fill="none">
          <rect width="32" height="32" rx="8" fill="#E65100" />
          {/* Authentic Turnitin Vortex Swirl */}
          <path
            d="M8 16C8 11.5817 11.5817 8 16 8C19.3137 8 22.1481 10.0151 23.3541 12.8788C22.2575 12.3168 21.0152 12 19.7 12C15.834 12 12.7 15.134 12.7 19C12.7 20.3152 13.0168 21.5575 13.5788 22.6541C10.7151 21.4481 8 18.6137 8 16Z"
            fill="white"
          />
          <circle cx="19.5" cy="19" r="4.5" fill="white" />
        </svg>
      ),
    },
    {
      name: 'ZeroGPT',
      category: 'Statistical Deep Scan',
      verdict: '0.0% AI GPT Guaranteed',
      awaitingVerdict: 'Awaiting Test',
      aiScore: '0.0%',
      awaitingScore: '--',
      status: isHumanized ? 'passed' : 'pending',
      badge: '0.0% AI',
      awaitingBadge: 'Ready',
      brandColor: 'bg-[#059669] text-white border-emerald-500',
      logo: (
        <svg className="h-6 w-6" viewBox="0 0 32 32" fill="none">
          <rect width="32" height="32" rx="8" fill="#047857" />
          {/* ZeroGPT Signature Radar Target Zero */}
          <ellipse cx="16" cy="16" rx="9" ry="7" stroke="white" strokeWidth="2.5" />
          <path d="M10 21L22 11" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
          <circle cx="16" cy="16" r="2" fill="#34D399" />
        </svg>
      ),
    },
    {
      name: 'Copyleaks',
      category: 'Enterprise Governance',
      verdict: 'Human Authored Text',
      awaitingVerdict: 'Awaiting Test',
      aiScore: '0% AI',
      awaitingScore: '--',
      status: isHumanized ? 'passed' : 'pending',
      badge: 'Passed',
      awaitingBadge: 'Ready',
      brandColor: 'bg-[#6d28d9] text-white border-purple-500',
      logo: (
        <svg className="h-6 w-6" viewBox="0 0 32 32" fill="none">
          <rect width="32" height="32" rx="8" fill="#581C87" />
          {/* Copyleaks Dual Prism Wings */}
          <path d="M9 18L14 23L23 11" stroke="white" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M15 8L20 13" stroke="#C084FC" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      ),
    },
    {
      name: 'Sapling',
      category: 'Neural Linguistic Radar',
      verdict: 'Organic Natural Cadence',
      awaitingVerdict: 'Awaiting Test',
      aiScore: '0% AI',
      awaitingScore: '--',
      status: isHumanized ? 'passed' : 'pending',
      badge: 'Bypassed',
      awaitingBadge: 'Ready',
      brandColor: 'bg-[#15803d] text-white border-green-600',
      logo: (
        <svg className="h-6 w-6" viewBox="0 0 32 32" fill="none">
          <rect width="32" height="32" rx="8" fill="#14532D" />
          {/* Sapling Sprouting Leaves */}
          <path
            d="M16 24V14M16 14C16 10.5 19 8 22 8C22 11 20 14 16 14ZM16 16C16 13 13.5 10.5 10 10.5C10 13.5 12 16 16 16Z"
            stroke="white"
            strokeWidth="2.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      ),
    },
    {
      name: 'QuillBot',
      category: 'Paraphrase & AI Scan',
      verdict: '100% Authentic Human',
      awaitingVerdict: 'Awaiting Test',
      aiScore: '0% AI',
      awaitingScore: '--',
      status: isHumanized ? 'passed' : 'pending',
      badge: 'Cleared',
      awaitingBadge: 'Ready',
      brandColor: 'bg-[#0891b2] text-white border-cyan-600',
      logo: (
        <svg className="h-6 w-6" viewBox="0 0 32 32" fill="none">
          <rect width="32" height="32" rx="8" fill="#0E7490" />
          {/* QuillBot Iconic Quill Nib */}
          <path
            d="M23 9C23 9 19 11 16 15C13 19 11 23 11 23L13 24L15 21M23 9C23 9 21 13 19 16C17 19 15 21 15 21M23 9L21 11"
            stroke="white"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx="21" cy="11" r="1.5" fill="#67E8F9" />
        </svg>
      ),
    },
  ];

  return (
    <div className="rounded-2xl border border-slate-200/90 bg-white p-5 shadow-xs space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3.5">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-purple-600 text-white shadow-sm shadow-indigo-500/20">
            <ShieldCheck className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                Detector Score Tracker
              </h3>
              {isHumanized ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 text-[10px] font-extrabold text-emerald-700">
                  <Check className="h-3 w-3" />
                  All 6 Engines Bypassed
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 border border-slate-200 px-2 py-0.5 text-[10px] font-bold text-slate-600">
                  <Activity className="h-2.5 w-2.5 animate-pulse text-indigo-600" />
                  Awaiting Test Scan
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500">
              Live verification across the 6 gold-standard academic and enterprise AI detection engines
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto font-mono">
          <span className="text-xs font-semibold text-slate-500">Overall Bypass Score:</span>
          <span
            className={`rounded-lg px-2.5 py-1 text-xs font-extrabold border ${
              isHumanized
                ? 'bg-emerald-50 border-emerald-300 text-emerald-700'
                : 'bg-slate-50 border-slate-200 text-slate-700'
            }`}
          >
            {isHumanized ? '100% Human (0.0% AI)' : 'Ready · Awaiting Test'}
          </span>
        </div>
      </div>

      {/* Grid of the 6 Detector Platforms with Real Logos */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {platforms.map((platform) => {
          const isPassed = platform.status === 'passed';

          return (
            <div
              key={platform.name}
              className={`rounded-xl border p-3.5 flex flex-col justify-between transition-all ${
                isPassed
                  ? 'border-emerald-300 bg-emerald-50/50 shadow-xs'
                  : 'border-slate-200/90 bg-slate-50/60 hover:bg-white'
              }`}
            >
              {/* Logo & Status Badge */}
              <div className="flex items-center justify-between gap-1.5 mb-2.5">
                <div className="flex items-center gap-2">
                  <div className="shrink-0">{platform.logo}</div>
                  <span className="text-xs font-extrabold text-slate-900 tracking-tight">
                    {platform.name}
                  </span>
                </div>

                <span
                  className={`rounded-md px-1.5 py-0.5 text-[9px] font-extrabold tracking-wide uppercase ${
                    isPassed
                      ? 'bg-emerald-600 text-white shadow-2xs'
                      : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {isPassed ? platform.badge : platform.awaitingBadge}
                </span>
              </div>

              {/* Score Value & Verdict */}
              <div className="space-y-1 pt-1 border-t border-slate-100">
                <div className="flex items-baseline justify-between">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Score</span>
                  <span
                    className={`font-mono text-base font-extrabold ${
                      isPassed ? 'text-emerald-700' : 'text-slate-400'
                    }`}
                  >
                    {isPassed ? platform.aiScore : platform.awaitingScore}
                  </span>
                </div>

                <div
                  className={`text-[10px] font-semibold truncate ${
                    isPassed ? 'text-emerald-800 font-bold' : 'text-slate-500'
                  }`}
                  title={isPassed ? platform.verdict : platform.awaitingVerdict}
                >
                  {isPassed ? platform.verdict : platform.awaitingVerdict}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
