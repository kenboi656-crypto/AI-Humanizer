import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Loader2, ShieldCheck, Lock } from 'lucide-react';

interface ProtectedRouteProps {
  children: React.ReactNode;
  fallbackToLogin?: () => void;
  requireVerification?: boolean;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  fallbackToLogin,
  requireVerification = false,
}) => {
  const { user, isAuthenticated, loading, isEmailVerified } = useAuth();

  // 1. Loading State: Resolving Firebase Auth state, preventing race conditions & flickering
  if (loading) {
    return (
      <div className="min-h-[500px] flex flex-col items-center justify-center p-8 text-center space-y-4 animate-in fade-in duration-200">
        <div className="relative flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600 border border-indigo-100 shadow-xs">
          <Loader2 className="h-7 w-7 animate-spin" />
        </div>
        <div className="space-y-1">
          <h3 className="text-base font-bold text-slate-800">Verifying Security Session</h3>
          <p className="text-xs text-slate-500 max-w-xs">
            Connecting to Firebase Authentication and resolving your account profile...
          </p>
        </div>
      </div>
    );
  }

  // 2. Unauthenticated: Prompt login or invoke fallback callback
  if (!isAuthenticated || !user) {
    return (
      <div className="min-h-[400px] flex flex-col items-center justify-center p-8 text-center space-y-4 max-w-md mx-auto">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 border border-rose-200 shadow-xs">
          <Lock className="h-7 w-7" />
        </div>
        <div className="space-y-1.5">
          <h3 className="text-lg font-extrabold text-slate-900">Protected Account Access</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Please sign in to access your account dashboard, unlimited humanizer parameters, and document archives.
          </p>
        </div>

        {fallbackToLogin && (
          <button
            type="button"
            onClick={fallbackToLogin}
            className="flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-6 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-indigo-700 transition-colors cursor-pointer"
          >
            <span>Sign In to Continue</span>
          </button>
        )}
      </div>
    );
  }

  // 3. Email verification requirement check (if strictly required)
  if (requireVerification && !isEmailVerified) {
    return (
      <div className="min-h-[400px] flex flex-col items-center justify-center p-8 text-center space-y-4 max-w-md mx-auto">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-50 text-amber-600 border border-amber-200 shadow-xs">
          <ShieldCheck className="h-7 w-7" />
        </div>
        <div className="space-y-1.5">
          <h3 className="text-lg font-extrabold text-slate-900">Email Verification Required</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Please verify your email address before accessing this protected resource.
          </p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};
