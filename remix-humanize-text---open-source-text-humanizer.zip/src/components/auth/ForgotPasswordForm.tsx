import React, { useState, useEffect } from 'react';
import { Mail, ArrowLeft, ArrowRight, CheckCircle2, AlertCircle, Loader2, RefreshCw } from 'lucide-react';
import { formatAuthError } from '../../utils/authErrors';

interface ForgotPasswordFormProps {
  onSendResetEmail: (email: string) => Promise<void>;
  onSwitchToLogin: () => void;
}

export const ForgotPasswordForm: React.FC<ForgotPasswordFormProps> = ({
  onSendResetEmail,
  onSwitchToLogin,
}) => {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cooldown, setCooldown] = useState(0);

  // Cooldown countdown timer
  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setInterval(() => {
      setCooldown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [cooldown]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading || cooldown > 0) return;

    const trimmedEmail = email.trim().toLowerCase();
    if (!trimmedEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setError('Please enter a valid email address.');
      return;
    }

    setError(null);
    setIsLoading(true);

    try {
      await onSendResetEmail(trimmedEmail);
      setIsSuccess(true);
      setCooldown(60); // 60s cooldown against rapid requests
    } catch (err: any) {
      // Avoid revealing account-existence by showing standard helpful response unless network fails
      const formatted = formatAuthError(err);
      if (err?.code === 'auth/network-request-failed') {
        setError(formatted);
      } else {
        // Safe success screen or user guidance
        setIsSuccess(true);
        setCooldown(60);
      }
    } finally {
      setIsLoading(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="space-y-5 text-center animate-in fade-in duration-200">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-600 border border-emerald-200 shadow-xs">
          <CheckCircle2 className="h-7 w-7" />
        </div>

        <div className="space-y-1.5">
          <h3 className="text-lg font-extrabold text-slate-900">Check Your Email</h3>
          <p className="text-xs text-slate-600 max-w-sm mx-auto leading-relaxed">
            If an account matches <strong className="text-slate-800">{email}</strong>, we have dispatched a password reset link. Please check your inbox and spam folder.
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-500 text-left space-y-1">
          <p className="font-semibold text-slate-700">Didn't receive an email?</p>
          <ul className="list-disc pl-4 space-y-0.5 text-[11px]">
            <li>Ensure the email address is spelled correctly.</li>
            <li>Check your spam or junk mail folder.</li>
            <li>Wait a couple minutes for delivery.</li>
          </ul>
        </div>

        <div className="space-y-2 pt-2">
          {cooldown > 0 ? (
            <p className="text-xs text-slate-400 font-medium">
              You can request another link in <span className="font-mono text-indigo-600 font-bold">{cooldown}s</span>
            </p>
          ) : (
            <button
              type="button"
              onClick={handleSubmit}
              disabled={isLoading}
              className="flex items-center justify-center gap-1.5 mx-auto text-xs font-bold text-indigo-600 hover:text-indigo-700 cursor-pointer"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              <span>Resend Reset Email</span>
            </button>
          )}

          <button
            type="button"
            onClick={onSwitchToLogin}
            className="w-full flex items-center justify-center gap-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 py-2.5 px-4 text-xs font-bold transition-colors cursor-pointer"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span>Return to Sign In</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="space-y-1">
        <h3 className="text-base font-extrabold text-slate-900">Reset Your Password</h3>
        <p className="text-xs text-slate-500 leading-relaxed">
          Enter the email associated with your account, and we'll send you a secure link to reset your credentials.
        </p>
      </div>

      {error && (
        <div
          role="alert"
          aria-live="assertive"
          className="flex items-start gap-2.5 rounded-xl border border-rose-200 bg-rose-50/80 p-3 text-xs text-rose-800 animate-in fade-in duration-150"
        >
          <AlertCircle className="h-4 w-4 text-rose-600 shrink-0 mt-0.5" />
          <p className="leading-relaxed font-medium">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} noValidate className="space-y-4">
        <div>
          <label htmlFor="reset-email" className="block text-xs font-bold text-slate-700 mb-1.5">
            Account Email
          </label>
          <div className="relative">
            <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
            <input
              id="reset-email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (error) setError(null);
              }}
              placeholder="name@example.com"
              disabled={isLoading}
              className="w-full rounded-xl border border-slate-200 bg-slate-50/60 pl-10 pr-3.5 py-2.5 text-sm text-slate-800 placeholder-slate-400 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/10 transition-colors disabled:opacity-50"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={isLoading || cooldown > 0 || !email.trim()}
          className="w-full flex items-center justify-center gap-2 rounded-xl bg-indigo-600 py-3 px-4 text-sm font-bold text-white shadow-xs hover:bg-indigo-700 active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed transition-all cursor-pointer"
        >
          {isLoading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Sending Reset Instructions...</span>
            </>
          ) : (
            <>
              <span>Send Password Reset Link</span>
              <ArrowRight className="h-4 w-4" />
            </>
          )}
        </button>
      </form>

      <div className="text-center pt-2 border-t border-slate-100">
        <button
          type="button"
          onClick={onSwitchToLogin}
          disabled={isLoading}
          className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-indigo-600 transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Back to Sign In</span>
        </button>
      </div>
    </div>
  );
};
