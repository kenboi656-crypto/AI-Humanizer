import React, { useState, useEffect } from 'react';
import { Mail, CheckCircle2, RefreshCw, LogOut, ArrowRight, Loader2, AlertCircle } from 'lucide-react';
import { formatAuthError } from '../../utils/authErrors';

interface EmailVerificationProps {
  email: string;
  isVerified: boolean;
  onResend: () => Promise<void>;
  onCheckStatus: () => Promise<boolean>;
  onLogout: () => void;
  onProceed?: () => void;
}

export const EmailVerification: React.FC<EmailVerificationProps> = ({
  email,
  isVerified,
  onResend,
  onCheckStatus,
  onLogout,
  onProceed,
}) => {
  const [cooldown, setCooldown] = useState(0);
  const [isResending, setIsResending] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // 60-second cooldown timer
  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setInterval(() => {
      setCooldown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [cooldown]);

  const handleResend = async () => {
    if (cooldown > 0 || isResending) return;
    setError(null);
    setIsResending(true);
    try {
      await onResend();
      setCooldown(60);
      setNotice(`A new verification email has been dispatched to ${email}`);
    } catch (err: any) {
      setError(formatAuthError(err));
    } finally {
      setIsResending(false);
    }
  };

  const handleCheckStatus = async () => {
    if (isChecking) return;
    setError(null);
    setIsChecking(true);
    try {
      const verified = await onCheckStatus();
      if (verified) {
        setNotice('Email successfully verified! You may now proceed.');
        if (onProceed) onProceed();
      } else {
        setNotice('Email not yet verified. Please click the link in your email first.');
      }
    } catch (err: any) {
      setError(formatAuthError(err));
    } finally {
      setIsChecking(false);
    }
  };

  if (isVerified) {
    return (
      <div className="space-y-5 text-center animate-in fade-in duration-200">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-600 border border-emerald-200 shadow-xs">
          <CheckCircle2 className="h-7 w-7" />
        </div>
        <div className="space-y-1.5">
          <h3 className="text-lg font-extrabold text-slate-900">Email Verified!</h3>
          <p className="text-xs text-slate-600 max-w-sm mx-auto leading-relaxed">
            Your email <strong className="text-slate-800">{email}</strong> has been confirmed. Your account is active with full access.
          </p>
        </div>

        {onProceed && (
          <button
            type="button"
            onClick={onProceed}
            className="w-full flex items-center justify-center gap-2 rounded-xl bg-indigo-600 py-3 px-4 text-sm font-bold text-white shadow-xs hover:bg-indigo-700 transition-all cursor-pointer"
          >
            <span>Continue to Dashboard</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-5 text-center animate-in fade-in duration-200">
      <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600 border border-indigo-200 shadow-xs">
        <Mail className="h-7 w-7 animate-pulse" />
      </div>

      <div className="space-y-1.5">
        <h3 className="text-lg font-extrabold text-slate-900">Verify Your Email Address</h3>
        <p className="text-xs text-slate-600 max-w-sm mx-auto leading-relaxed">
          We have sent a verification link to <strong className="text-slate-900">{email}</strong>. Please check your inbox and tap the link to confirm your account.
        </p>
      </div>

      {notice && (
        <div
          role="status"
          className="flex items-center gap-2 rounded-xl border border-indigo-200 bg-indigo-50/70 p-3 text-xs text-indigo-800 text-left font-medium"
        >
          <CheckCircle2 className="h-4 w-4 text-indigo-600 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      {error && (
        <div
          role="alert"
          className="flex items-center gap-2 rounded-xl border border-rose-200 bg-rose-50/80 p-3 text-xs text-rose-800 text-left font-medium"
        >
          <AlertCircle className="h-4 w-4 text-rose-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <div className="space-y-2.5 pt-1">
        {/* Check verification button */}
        <button
          type="button"
          onClick={handleCheckStatus}
          disabled={isChecking}
          className="w-full flex items-center justify-center gap-2 rounded-xl bg-indigo-600 py-3 px-4 text-sm font-bold text-white shadow-xs hover:bg-indigo-700 active:scale-[0.99] disabled:opacity-50 transition-all cursor-pointer"
        >
          {isChecking ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Checking Verification Status...</span>
            </>
          ) : (
            <>
              <RefreshCw className="h-4 w-4" />
              <span>I've Verified My Email</span>
            </>
          )}
        </button>

        {/* Resend button */}
        {cooldown > 0 ? (
          <p className="text-xs text-slate-400 font-medium py-1">
            Resend available in <span className="font-mono text-indigo-600 font-bold">{cooldown}s</span>
          </p>
        ) : (
          <button
            type="button"
            onClick={handleResend}
            disabled={isResending}
            className="w-full flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 py-2.5 text-xs font-semibold text-slate-700 transition-colors cursor-pointer disabled:opacity-50"
          >
            {isResending ? (
              <>
                <Loader2 className="h-3.5 w-3.5 animate-spin text-slate-500" />
                <span>Sending email...</span>
              </>
            ) : (
              <span>Resend Verification Email</span>
            )}
          </button>
        )}
      </div>

      <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
        <span>Wrong email address?</span>
        <button
          type="button"
          onClick={onLogout}
          className="flex items-center gap-1 text-slate-600 hover:text-rose-600 font-semibold cursor-pointer transition-colors"
        >
          <LogOut className="h-3.5 w-3.5" />
          <span>Sign Out</span>
        </button>
      </div>
    </div>
  );
};
