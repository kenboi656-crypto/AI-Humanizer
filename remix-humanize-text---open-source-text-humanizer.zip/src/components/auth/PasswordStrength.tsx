import React from 'react';
import { Check, X } from 'lucide-react';

interface PasswordStrengthProps {
  password: string;
}

export interface PasswordCriteria {
  minLength: boolean;
  hasUpper: boolean;
  hasLower: boolean;
  hasNumber: boolean;
  hasSpecial: boolean;
}

export function evaluatePassword(password: string): {
  criteria: PasswordCriteria;
  score: number; // 0 to 5
  isValid: boolean;
  label: string;
  colorClass: string;
} {
  const criteria: PasswordCriteria = {
    minLength: password.length >= 12,
    hasUpper: /[A-Z]/.test(password),
    hasLower: /[a-z]/.test(password),
    hasNumber: /[0-9]/.test(password),
    hasSpecial: /[^A-Za-z0-9]/.test(password),
  };

  const score = Object.values(criteria).filter(Boolean).length;
  const isValid = score === 5;

  let label = 'Very Weak';
  let colorClass = 'bg-rose-500 text-rose-600';

  if (score === 1 || score === 2) {
    label = 'Weak';
    colorClass = 'bg-rose-500 text-rose-600';
  } else if (score === 3) {
    label = 'Fair';
    colorClass = 'bg-amber-500 text-amber-600';
  } else if (score === 4) {
    label = 'Good';
    colorClass = 'bg-blue-500 text-blue-600';
  } else if (score === 5) {
    label = 'Strong';
    colorClass = 'bg-emerald-500 text-emerald-600';
  }

  return { criteria, score, isValid, label, colorClass };
}

export const PasswordStrength: React.FC<PasswordStrengthProps> = ({ password }) => {
  if (!password) return null;

  const { criteria, score, label } = evaluatePassword(password);

  const criteriaList = [
    { met: criteria.minLength, text: 'At least 12 characters' },
    { met: criteria.hasUpper, text: 'One uppercase letter (A-Z)' },
    { met: criteria.hasLower, text: 'One lowercase letter (a-z)' },
    { met: criteria.hasNumber, text: 'One number (0-9)' },
    { met: criteria.hasSpecial, text: 'One special character (!@#$%^&*)' },
  ];

  return (
    <div className="space-y-2.5 pt-1 animate-in fade-in duration-200">
      {/* Strength Bar */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-[11px] font-semibold">
          <span className="text-slate-500">Password Strength:</span>
          <span
            className={
              score === 5
                ? 'text-emerald-600 font-bold'
                : score >= 3
                ? 'text-amber-600 font-bold'
                : 'text-rose-600 font-bold'
            }
          >
            {label} ({score}/5)
          </span>
        </div>
        <div className="grid grid-cols-5 gap-1.5 h-1.5 w-full bg-slate-100 rounded-full overflow-hidden p-0.5">
          {[1, 2, 3, 4, 5].map((lvl) => (
            <div
              key={lvl}
              className={`h-full rounded-full transition-all duration-300 ${
                score >= lvl
                  ? score === 5
                    ? 'bg-emerald-500'
                    : score >= 3
                    ? 'bg-amber-500'
                    : 'bg-rose-500'
                  : 'bg-slate-200'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Checklist Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs text-slate-600 bg-slate-50/70 p-2.5 rounded-xl border border-slate-100">
        {criteriaList.map((item, index) => (
          <div key={index} className="flex items-center gap-1.5">
            {item.met ? (
              <Check className="h-3.5 w-3.5 text-emerald-600 shrink-0" strokeWidth={2.5} />
            ) : (
              <X className="h-3.5 w-3.5 text-slate-300 shrink-0" strokeWidth={2} />
            )}
            <span
              className={`text-[11px] leading-tight ${
                item.met ? 'text-slate-800 font-medium' : 'text-slate-400'
              }`}
            >
              {item.text}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
