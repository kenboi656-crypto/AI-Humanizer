import React, { useState, useRef } from 'react';
import {
  X,
  Sparkles,
  ShieldCheck,
  ImageIcon,
  Youtube,
  FileText,
  BookOpen,
  Headphones,
  Video,
  MessageSquare,
  Layers,
  Languages,
  BookMarked,
  FileArchive,
  Image,
  ArrowRight,
  Check,
  Copy,
  Upload,
  Search,
  ExternalLink,
  Download,
  RotateCw,
  Scissors,
  Split,
  FilePlus,
  Stamp,
  Lock,
  EyeOff,
  Wrench,
  CheckCircle2,
  AlertCircle,
  CreditCard,
  Crown,
  Users,
  GraduationCap,
} from 'lucide-react';
import { NavTab } from './Navbar';
import {
  mergePdfs,
  splitPdf,
  rotatePdf,
  extractPages,
  deletePages,
  cropPdfMargins,
  watermarkPdf,
  compressPdf,
  compressImageFile,
  imagesToPdf,
  signPdf,
  repairAndStandardizePdf,
  downloadBlob,
} from '../services/pdfToolsService';

interface ToolsCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTab: (tab: NavTab) => void;
  onSendToHumanizer?: (text: string) => void;
}

type ToolCategory =
  | 'all'
  | 'ai-detect'
  | 'ai-learning'
  | 'pdf-organize'
  | 'pdf-convert'
  | 'pdf-security'
  | 'pricing-plans';

type ActiveToolId =
  | null
  // AI Learning
  | 'notes-gen'
  | 'ai-summarizer'
  | 'flashcards'
  | 'ai-chat'
  | 'yt-transcript'
  | 'audio-text'
  | 'video-text'
  | 'words-translate'
  // PDF Organize & Edit
  | 'merge-pdf'
  | 'split-pdf'
  | 'rotate-pdf'
  | 'extract-pages'
  | 'delete-pages'
  | 'crop-margins'
  // Conversion
  | 'images-to-pdf'
  | 'compress-image'
  // Optimization & Security
  | 'compress-pdf'
  | 'watermark-pdf'
  | 'sign-pdf'
  | 'pdfa-repair'
  // Pricing
  | 'pricing-plans';

export const ToolsCenterModal: React.FC<ToolsCenterModalProps> = ({
  isOpen,
  onClose,
  onSelectTab,
  onSendToHumanizer,
}) => {
  const [activeCategory, setActiveCategory] = useState<ToolCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTool, setActiveTool] = useState<ActiveToolId>(null);

  // Input states
  const [textInput, setTextInput] = useState('');
  const [summaryLength, setSummaryLength] = useState<'brief' | 'balanced' | 'detailed'>('balanced');
  const [targetLang, setTargetLang] = useState('Spanish');
  const [ytUrl, setYtUrl] = useState('');

  // PDF Tool File States
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [splitRange, setSplitRange] = useState({ start: 1, end: 3 });
  const [rotateAngle, setRotateAngle] = useState<90 | 180 | 270>(90);
  const [pagesStr, setPagesStr] = useState('1, 3, 5');
  const [watermarkText, setWatermarkText] = useState('CONFIDENTIAL');
  const [signName, setSignName] = useState('Raheel Verified');

  // Execution states
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [resultOutput, setResultOutput] = useState<any>(null);
  const [copied, setCopied] = useState(false);

  // Chat Assistant State
  const [chatMessages, setChatMessages] = useState<Array<{ role: 'user' | 'ai'; text: string }>>([
    {
      role: 'ai',
      text: 'Hello! I am your AI Study & Research Tutor. Ask me any question, paste complex topics to break down, or ask for study guidance!',
    },
  ]);
  const [chatInput, setChatInput] = useState('');

  // Flashcards flip tracker
  const [flippedCards, setFlippedCards] = useState<Record<number, boolean>>({});

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleLaunchTab = (tab: NavTab) => {
    onSelectTab(tab);
    onClose();
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTransfer = (text: string) => {
    if (onSendToHumanizer) {
      onSendToHumanizer(text);
      onClose();
    }
  };

  // ----------------------------------------------------
  // REAL API EXECUTIONS FOR ALL AI TOOLS
  // ----------------------------------------------------
  const runAiTool = async (toolId: ActiveToolId) => {
    setError(null);
    setSuccessMsg(null);
    setIsProcessing(true);

    try {
      if (toolId === 'notes-gen') {
        if (!textInput.trim()) throw new Error('Please enter text or notes to format.');
        const res = await fetch('/api/tools/notes-generator', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: textInput }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to generate study notes');
        setResultOutput(data.notes);
        setSuccessMsg('100% Structured Study Notes Generated Successfully!');
      } else if (toolId === 'ai-summarizer') {
        if (!textInput.trim()) throw new Error('Please enter text to summarize.');
        const res = await fetch('/api/tools/ai-summarizer', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: textInput, length: summaryLength }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to generate summary');
        setResultOutput(data.summary);
        setSuccessMsg('Executive Summary Generated Successfully!');
      } else if (toolId === 'flashcards') {
        if (!textInput.trim()) throw new Error('Please enter study text to build flashcards.');
        const res = await fetch('/api/tools/flashcards', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: textInput }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to generate flashcards');
        setResultOutput(data.cards);
        setSuccessMsg(`Generated ${data.cards.length} Interactive Revision Flashcards!`);
      } else if (toolId === 'yt-transcript') {
        const query = ytUrl.trim() || textInput.trim();
        if (!query) throw new Error('Please enter a YouTube video URL or topic.');
        const res = await fetch('/api/tools/yt-transcript', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: query }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to extract transcript');
        setResultOutput(data.transcript);
        setSuccessMsg('YouTube Transcript & Chapters Extracted Successfully!');
      } else if (toolId === 'words-translate') {
        if (!textInput.trim()) throw new Error('Please enter words or phrases to translate.');
        const res = await fetch('/api/tools/words-translate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: textInput, targetLang }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Translation failed');
        setResultOutput(data.translation);
        setSuccessMsg('Linguistic & Idiomatic Translation Ready!');
      } else if (toolId === 'audio-text' || toolId === 'video-text') {
        const endpoint = toolId === 'audio-text' ? '/api/tools/audio-to-text' : '/api/tools/video-to-text';
        let res;
        if (selectedFiles.length > 0) {
          const formData = new FormData();
          formData.append(toolId === 'audio-text' ? 'audio' : 'video', selectedFiles[0]);
          res = await fetch(endpoint, { method: 'POST', body: formData });
        } else {
          if (!textInput.trim()) throw new Error('Please upload an audio/video file or enter speech description.');
          res = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: textInput, title: 'Media Audio' }),
          });
        }
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Transcription failed');
        setResultOutput(data.transcript);
        setSuccessMsg('Transcription Completed with 100% Accuracy!');
      }
    } catch (err: any) {
      setError(err.message || 'Operation failed');
    } finally {
      setIsProcessing(false);
    }
  };

  // ----------------------------------------------------
  // REAL CLIENT-SIDE PDF SUITE EXECUTIONS
  // ----------------------------------------------------
  const runPdfTool = async (toolId: ActiveToolId) => {
    setError(null);
    setSuccessMsg(null);
    setIsProcessing(true);

    try {
      if (toolId === 'merge-pdf') {
        if (selectedFiles.length < 2) throw new Error('Please select at least 2 PDF files to merge.');
        const result = await mergePdfs(selectedFiles);
        downloadBlob(result.blob, result.filename);
        setSuccessMsg(`Merged ${selectedFiles.length} PDFs (${result.pageCount} total pages) and downloaded!`);
      } else if (toolId === 'split-pdf') {
        if (selectedFiles.length === 0) throw new Error('Please upload a PDF file to split.');
        const result = await splitPdf(selectedFiles[0], splitRange.start, splitRange.end);
        downloadBlob(result.blob, result.filename);
        setSuccessMsg(`Split pages ${splitRange.start}-${splitRange.end} (${result.pageCount} pages) and downloaded!`);
      } else if (toolId === 'rotate-pdf') {
        if (selectedFiles.length === 0) throw new Error('Please upload a PDF file to rotate.');
        const result = await rotatePdf(selectedFiles[0], rotateAngle);
        downloadBlob(result.blob, result.filename);
        setSuccessMsg(`Rotated all pages by ${rotateAngle}° and downloaded!`);
      } else if (toolId === 'extract-pages') {
        if (selectedFiles.length === 0) throw new Error('Please upload a PDF file.');
        const result = await extractPages(selectedFiles[0], pagesStr);
        downloadBlob(result.blob, result.filename);
        setSuccessMsg(`Extracted pages [${pagesStr}] (${result.pageCount} pages) and downloaded!`);
      } else if (toolId === 'delete-pages') {
        if (selectedFiles.length === 0) throw new Error('Please upload a PDF file.');
        const result = await deletePages(selectedFiles[0], pagesStr);
        downloadBlob(result.blob, result.filename);
        setSuccessMsg(`Removed pages [${pagesStr}] and downloaded trimmed PDF!`);
      } else if (toolId === 'crop-margins') {
        if (selectedFiles.length === 0) throw new Error('Please upload a PDF file to crop.');
        const result = await cropPdfMargins(selectedFiles[0], 25);
        downloadBlob(result.blob, result.filename);
        setSuccessMsg(`Cropped margins uniformly and downloaded!`);
      } else if (toolId === 'images-to-pdf') {
        if (selectedFiles.length === 0) throw new Error('Please select at least one JPG or PNG image.');
        const result = await imagesToPdf(selectedFiles);
        downloadBlob(result.blob, result.filename);
        setSuccessMsg(`Converted ${selectedFiles.length} images to PDF and downloaded!`);
      } else if (toolId === 'compress-pdf') {
        if (selectedFiles.length === 0) throw new Error('Please upload a PDF file to compress.');
        const result = await compressPdf(selectedFiles[0]);
        downloadBlob(result.blob, result.filename);
        setSuccessMsg(`PDF Compressed: ${(result.originalSize / 1024).toFixed(0)} KB → ${(result.compressedSize / 1024).toFixed(0)} KB (saved ${result.ratio})!`);
      } else if (toolId === 'compress-image') {
        if (selectedFiles.length === 0) throw new Error('Please select an image file to compress.');
        const result = await compressImageFile(selectedFiles[0], 0.75);
        downloadBlob(result.blob, result.filename);
        setSuccessMsg(`Image Compressed: ${(result.originalSize / 1024).toFixed(0)} KB → ${(result.compressedSize / 1024).toFixed(0)} KB (saved ${result.ratio})!`);
      } else if (toolId === 'watermark-pdf') {
        if (selectedFiles.length === 0) throw new Error('Please upload a PDF file.');
        const result = await watermarkPdf(selectedFiles[0], watermarkText);
        downloadBlob(result.blob, result.filename);
        setSuccessMsg(`Watermarked with "${watermarkText}" and downloaded!`);
      } else if (toolId === 'sign-pdf') {
        if (selectedFiles.length === 0) throw new Error('Please upload a PDF file to sign.');
        // Generate an elegant SVG signature dataURL
        const canvas = document.createElement('canvas');
        canvas.width = 400;
        canvas.height = 120;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.font = 'italic bold 32px "Brush Script MT", cursive, sans-serif';
          ctx.fillStyle = '#1e1b4b';
          ctx.fillText(signName, 20, 70);
          ctx.strokeStyle = '#4338ca';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(15, 85);
          ctx.bezierCurveTo(100, 95, 250, 75, 380, 85);
          ctx.stroke();
        }
        const sigDataUrl = canvas.toDataURL('image/png');
        const result = await signPdf(selectedFiles[0], sigDataUrl, 1);
        downloadBlob(result.blob, result.filename);
        setSuccessMsg(`Electronically signed with "${signName}" and downloaded!`);
      } else if (toolId === 'pdfa-repair') {
        if (selectedFiles.length === 0) throw new Error('Please upload a PDF file.');
        const result = await repairAndStandardizePdf(selectedFiles[0]);
        downloadBlob(result.blob, result.filename);
        setSuccessMsg(`PDF/A ISO-19005 Compliance Applied & Repaired!`);
      }
    } catch (err: any) {
      setError(err.message || 'PDF processing failed');
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle AI Chat
  const handleSendChatMessage = async () => {
    if (!chatInput.trim()) return;
    const userText = chatInput.trim();
    setChatMessages((prev) => [...prev, { role: 'user', text: userText }]);
    setChatInput('');
    setIsProcessing(true);

    try {
      const res = await fetch('/api/tools/ai-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userText,
          history: chatMessages.slice(-6),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to send message');
      setChatMessages((prev) => [...prev, { role: 'ai', text: data.reply }]);
    } catch (err: any) {
      setChatMessages((prev) => [
        ...prev,
        { role: 'ai', text: `Sorry, I encountered an error: ${err.message}. Please try again.` },
      ]);
    } finally {
      setIsProcessing(false);
    }
  };

  // Tools catalog
  const ALL_TOOLS = [
    // Category 1: AI Humanize & Detect
    {
      id: 'pipeline',
      name: 'AI Humanizer',
      description: 'Rewrite AI text to read naturally with 100% human authenticity.',
      badge: '0.0% AI',
      badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      category: 'ai-detect',
      icon: Sparkles,
      iconColor: 'from-indigo-600 to-purple-600',
      isTab: true,
      tabTarget: 'pipeline' as NavTab,
    },
    {
      id: 'detector',
      name: 'AI Detector',
      description: 'Spot AI-written text instantly with word-by-word forensic metrics.',
      badge: 'Multi-Model',
      badgeColor: 'bg-rose-50 text-rose-700 border-rose-200',
      category: 'ai-detect',
      icon: ShieldCheck,
      iconColor: 'from-rose-500 to-pink-600',
      isTab: true,
      tabTarget: 'detector' as NavTab,
    },
    {
      id: 'image-detector',
      name: 'AI Image Detector',
      description: 'Detect AI-generated images from Midjourney, DALL-E, Flux, and SD.',
      badge: 'Deep Vision',
      badgeColor: 'bg-purple-50 text-purple-700 border-purple-200',
      category: 'ai-detect',
      icon: ImageIcon,
      iconColor: 'from-purple-600 to-indigo-600',
      isTab: true,
      tabTarget: 'image-detector' as NavTab,
    },

    // Category 2: AI Learning
    {
      id: 'yt-transcript',
      name: 'YouTube Transcript',
      description: 'Extract video captions with chronological timestamps & summaries.',
      badge: 'Timestamps',
      badgeColor: 'bg-red-50 text-red-700 border-red-200',
      category: 'ai-learning',
      icon: Youtube,
      iconColor: 'from-red-600 to-rose-600',
    },
    {
      id: 'youtube-summarizer',
      name: 'YouTube Summarizer',
      description: 'Summarize & humanize YouTube video lectures into clean prose.',
      badge: 'Video AI',
      badgeColor: 'bg-red-50 text-red-700 border-red-200',
      category: 'ai-learning',
      icon: Video,
      iconColor: 'from-red-500 to-amber-600',
      isTab: true,
      tabTarget: 'youtube' as NavTab,
    },
    {
      id: 'notes-gen',
      name: 'AI Notes Generator',
      description: 'Structured study notes with pillars, mnemonics, and self-quizzes.',
      badge: 'Study AI',
      badgeColor: 'bg-blue-50 text-blue-700 border-blue-200',
      category: 'ai-learning',
      icon: BookOpen,
      iconColor: 'from-blue-600 to-cyan-600',
    },
    {
      id: 'ai-summarizer',
      name: 'AI Summarizer',
      description: 'Condense long text into executive overviews and key takeaways.',
      badge: 'High Density',
      badgeColor: 'bg-indigo-50 text-indigo-700 border-indigo-200',
      category: 'ai-learning',
      icon: FileText,
      iconColor: 'from-indigo-600 to-blue-600',
    },
    {
      id: 'video-text',
      name: 'Video to Text',
      description: 'Transcribe spoken video dialogues with speaker IDs & quotes.',
      badge: 'Transcribe',
      badgeColor: 'bg-amber-50 text-amber-700 border-amber-200',
      category: 'ai-learning',
      icon: Video,
      iconColor: 'from-amber-600 to-orange-600',
    },
    {
      id: 'audio-text',
      name: 'Audio to Text',
      description: 'Transcribe voice recordings into accurate, clean text verbatim.',
      badge: 'Speech-to-Text',
      badgeColor: 'bg-teal-50 text-teal-700 border-teal-200',
      category: 'ai-learning',
      icon: Headphones,
      iconColor: 'from-teal-600 to-emerald-600',
    },
    {
      id: 'ai-chat',
      name: 'AI Chat Tutor',
      description: 'Interactive study AI assistant that breaks down difficult concepts.',
      badge: 'Live Tutor',
      badgeColor: 'bg-purple-50 text-purple-700 border-purple-200',
      category: 'ai-learning',
      icon: MessageSquare,
      iconColor: 'from-purple-600 to-pink-600',
    },
    {
      id: 'flashcards',
      name: 'Auto Flashcards',
      description: 'Interactive revision flip-cards generated from study content.',
      badge: 'Revision',
      badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      category: 'ai-learning',
      icon: Layers,
      iconColor: 'from-emerald-600 to-teal-600',
    },
    {
      id: 'words-translate',
      name: 'Words & Idioms Translate',
      description: 'Idiomatic vocabulary, cultural context, and slang equivalents.',
      badge: 'Linguistics',
      badgeColor: 'bg-indigo-50 text-indigo-700 border-indigo-200',
      category: 'ai-learning',
      icon: BookMarked,
      iconColor: 'from-indigo-600 to-violet-600',
    },
    {
      id: 'translator',
      name: 'Doc Translator',
      description: 'Humanized document translation preserving academic accuracy.',
      badge: '10+ Languages',
      badgeColor: 'bg-cyan-50 text-cyan-700 border-cyan-200',
      category: 'ai-learning',
      icon: Languages,
      iconColor: 'from-cyan-600 to-blue-600',
      isTab: true,
      tabTarget: 'translator' as NavTab,
    },

    // Category 3: Organization & Editing (PDF)
    {
      id: 'merge-pdf',
      name: 'Merge PDF',
      description: 'Merge multiple PDFs into a single unified document.',
      badge: 'Organization',
      badgeColor: 'bg-blue-50 text-blue-700 border-blue-200',
      category: 'pdf-organize',
      icon: FilePlus,
      iconColor: 'from-blue-600 to-indigo-600',
    },
    {
      id: 'split-pdf',
      name: 'Split PDF',
      description: 'Split documents into separate page range files.',
      badge: 'Editing',
      badgeColor: 'bg-violet-50 text-violet-700 border-violet-200',
      category: 'pdf-organize',
      icon: Split,
      iconColor: 'from-violet-600 to-purple-600',
    },
    {
      id: 'rotate-pdf',
      name: 'Rotate Pages',
      description: 'Rotate PDF pages by 90°, 180°, or 270° degrees permanently.',
      badge: 'Orientation',
      badgeColor: 'bg-amber-50 text-amber-700 border-amber-200',
      category: 'pdf-organize',
      icon: RotateCw,
      iconColor: 'from-amber-600 to-yellow-600',
    },
    {
      id: 'extract-pages',
      name: 'Extract Pages',
      description: 'Extract specific pages (e.g. 1, 3, 5-7) into a fresh PDF file.',
      badge: 'Extraction',
      badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      category: 'pdf-organize',
      icon: Scissors,
      iconColor: 'from-emerald-600 to-teal-600',
    },
    {
      id: 'delete-pages',
      name: 'Delete Pages',
      description: 'Remove unwanted pages and keep only the necessary pages.',
      badge: 'Trimming',
      badgeColor: 'bg-rose-50 text-rose-700 border-rose-200',
      category: 'pdf-organize',
      icon: Scissors,
      iconColor: 'from-rose-600 to-pink-600',
    },
    {
      id: 'crop-margins',
      name: 'Crop Margins',
      description: 'Crop document margins to eliminate excess white borders.',
      badge: 'Formatting',
      badgeColor: 'bg-indigo-50 text-indigo-700 border-indigo-200',
      category: 'pdf-organize',
      icon: Scissors,
      iconColor: 'from-indigo-600 to-blue-600',
    },

    // Category 4: Conversion & OCR
    {
      id: 'images-to-pdf',
      name: 'Images to PDF',
      description: 'Convert JPG, PNG, and WebP images into a formatted PDF.',
      badge: 'To PDF',
      badgeColor: 'bg-purple-50 text-purple-700 border-purple-200',
      category: 'pdf-convert',
      icon: Image,
      iconColor: 'from-purple-600 to-indigo-600',
    },
    {
      id: 'compress-image',
      name: 'Compress Image',
      description: 'Reduce JPG and PNG file sizes by up to 75% without quality loss.',
      badge: 'Optimizer',
      badgeColor: 'bg-teal-50 text-teal-700 border-teal-200',
      category: 'pdf-convert',
      icon: Image,
      iconColor: 'from-teal-600 to-emerald-600',
    },

    // Category 5: Optimization & Security
    {
      id: 'compress-pdf',
      name: 'Compress PDF',
      description: 'Reduce PDF file sizes while optimizing quality for easy sharing.',
      badge: 'Size Saver',
      badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      category: 'pdf-security',
      icon: FileArchive,
      iconColor: 'from-emerald-600 to-green-600',
    },
    {
      id: 'watermark-pdf',
      name: 'Watermark PDF',
      description: 'Apply custom text watermarks, angle, and opacity across pages.',
      badge: 'Copyright',
      badgeColor: 'bg-blue-50 text-blue-700 border-blue-200',
      category: 'pdf-security',
      icon: Stamp,
      iconColor: 'from-blue-600 to-indigo-600',
    },
    {
      id: 'sign-pdf',
      name: 'Digital Signature',
      description: 'Sign documents electronically with a verified digital signature stamp.',
      badge: 'e-Sign',
      badgeColor: 'bg-indigo-50 text-indigo-700 border-indigo-200',
      category: 'pdf-security',
      icon: Stamp,
      iconColor: 'from-indigo-600 to-purple-600',
    },
    {
      id: 'pdfa-repair',
      name: 'PDF/A & Repair',
      description: 'Standardize to ISO-19005 archival standard and repair corrupted files.',
      badge: 'ISO Standards',
      badgeColor: 'bg-amber-50 text-amber-700 border-amber-200',
      category: 'pdf-security',
      icon: Wrench,
      iconColor: 'from-amber-600 to-orange-600',
    },

    // Category 6: Pricing & Tiers
    {
      id: 'pricing-plans',
      name: 'Pricing & Tiers',
      description: 'Free Plan, Premium Plan, and Business / Education licenses.',
      badge: 'Plans',
      badgeColor: 'bg-amber-50 text-amber-700 border-amber-200',
      category: 'pricing-plans',
      icon: Crown,
      iconColor: 'from-amber-500 to-orange-500',
    },
  ];

  const filteredTools = ALL_TOOLS.filter((tool) => {
    const matchesCategory = activeCategory === 'all' || tool.category === activeCategory;
    const matchesSearch =
      searchQuery === '' ||
      tool.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl rounded-3xl border border-slate-200 bg-white p-6 sm:p-8 shadow-2xl space-y-6 max-h-[92vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 rounded-full p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-800 transition-colors cursor-pointer"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Modal Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 rounded-full bg-indigo-50 border border-indigo-200 px-3 py-0.5 text-xs font-bold text-indigo-700">
              <Sparkles className="h-3.5 w-3.5" />
              <span>Full AI &amp; Document Suite · 100% Accurate</span>
            </div>
            <h2 className="text-2xl font-extrabold tracking-tight text-slate-900">
              All Tools &amp; Capabilities
            </h2>
            <p className="text-xs text-slate-500">
              Launch dedicated AI humanizers, study tools, PDF editing, and conversion features.
            </p>
          </div>

          {/* Search Bar */}
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search all 20+ tools..."
              className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-xs text-slate-800 placeholder-slate-400 focus:border-indigo-500 focus:bg-white focus:outline-none"
            />
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {[
            { id: 'all', label: 'All Tools' },
            { id: 'ai-detect', label: 'AI Humanize & Detect' },
            { id: 'ai-learning', label: 'AI Learning Suite' },
            { id: 'pdf-organize', label: 'Organization & Editing' },
            { id: 'pdf-convert', label: 'Conversion & OCR' },
            { id: 'pdf-security', label: 'Optimization & Security' },
            { id: 'pricing-plans', label: 'Pricing & Tiers' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                setActiveCategory(cat.id as ToolCategory);
                setActiveTool(null);
              }}
              className={`shrink-0 rounded-xl px-3.5 py-1.5 text-xs font-bold transition-all cursor-pointer ${
                activeCategory === cat.id
                  ? 'bg-indigo-600 text-white shadow-xs shadow-indigo-500/20'
                  : 'border border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* ---------------- ACTIVE TOOL WORKSPACE MODAL ---------------- */}
        {activeTool && (
          <div className="rounded-2xl border border-indigo-200 bg-gradient-to-br from-indigo-50/40 via-white to-purple-50/20 p-5 space-y-4 shadow-sm animate-in fade-in">
            <div className="flex items-center justify-between border-b border-indigo-100 pb-3">
              <div className="flex items-center gap-2.5">
                <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-indigo-600 text-white text-xs font-bold">
                  ⚡
                </span>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    {ALL_TOOLS.find((t) => t.id === activeTool)?.name}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    {ALL_TOOLS.find((t) => t.id === activeTool)?.description}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setActiveTool(null);
                  setError(null);
                  setSuccessMsg(null);
                  setResultOutput(null);
                  setSelectedFiles([]);
                }}
                className="text-xs text-slate-500 hover:text-slate-800 font-semibold"
              >
                Close Tool ✕
              </button>
            </div>

            {/* Error & Success notifications */}
            {error && (
              <div className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs text-rose-700 flex items-center gap-2">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}
            {successMsg && (
              <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-xs text-emerald-800 flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 shrink-0" />
                <span>{successMsg}</span>
              </div>
            )}

            {/* TOOL 1: AI Study Chat */}
            {activeTool === 'ai-chat' && (
              <div className="space-y-3">
                <div className="h-64 overflow-y-auto space-y-2.5 rounded-xl border border-slate-200 bg-white p-3.5 text-xs">
                  {chatMessages.map((msg, i) => (
                    <div
                      key={i}
                      className={`flex gap-2.5 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      {msg.role === 'ai' && (
                        <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-indigo-600 text-[10px] font-bold text-white">
                          AI
                        </div>
                      )}
                      <div
                        className={`max-w-[80%] rounded-2xl px-3.5 py-2 leading-relaxed ${
                          msg.role === 'user'
                            ? 'bg-indigo-600 text-white'
                            : 'bg-slate-100 text-slate-800'
                        }`}
                      >
                        {msg.text}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendChatMessage()}
                    placeholder="Ask study questions, explain terms, or paste your draft..."
                    className="flex-1 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs text-slate-800 focus:border-indigo-500 focus:outline-none"
                  />
                  <button
                    onClick={handleSendChatMessage}
                    disabled={isProcessing}
                    className="rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white hover:bg-indigo-700 disabled:opacity-50 cursor-pointer"
                  >
                    {isProcessing ? 'Thinking...' : 'Send'}
                  </button>
                </div>
              </div>
            )}

            {/* TOOL 2: YouTube Transcript */}
            {activeTool === 'yt-transcript' && (
              <div className="space-y-3">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={ytUrl}
                    onChange={(e) => setYtUrl(e.target.value)}
                    placeholder="Enter YouTube Video URL (e.g. https://www.youtube.com/watch?v=...) or topic"
                    className="flex-1 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs text-slate-800 focus:border-indigo-500 focus:outline-none"
                  />
                  <button
                    onClick={() => runAiTool('yt-transcript')}
                    disabled={isProcessing}
                    className="rounded-xl bg-red-600 px-4 py-2 text-xs font-bold text-white hover:bg-red-700 disabled:opacity-50 cursor-pointer"
                  >
                    {isProcessing ? 'Extracting...' : 'Extract Transcript'}
                  </button>
                </div>
              </div>
            )}

            {/* TOOL 3: Words & Idioms Translate */}
            {activeTool === 'words-translate' && (
              <div className="space-y-3">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={textInput}
                    onChange={(e) => setTextInput(e.target.value)}
                    placeholder="Enter word, phrase, or idiom to translate..."
                    className="flex-1 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs text-slate-800 focus:border-indigo-500 focus:outline-none"
                  />
                  <select
                    value={targetLang}
                    onChange={(e) => setTargetLang(e.target.value)}
                    className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700"
                  >
                    {['Spanish', 'French', 'German', 'Urdu', 'Chinese', 'Japanese', 'Arabic', 'Russian'].map((l) => (
                      <option key={l} value={l}>{l}</option>
                    ))}
                  </select>
                  <button
                    onClick={() => runAiTool('words-translate')}
                    disabled={isProcessing}
                    className="rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white hover:bg-indigo-700 disabled:opacity-50 cursor-pointer"
                  >
                    {isProcessing ? 'Translating...' : 'Translate Idioms'}
                  </button>
                </div>
              </div>
            )}

            {/* TOOL 4: Text-Based AI Tools (Notes, Summarizer, Flashcards) */}
            {['notes-gen', 'ai-summarizer', 'flashcards'].includes(activeTool) && (
              <div className="space-y-3">
                {activeTool === 'ai-summarizer' && (
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-semibold text-slate-600">Length:</span>
                    {(['brief', 'balanced', 'detailed'] as const).map((len) => (
                      <button
                        key={len}
                        onClick={() => setSummaryLength(len)}
                        className={`rounded-lg px-2.5 py-1 text-xs font-bold capitalize ${
                          summaryLength === len
                            ? 'bg-indigo-600 text-white'
                            : 'bg-white border border-slate-200 text-slate-600'
                        }`}
                      >
                        {len}
                      </button>
                    ))}
                  </div>
                )}

                <textarea
                  value={textInput}
                  onChange={(e) => setTextInput(e.target.value)}
                  placeholder="Paste lecture text, research draft, or article content here..."
                  rows={5}
                  className="w-full rounded-xl border border-slate-200 bg-white p-3 text-xs text-slate-800 focus:border-indigo-500 focus:outline-none"
                />

                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => runAiTool(activeTool)}
                    disabled={isProcessing}
                    className="rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-bold text-white hover:bg-indigo-700 disabled:opacity-50 transition-all cursor-pointer shadow-xs"
                  >
                    {isProcessing ? 'Processing with Gemini...' : 'Generate 100% Accurate Output'}
                  </button>
                </div>
              </div>
            )}

            {/* TOOL 5: PDF Suite Tools (Merge, Split, Rotate, Extract, Compress, Watermark, Sign) */}
            {[
              'merge-pdf',
              'split-pdf',
              'rotate-pdf',
              'extract-pages',
              'delete-pages',
              'crop-margins',
              'images-to-pdf',
              'compress-pdf',
              'compress-image',
              'watermark-pdf',
              'sign-pdf',
              'pdfa-repair',
              'audio-text',
              'video-text',
            ].includes(activeTool) && (
              <div className="space-y-4">
                {/* File picker */}
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="rounded-2xl border-2 border-dashed border-indigo-200 bg-white p-6 text-center hover:border-indigo-400 hover:bg-indigo-50/30 transition-all cursor-pointer"
                >
                  <Upload className="mx-auto h-8 w-8 text-indigo-500 mb-1.5" />
                  <div className="text-xs font-bold text-slate-800">
                    {selectedFiles.length > 0
                      ? `${selectedFiles.length} file(s) selected: ${selectedFiles.map((f) => f.name).join(', ')}`
                      : activeTool === 'images-to-pdf' || activeTool === 'compress-image'
                      ? 'Click to upload JPG/PNG images'
                      : activeTool === 'audio-text' || activeTool === 'video-text'
                      ? 'Click to upload audio or video recording'
                      : 'Click to upload PDF document(s)'}
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Safe client-side execution with instantaneous download
                  </p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple={activeTool === 'merge-pdf' || activeTool === 'images-to-pdf'}
                    accept={
                      activeTool === 'compress-image' || activeTool === 'images-to-pdf'
                        ? 'image/*'
                        : activeTool === 'audio-text'
                        ? 'audio/*'
                        : activeTool === 'video-text'
                        ? 'video/*'
                        : 'application/pdf'
                    }
                    onChange={(e) => {
                      if (e.target.files) {
                        setSelectedFiles(Array.from(e.target.files));
                      }
                    }}
                    className="hidden"
                  />
                </div>

                {/* Sub-tool specific parameters */}
                {activeTool === 'split-pdf' && (
                  <div className="flex items-center gap-3 text-xs">
                    <span className="font-bold text-slate-700">Page Range:</span>
                    <input
                      type="number"
                      min={1}
                      value={splitRange.start}
                      onChange={(e) => setSplitRange({ ...splitRange, start: parseInt(e.target.value) || 1 })}
                      className="w-16 rounded-lg border border-slate-200 p-1.5 text-center font-mono"
                    />
                    <span>to</span>
                    <input
                      type="number"
                      min={1}
                      value={splitRange.end}
                      onChange={(e) => setSplitRange({ ...splitRange, end: parseInt(e.target.value) || 1 })}
                      className="w-16 rounded-lg border border-slate-200 p-1.5 text-center font-mono"
                    />
                  </div>
                )}

                {activeTool === 'rotate-pdf' && (
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-bold text-slate-700">Rotate By:</span>
                    {[90, 180, 270].map((deg) => (
                      <button
                        key={deg}
                        onClick={() => setRotateAngle(deg as any)}
                        className={`rounded-lg px-3 py-1.5 font-bold ${
                          rotateAngle === deg ? 'bg-indigo-600 text-white' : 'border border-slate-200 bg-white'
                        }`}
                      >
                        {deg}° Clockwise
                      </button>
                    ))}
                  </div>
                )}

                {(activeTool === 'extract-pages' || activeTool === 'delete-pages') && (
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-bold text-slate-700">Specify Pages:</span>
                    <input
                      type="text"
                      value={pagesStr}
                      onChange={(e) => setPagesStr(e.target.value)}
                      placeholder="e.g. 1, 3, 5-8"
                      className="flex-1 rounded-lg border border-slate-200 p-1.5 font-mono text-xs"
                    />
                  </div>
                )}

                {activeTool === 'watermark-pdf' && (
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-bold text-slate-700">Watermark Text:</span>
                    <input
                      type="text"
                      value={watermarkText}
                      onChange={(e) => setWatermarkText(e.target.value)}
                      className="flex-1 rounded-lg border border-slate-200 p-1.5 text-xs font-bold"
                    />
                  </div>
                )}

                {activeTool === 'sign-pdf' && (
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-bold text-slate-700">Digital Signer Name:</span>
                    <input
                      type="text"
                      value={signName}
                      onChange={(e) => setSignName(e.target.value)}
                      className="flex-1 rounded-lg border border-slate-200 p-1.5 text-xs font-bold"
                    />
                  </div>
                )}

                <div className="flex justify-end gap-2">
                  <button
                    onClick={() =>
                      activeTool === 'audio-text' || activeTool === 'video-text'
                        ? runAiTool(activeTool)
                        : runPdfTool(activeTool)
                    }
                    disabled={isProcessing || selectedFiles.length === 0}
                    className="rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-bold text-white hover:bg-indigo-700 disabled:opacity-50 transition-all cursor-pointer shadow-xs flex items-center gap-2"
                  >
                    <Download className="h-4 w-4" />
                    <span>{isProcessing ? 'Processing...' : 'Run & Download Output'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* TOOL 6: PRICING & TIERS */}
            {activeTool === 'pricing-plans' && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                  {/* Free Plan */}
                  <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
                    <span className="rounded-full bg-slate-100 text-slate-700 px-2.5 py-0.5 text-[10px] font-bold">
                      FREE PLAN
                    </span>
                    <div className="text-2xl font-black text-slate-900">$0</div>
                    <p className="text-slate-500 text-[11px]">Free access to basic tools with usage caps.</p>
                    <ul className="space-y-1.5 text-slate-600">
                      <li>✓ Basic AI Humanizer (Simple mode)</li>
                      <li>✓ Free Lifetime for Pakistani users 🇵🇰</li>
                      <li>✓ Basic PDF Merge &amp; Rotate</li>
                      <li>✓ Standard 25MB file upload limit</li>
                    </ul>
                  </div>

                  {/* Premium Plan */}
                  <div className="relative rounded-2xl border-2 border-indigo-500 bg-white p-5 space-y-3 shadow-md shadow-indigo-500/10">
                    <span className="rounded-full bg-indigo-600 text-white px-2.5 py-0.5 text-[10px] font-bold">
                      PREMIUM PRO
                    </span>
                    <div className="text-2xl font-black text-slate-900">$3.99 <span className="text-xs font-normal text-slate-400">/mo</span></div>
                    <p className="text-slate-500 text-[11px]">Full unlocked access without caps.</p>
                    <ul className="space-y-1.5 text-slate-600 font-medium">
                      <li>✓ Enhanced 0.0% AI Humanizer</li>
                      <li>✓ Batch PDF processing without limits</li>
                      <li>✓ Advanced Gemini Multimodal OCR</li>
                      <li>✓ Secure e-Signatures &amp; Watermarks</li>
                      <li>✓ Full ad-free experience</li>
                    </ul>
                  </div>

                  {/* Business / Education */}
                  <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
                    <span className="rounded-full bg-purple-100 text-purple-700 px-2.5 py-0.5 text-[10px] font-bold">
                      BUSINESS &amp; EDU
                    </span>
                    <div className="text-2xl font-black text-slate-900">$9.99 <span className="text-xs font-normal text-slate-400">/seat</span></div>
                    <p className="text-slate-500 text-[11px]">Multi-user licensing &amp; team workflows.</p>
                    <ul className="space-y-1.5 text-slate-600">
                      <li>✓ Multi-user seats &amp; admin dashboard</li>
                      <li>✓ API console access with bulk webhooks</li>
                      <li>✓ Custom automated pipelines</li>
                      <li>✓ Dedicated high-priority processing</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* RESULTS VIEWER (For Text/Flashcards/Transcripts) */}
            {resultOutput && (
              <div className="space-y-3 pt-3 border-t border-indigo-100">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800">Generated Result:</span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleCopy(typeof resultOutput === 'string' ? resultOutput : JSON.stringify(resultOutput, null, 2))}
                      className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                    >
                      {copied ? <Check className="h-3 w-3 text-emerald-600" /> : <Copy className="h-3 w-3" />}
                      <span>{copied ? 'Copied' : 'Copy Output'}</span>
                    </button>
                    {typeof resultOutput === 'string' && (
                      <button
                        onClick={() => handleTransfer(resultOutput)}
                        className="inline-flex items-center gap-1 rounded-lg bg-indigo-600 px-3 py-1 text-xs font-bold text-white hover:bg-indigo-700 cursor-pointer shadow-2xs"
                      >
                        <Sparkles className="h-3 w-3" />
                        <span>Send to Humanizer</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Render Flashcards as interactive flip cards */}
                {Array.isArray(resultOutput) ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {resultOutput.map((card: any, idx: number) => {
                      const isFlipped = !!flippedCards[idx];
                      return (
                        <div
                          key={idx}
                          onClick={() => setFlippedCards({ ...flippedCards, [idx]: !isFlipped })}
                          className={`min-h-[140px] rounded-2xl p-4 flex flex-col justify-between cursor-pointer border transition-all ${
                            isFlipped
                              ? 'bg-indigo-600 text-white border-indigo-700 shadow-md'
                              : 'bg-white text-slate-800 border-slate-200 shadow-xs hover:border-indigo-300'
                          }`}
                        >
                          <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-wider mb-2">
                            <span>{card.category || 'Concept'}</span>
                            <span className={isFlipped ? 'text-indigo-200' : 'text-slate-400'}>
                              {isFlipped ? 'Answer' : 'Click to Flip'}
                            </span>
                          </div>
                          <div className="text-xs font-semibold leading-relaxed">
                            {isFlipped ? card.answer : card.question}
                          </div>
                          <div className="text-[9px] text-right opacity-70 mt-2">
                            Card {idx + 1}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="max-h-72 overflow-y-auto rounded-xl border border-slate-200 bg-white p-4 font-mono text-xs text-slate-800 whitespace-pre-wrap leading-relaxed">
                    {resultOutput}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ---------------- TOOLS GRID ---------------- */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {filteredTools.map((tool) => {
            const Icon = tool.icon;
            return (
              <div
                key={tool.id}
                onClick={() => {
                  if (tool.isTab && tool.tabTarget) {
                    handleLaunchTab(tool.tabTarget);
                  } else {
                    setActiveTool(tool.id as ActiveToolId);
                    setError(null);
                    setSuccessMsg(null);
                    setResultOutput(null);
                  }
                }}
                className={`group relative flex flex-col justify-between rounded-2xl border p-4 transition-all cursor-pointer ${
                  activeTool === tool.id
                    ? 'border-indigo-500 bg-indigo-50/50 shadow-sm'
                    : 'border-slate-200 bg-white hover:border-indigo-300 hover:shadow-sm'
                }`}
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div
                      className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr ${tool.iconColor} text-white shadow-xs group-hover:scale-105 transition-transform`}
                    >
                      <Icon className="h-5 w-5" />
                    </div>
                    <span
                      className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${tool.badgeColor}`}
                    >
                      {tool.badge}
                    </span>
                  </div>

                  <div>
                    <h4 className="text-xs font-extrabold text-slate-900 group-hover:text-indigo-600 transition-colors">
                      {tool.name}
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed line-clamp-2">
                      {tool.description}
                    </p>
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-100 text-[11px] font-bold text-indigo-600">
                  <span>{tool.isTab ? 'Open Workspace' : 'Launch Tool'}</span>
                  <ArrowRight className="h-3 w-3 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
