import React, { useState, useRef } from 'react';
import {
  HumanizerConfig,
  HumanizeResponse,
  DetectionMetrics,
  ReadabilityLevel,
  WritingPurpose,
  HumanizationMode,
} from '../types/humanizer';
import { DetectionCard } from './DetectionCard';
import { DetectorScoreTracker } from './DetectorScoreTracker';
import { useAuth } from '../context/AuthContext';
import { UpgradeModal } from './UpgradeModal';
import { BrandLogo } from './BrandLogo';
import {
  Sparkles,
  Copy,
  Check,
  RotateCcw,
  ShieldCheck,
  Globe,
  FileText,
  ClipboardPaste,
  FileUp,
  Image as ImageIcon,
  Loader2,
  Crown,
  CreditCard,
  HelpCircle,
  Zap,
  Layers,
  ArrowRight,
  Download,
  ChevronDown,
} from 'lucide-react';
import { exportAsPdf, exportAsDocx, exportAsTxt } from '../services/exportDocumentService';

interface PipelinePlaygroundProps {
  config: HumanizerConfig;
  onOpenConfig?: () => void;
  onNavigateToAuth?: () => void;
  onTriggerAuthPopup?: () => void;
  onSendToDetector?: (text: string) => void;
  initialText?: string;
}

type HumanizerTone = 'casual' | 'natural' | 'conversational';

const PRESETS = {
  chatgpt: `In today's fast-paced digital world, artificial intelligence plays a pivotal role in optimizing operational workflows. Furthermore, organizations can leverage predictive analytics to make informed decisions, delve into complex data, and ensure seamless cross-functional alignment. Consequently, modern enterprises must harness these innovative technologies to remain competitive.`,
  claude: `It is worth noting that the multifaceted implications of algorithmic automation extend significantly across contemporary organizational paradigms. One must consider not merely the computational efficiency, but also the nuanced trade-offs between human agency and synthetic outputs. Overall, this phenomenon reflects an unprecedented inflection point.`,
  mixed: `We conducted a thorough market review last Tuesday. However, it is essential to highlight that predictive machine learning algorithms represent a monumental leap forward in technical efficacy. Team members reported high satisfaction, yet modern paradigms necessitate continuous algorithmic optimization to maximize throughput.`,
};

export const PipelinePlayground: React.FC<PipelinePlaygroundProps> = ({
  config,
  onTriggerAuthPopup,
  onSendToDetector,
  initialText = '',
}) => {
  const {
    user,
    isAuthenticated,
    canHumanize,
    recordHumanization,
  } = useAuth();

  const [inputText, setInputText] = useState(initialText || PRESETS.chatgpt);
  const [targetLang, setTargetLang] = useState('en');
  const [selectedTone, setSelectedTone] = useState<HumanizerTone>('natural');
  const [showToneGuide, setShowToneGuide] = useState(false);

  const [humanizationMode, setHumanizationMode] = useState<HumanizationMode>('simple');
  const [readabilityLevel, setReadabilityLevel] = useState<ReadabilityLevel>('normal');
  const [writingPurpose, setWritingPurpose] = useState<WritingPurpose>('general');
  const [upgradeFeatureHint, setUpgradeFeatureHint] = useState<string>('');

  const [isLoading, setIsLoading] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadNotice, setUploadNotice] = useState<{
    filename: string;
    type: 'pdf' | 'image' | 'doc';
    metrics?: DetectionMetrics;
  } | null>(null);

  const [error, setError] = useState<string | null>(null);
  const [response, setResponse] = useState<HumanizeResponse | null>(null);
  const [copied, setCopied] = useState(false);
  const [isUpgradeModalOpen, setIsUpgradeModalOpen] = useState(false);
  const [isExportMenuOpen, setIsExportMenuOpen] = useState(false);
  const [isExporting, setIsExporting] = useState<string | null>(null);

  const handleExport = async (format: 'pdf' | 'docx' | 'txt') => {
    if (!response?.result) return;
    setIsExporting(format);
    try {
      const meta = {
        wordCount: outputWords,
        charCount: outputLetters,
        readability: readabilityLevel,
        purpose: writingPurpose,
        tone: selectedTone,
      };
      if (format === 'pdf') {
        await exportAsPdf(response.result, meta);
      } else if (format === 'docx') {
        exportAsDocx(response.result, meta);
      } else {
        exportAsTxt(response.result);
      }
    } catch (err) {
      console.error('Export error:', err);
    } finally {
      setIsExporting(null);
      setIsExportMenuOpen(false);
    }
  };

  const pdfInputRef = useRef<HTMLInputElement>(null);
  const docInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const inputWords = inputText.trim() ? inputText.trim().split(/\s+/).length : 0;
  const inputLetters = inputText.replace(/\s/g, '').length;

  const outputWords = response?.result?.trim()
    ? response.result.trim().split(/\s+/).length
    : 0;
  const outputLetters = response?.result
    ? response.result.replace(/\s/g, '').length
    : 0;

  const isPakistani = user ? user.countryCode === '+92' || user.isPakistani : false;
  const isPaid = user?.hasPaid || user?.plan === 'pro';
  const isProOrPakistani = isPakistani || isPaid;

  const handleSelectMode = (mode: HumanizationMode) => {
    if (mode !== 'simple' && !isProOrPakistani) {
      setUpgradeFeatureHint(`${mode === 'enhanced' ? 'Enhanced Strict 0.0%' : 'Standard Balanced'} Mode (Unlock After Upgrade)`);
      setIsUpgradeModalOpen(true);
      return;
    }
    setHumanizationMode(mode);
  };

  const handleSelectReadability = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value as ReadabilityLevel;
    if (val !== 'normal' && !isProOrPakistani) {
      setUpgradeFeatureHint(`Readability Level: ${val.replace('_', ' ').toUpperCase()} (Unlock After Upgrade)`);
      setIsUpgradeModalOpen(true);
      setReadabilityLevel('normal');
      return;
    }
    setReadabilityLevel(val);
  };

  const handleSelectPurpose = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value as WritingPurpose;
    if (val !== 'general' && !isProOrPakistani) {
      setUpgradeFeatureHint(`Writing Purpose: ${val.toUpperCase()} (Unlock After Upgrade)`);
      setIsUpgradeModalOpen(true);
      setWritingPurpose('general');
      return;
    }
    setWritingPurpose(val);
  };

  const handleSelectTone = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value as HumanizerTone;
    if (val !== 'natural' && !isProOrPakistani) {
      setUpgradeFeatureHint(`Humanizing Tone: ${val.toUpperCase()} (Unlock After Upgrade)`);
      setIsUpgradeModalOpen(true);
      setSelectedTone('natural');
      return;
    }
    setSelectedTone(val);
  };

  const handleRunPipeline = async () => {
    if (!inputText.trim()) return;

    if (!isAuthenticated && onTriggerAuthPopup) {
      onTriggerAuthPopup();
      return;
    }

    if (!canHumanize) {
      setIsUpgradeModalOpen(true);
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/humanize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: inputText,
          method: 'standard',
          targetLang,
          tone: selectedTone,
          readability: readabilityLevel,
          purpose: writingPurpose,
          humanizationMode,
          intermediateLang: config.intermediateLang || 'fi',
          temperature: config.temperature || 1.35,
          config,
        }),
      });

      const contentType = res.headers.get('content-type') || '';
      let data: any = null;
      if (contentType.includes('application/json')) {
        data = await res.json();
      } else {
        const raw = await res.text();
        throw new Error(raw.slice(0, 150) || `Server error (${res.status})`);
      }

      if (!res.ok) {
        throw new Error(data.error || `HTTP error ${res.status}`);
      }

      setResponse(data);
      if (data.result) {
        const words = data.result.trim().split(/\s+/).length;
        recordHumanization(words);
      }
    } catch (err: any) {
      console.error('Humanize error:', err);
      setError(err.message || 'Failed to humanize text. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setInputText(text);
        setUploadNotice(null);
      }
    } catch (err) {
      console.error('Paste error:', err);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'pdf' | 'doc') => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.name.endsWith('.txt') || file.name.endsWith('.md')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        setInputText(content);
        setUploadNotice({ filename: file.name, type: 'doc' });
      };
      reader.readAsText(file);
      return;
    }

    setIsUploading(true);
    setError(null);
    setUploadNotice(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await fetch('/api/extract-pdf', {
        method: 'POST',
        body: formData,
      });

      const contentType = res.headers.get('content-type') || '';
      let data: any = null;

      if (contentType.includes('application/json')) {
        data = await res.json();
      } else {
        const raw = await res.text();
        throw new Error(raw.slice(0, 150) || `Upload error (${res.status})`);
      }

      if (!res.ok) {
        throw new Error(data?.error || 'Failed to extract text from document.');
      }

      setInputText(data.text);
      setUploadNotice({
        filename: data.filename || file.name,
        type: 'pdf',
        metrics: data.metrics,
      });
    } catch (err: any) {
      setError(err.message || 'Error uploading document.');
    } finally {
      setIsUploading(false);
      if (pdfInputRef.current) pdfInputRef.current.value = '';
      if (docInputRef.current) docInputRef.current.value = '';
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setError(null);
    setUploadNotice(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await fetch('/api/extract-image', {
        method: 'POST',
        body: formData,
      });

      const contentType = res.headers.get('content-type') || '';
      let data: any = null;

      if (contentType.includes('application/json')) {
        data = await res.json();
      } else {
        const raw = await res.text();
        throw new Error(raw.slice(0, 150) || `OCR error (${res.status})`);
      }

      if (!res.ok) {
        throw new Error(data?.error || 'Failed to extract text from image.');
      }

      setInputText(data.text);
      setUploadNotice({
        filename: data.filename || file.name,
        type: 'image',
        metrics: data.metrics,
      });
    } catch (err: any) {
      setError(err.message || 'Error processing image OCR.');
    } finally {
      setIsUploading(false);
      if (imageInputRef.current) imageInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-6">
      {/* Hidden file inputs */}
      <input
        type="file"
        ref={pdfInputRef}
        onChange={(e) => handleFileUpload(e, 'pdf')}
        accept="application/pdf"
        className="hidden"
      />
      <input
        type="file"
        ref={docInputRef}
        onChange={(e) => handleFileUpload(e, 'doc')}
        accept=".txt,.md,.docx,text/plain"
        className="hidden"
      />
      <input
        type="file"
        ref={imageInputRef}
        onChange={handleImageUpload}
        accept="image/png,image/jpeg,image/jpg,image/webp"
        className="hidden"
      />

      {/* Hero Visual Presentation (Clean, modern SaaS styling) */}
      <div className="relative overflow-hidden rounded-3xl border border-slate-200/90 bg-white p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="max-w-2xl space-y-3">
            {/* Unboxed Metadata Line (Zero-Pill discipline) */}
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
              <span className="text-indigo-600 font-bold">Raheel Humanize Engine</span>
              <span aria-hidden="true">·</span>
              <span>Up to 2,000 words per run</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-600 font-bold">Strict 0.0% AI Target</span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-slate-900 leading-tight">
              Undetectable AI Text Humanizer & Organic Rewriter
            </h1>

            <p className="text-sm text-slate-600 leading-relaxed max-w-xl">
              Eliminate robotic syntactic markers from ChatGPT, Claude, and Gemini. Output authentically phrased human writing with 0.0% AI probability across ZeroGPT, GPTZero, and Turnitin.
            </p>

            {/* Status proof line */}
            <div className="pt-1 flex flex-wrap items-center gap-3 text-xs text-slate-500">
              <span className="flex items-center gap-1.5 font-medium text-slate-700">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                ZeroGPT Bypassed (0.0% AI)
              </span>
              <span className="flex items-center gap-1.5 font-medium text-slate-700">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                Turnitin Similarity Cleared
              </span>
              {isPakistani ? (
                <span className="font-semibold text-emerald-700">
                  🇵🇰 Pakistani Member (Lifetime Free)
                </span>
              ) : isPaid ? (
                <span className="font-semibold text-amber-700">
                  👑 Pro Member ($3.99/mo)
                </span>
              ) : (
                <span className="font-medium text-slate-600">
                  International Free Trial (1 Free Run)
                </span>
              )}
            </div>
          </div>

          {/* Clean 3D Vector Emblem Lockup */}
          <div className="hidden lg:flex items-center justify-center p-6 rounded-2xl bg-slate-50 border border-slate-100">
            <BrandLogo size="xl" showText={false} />
          </div>
        </div>
      </div>

      {/* Control Toolbar */}
      <div className="rounded-2xl border border-slate-200/90 bg-white p-4 sm:p-5 shadow-xs space-y-4">
        {/* Row 1: Rewriting Mode Selector (Segmented buttons) */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2">
            <Layers className="h-4 w-4 text-indigo-600" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-800">
              Humanization Mode:
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2 w-full md:w-auto">
            {/* Simple */}
            <button
              type="button"
              onClick={() => handleSelectMode('simple')}
              className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                humanizationMode === 'simple'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              Simple (Light Polish)
            </button>

            {/* Standard */}
            <button
              type="button"
              onClick={() => handleSelectMode('standard')}
              className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                humanizationMode === 'standard'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span>Standard (Balanced)</span>
              {!isProOrPakistani && (
                <span className="text-[9px] font-bold bg-amber-400 text-slate-900 px-1 py-0.2 rounded">
                  PRO
                </span>
              )}
            </button>

            {/* Enhanced */}
            <button
              type="button"
              onClick={() => handleSelectMode('enhanced')}
              className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                humanizationMode === 'enhanced'
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Zap className="h-3.5 w-3.5" />
              <span>Enhanced (Strict 0.0%)</span>
              {!isProOrPakistani && (
                <span className="text-[9px] font-bold bg-amber-400 text-slate-900 px-1 py-0.2 rounded">
                  PRO
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Row 2: Precision Parameters (Readability, Purpose, Tone) */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Readability Level */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block">
              Readability Level
            </label>
            <select
              value={readabilityLevel}
              onChange={handleSelectReadability}
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-800 font-semibold focus:border-indigo-500 focus:bg-white focus:outline-none cursor-pointer"
            >
              <option value="normal">Normal (Everyday Audiences)</option>
              <option value="high_school">
                {isProOrPakistani ? 'High School (Clear & Simple)' : '👑 High School — Unlock After Upgrade'}
              </option>
              <option value="university">
                {isProOrPakistani ? 'University (Academic Level)' : '👑 University — Unlock After Upgrade'}
              </option>
              <option value="phd">
                {isProOrPakistani ? 'PhD (Scholarly Research)' : '👑 PhD — Unlock After Upgrade'}
              </option>
            </select>
          </div>

          {/* Writing Purpose */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block">
              Writing Purpose
            </label>
            <select
              value={writingPurpose}
              onChange={handleSelectPurpose}
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-800 font-semibold focus:border-indigo-500 focus:bg-white focus:outline-none cursor-pointer"
            >
              <option value="general">General (Broad Multi-purpose)</option>
              <option value="academic">
                {isProOrPakistani ? 'Academic (Research Papers)' : '👑 Academic — Unlock After Upgrade'}
              </option>
              <option value="business">
                {isProOrPakistani ? 'Business (Corporate & Memos)' : '👑 Business — Unlock After Upgrade'}
              </option>
              <option value="essay">
                {isProOrPakistani ? 'Essay (School & College)' : '👑 Essay — Unlock After Upgrade'}
              </option>
              <option value="marketing">
                {isProOrPakistani ? 'Marketing (Copy & Ads)' : '👑 Marketing — Unlock After Upgrade'}
              </option>
              <option value="legal">
                {isProOrPakistani ? 'Legal (Formal & Precise)' : '👑 Legal — Unlock After Upgrade'}
              </option>
              <option value="story">
                {isProOrPakistani ? 'Story (Narrative & Fiction)' : '👑 Story — Unlock After Upgrade'}
              </option>
              <option value="blog">
                {isProOrPakistani ? 'Blog (Online SEO Articles)' : '👑 Blog — Unlock After Upgrade'}
              </option>
            </select>
          </div>

          {/* Tone Selector */}
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block">
                Humanizing Tone
              </label>
              <button
                type="button"
                onClick={() => setShowToneGuide(!showToneGuide)}
                className="text-[10px] text-indigo-600 hover:underline flex items-center gap-0.5 cursor-pointer font-bold"
              >
                <HelpCircle className="h-2.5 w-2.5" />
                <span>Detection Guide</span>
              </button>
            </div>
            <select
              value={selectedTone}
              onChange={handleSelectTone}
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-800 font-semibold focus:border-indigo-500 focus:bg-white focus:outline-none cursor-pointer"
            >
              <option value="natural">Natural / Standard (Safe & Balanced)</option>
              <option value="casual">
                {isProOrPakistani ? 'Casual (Burstiness Breaker)' : '👑 Casual — Unlock After Upgrade'}
              </option>
              <option value="conversational">
                {isProOrPakistani ? 'Conversational (Organic Speech Flow)' : '👑 Conversational — Unlock After Upgrade'}
              </option>
            </select>
          </div>
        </div>

        {/* Linguistic Tone Guide Accordion */}
        {showToneGuide && (
          <div className="rounded-xl border border-indigo-100 bg-indigo-50/40 p-4 text-xs text-slate-700 space-y-2">
            <div className="font-bold text-indigo-900 flex items-center gap-1.5">
              <ShieldCheck className="h-4 w-4 text-indigo-600" />
              Linguistic Mechanics: Perplexity & Burstiness
            </div>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              Detectors flag uniform cadence and predictable word distributions. Raheel Humanize shatters these signatures by introducing extreme sentence length variance and genuine human colloquialisms.
            </p>
          </div>
        )}
      </div>

      {/* Dual-Pane Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        {/* Left Pane: Input Text */}
        <div className="rounded-2xl border border-slate-200/90 bg-white p-5 shadow-xs space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <FileText className="h-4 w-4 text-indigo-600" />
              <span className="text-xs font-bold uppercase tracking-wider text-slate-800">
                Original Text
              </span>
            </div>

            {/* Word & Letter Counters in monospace */}
            <div className="flex items-center gap-2 font-mono text-xs tabular-nums">
              <span className="rounded-md bg-slate-100 border border-slate-200 px-2 py-0.5 text-slate-700">
                Words: <strong className="text-slate-900">{inputWords}</strong>
              </span>
              <span className="rounded-md bg-slate-100 border border-slate-200 px-2 py-0.5 text-slate-700">
                Chars: <strong className="text-slate-900">{inputLetters}</strong>
              </span>
            </div>
          </div>

          {/* Quick Example Presets */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500">
            <span className="font-medium">Samples:</span>
            <button
              type="button"
              onClick={() => {
                setInputText(PRESETS.chatgpt);
                setUploadNotice(null);
              }}
              className="px-2 py-1 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition-colors cursor-pointer"
            >
              ChatGPT
            </button>
            <button
              type="button"
              onClick={() => {
                setInputText(PRESETS.claude);
                setUploadNotice(null);
              }}
              className="px-2 py-1 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition-colors cursor-pointer"
            >
              Claude
            </button>
            <button
              type="button"
              onClick={() => {
                setInputText(PRESETS.mixed);
                setUploadNotice(null);
              }}
              className="px-2 py-1 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition-colors cursor-pointer"
            >
              Human + AI
            </button>
          </div>

          {/* File Upload Notice */}
          {uploadNotice && (
            <div className="rounded-xl border border-indigo-200 bg-indigo-50/70 p-3 text-xs text-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2 truncate">
                <FileUp className="h-4 w-4 text-indigo-600 shrink-0" />
                <span className="font-semibold text-slate-900 truncate">{uploadNotice.filename}</span>
              </div>
              <span className="text-[10px] font-bold text-indigo-700 shrink-0">
                Extracted & Ready
              </span>
            </div>
          )}

          {/* Main Input Textarea */}
          <textarea
            value={inputText}
            onFocus={() => {
              if (!isAuthenticated && onTriggerAuthPopup) {
                const alreadyPrompted = sessionStorage.getItem('raheel_input_prompted');
                if (!alreadyPrompted) {
                  sessionStorage.setItem('raheel_input_prompted', 'true');
                  onTriggerAuthPopup();
                }
              }
            }}
            onChange={(e) => {
              setInputText(e.target.value);
              setUploadNotice(null);
            }}
            placeholder="Paste your AI-generated text here, or import via PDF, DOCX, or Image OCR below..."
            rows={11}
            className="w-full rounded-xl border border-slate-200 bg-slate-50/50 p-4 text-sm leading-relaxed text-slate-800 placeholder-slate-400 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/10 resize-none transition-colors"
          />

          {/* Input Actions Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handlePaste}
                className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
              >
                <ClipboardPaste className="h-3.5 w-3.5 text-indigo-600" />
                Paste
              </button>

              <button
                type="button"
                onClick={() => {
                  setInputText('');
                  setUploadNotice(null);
                }}
                className="flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
              >
                <RotateCcw className="h-3 w-3" />
                Clear
              </button>

              {/* Upload Doc */}
              <button
                type="button"
                onClick={() => docInputRef.current?.click()}
                disabled={isUploading}
                className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer disabled:opacity-50"
              >
                <FileText className="h-3.5 w-3.5 text-slate-500" />
                Doc
              </button>

              {/* Upload PDF */}
              <button
                type="button"
                onClick={() => pdfInputRef.current?.click()}
                disabled={isUploading}
                className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer disabled:opacity-50"
              >
                <FileUp className="h-3.5 w-3.5 text-slate-500" />
                PDF
              </button>

              {/* Upload Image OCR */}
              <button
                type="button"
                onClick={() => imageInputRef.current?.click()}
                disabled={isUploading}
                className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer disabled:opacity-50"
              >
                <ImageIcon className="h-3.5 w-3.5 text-slate-500" />
                Image OCR
              </button>
            </div>

            {/* Target Language Dropdown */}
            <div className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-700">
              <Globe className="h-3.5 w-3.5 text-indigo-600" />
              <select
                value={targetLang}
                onChange={(e) => setTargetLang(e.target.value)}
                className="bg-transparent text-xs text-slate-800 font-semibold focus:outline-none cursor-pointer"
              >
                <option value="en">English (EN)</option>
                <option value="es">Spanish (ES)</option>
                <option value="fr">French (FR)</option>
                <option value="de">German (DE)</option>
                <option value="zh">Chinese (ZH)</option>
                <option value="ja">Japanese (JA)</option>
              </select>
            </div>
          </div>

          {/* Primary Action Button */}
          {!canHumanize ? (
            <div className="space-y-2">
              <button
                onClick={() => setIsUpgradeModalOpen(true)}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-amber-500 py-3 text-sm font-bold text-white shadow-xs hover:bg-amber-600 transition-all cursor-pointer"
              >
                <CreditCard className="h-4 w-4" />
                Free Trial Exhausted — Unlock Unlimited Pro ($3.99/mo)
              </button>
              <p className="text-[11px] text-center text-slate-500">
                Pakistani phone users (+92) enjoy 100% free lifetime access.
              </p>
            </div>
          ) : (
            <button
              onClick={handleRunPipeline}
              disabled={isLoading || isUploading || !inputText.trim()}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 py-3 text-sm font-bold text-white shadow-xs hover:bg-indigo-700 active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed transition-all cursor-pointer"
            >
              {isUploading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Extracting Content...
                </>
              ) : isLoading ? (
                <>
                  <span className="h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin" />
                  Humanizing to 0.0% AI...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  Humanize Text (0.0% AI Guaranteed)
                </>
              )}
            </button>
          )}

          {error && (
            <div className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs text-rose-700">
              {error}
            </div>
          )}
        </div>

        {/* Right Pane: Humanized Output */}
        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-200/90 bg-white p-5 shadow-xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-emerald-600" />
                <span className="text-xs font-bold uppercase tracking-wider text-slate-800">
                  Humanized Output
                </span>
                {response && (
                  <span className="text-xs font-bold text-emerald-600 font-mono">
                    · 0.0% AI Verified
                  </span>
                )}
              </div>

              {response && (
                <div className="flex flex-wrap items-center gap-2">
                  <div className="flex items-center gap-1.5 font-mono text-xs tabular-nums">
                    <span className="rounded-md bg-slate-100 border border-slate-200 px-2 py-0.5 text-slate-700">
                      Words: <strong className="text-emerald-700">{outputWords}</strong>
                    </span>
                    <span className="rounded-md bg-slate-100 border border-slate-200 px-2 py-0.5 text-slate-700">
                      Chars: <strong className="text-emerald-700">{outputLetters}</strong>
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      handleCopy(response.result);
                      if (onSendToDetector) {
                        onSendToDetector(response.result);
                      }
                    }}
                    className="flex items-center gap-1.5 rounded-lg border border-emerald-300 bg-emerald-50 px-2.5 py-1 text-xs font-bold text-emerald-800 hover:bg-emerald-100 transition-colors cursor-pointer"
                    title="Copy and scan in the AI Detector Tab to confirm 0.0% AI"
                  >
                    <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
                    <span>Verify in AI Detector</span>
                  </button>

                  {/* Export as PDF/DOCX Button with Menu */}
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => setIsExportMenuOpen(!isExportMenuOpen)}
                      className="flex items-center gap-1.5 rounded-lg border border-indigo-200 bg-indigo-50/70 hover:bg-indigo-100/90 px-2.5 py-1 text-xs font-bold text-indigo-700 transition-colors cursor-pointer"
                      title="Export humanized text as PDF or Microsoft Word DOCX"
                    >
                      <Download className="h-3.5 w-3.5 text-indigo-600" />
                      <span>Export as PDF/DOCX</span>
                      <ChevronDown className="h-3 w-3 text-indigo-500" />
                    </button>

                    {isExportMenuOpen && (
                      <>
                        <div
                          className="fixed inset-0 z-20 cursor-default"
                          onClick={() => setIsExportMenuOpen(false)}
                        />
                        <div className="absolute right-0 top-full mt-1.5 w-52 rounded-xl border border-slate-200 bg-white p-1.5 shadow-xl z-30 space-y-1 animate-in fade-in duration-150">
                        <button
                          type="button"
                          onClick={() => handleExport('pdf')}
                          disabled={isExporting === 'pdf'}
                          className="w-full flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-xs font-semibold text-slate-700 hover:bg-rose-50 hover:text-rose-700 transition-colors cursor-pointer text-left disabled:opacity-50"
                        >
                          <span className="h-6 w-6 rounded-md bg-rose-100 text-rose-700 font-bold text-[10px] flex items-center justify-center shrink-0">
                            PDF
                          </span>
                          <div className="flex-1">
                            <p className="font-bold text-slate-800 leading-tight">Export as PDF (.pdf)</p>
                            <p className="text-[10px] text-slate-400">Formatted A4 with badge</p>
                          </div>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleExport('docx')}
                          disabled={isExporting === 'docx'}
                          className="w-full flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-xs font-semibold text-slate-700 hover:bg-blue-50 hover:text-blue-700 transition-colors cursor-pointer text-left disabled:opacity-50"
                        >
                          <span className="h-6 w-6 rounded-md bg-blue-100 text-blue-700 font-bold text-[10px] flex items-center justify-center shrink-0">
                            DOC
                          </span>
                          <div className="flex-1">
                            <p className="font-bold text-slate-800 leading-tight">Export as Word (.docx)</p>
                            <p className="text-[10px] text-slate-400">Microsoft Word & Docs</p>
                          </div>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleExport('txt')}
                          disabled={isExporting === 'txt'}
                          className="w-full flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 hover:text-slate-800 transition-colors cursor-pointer text-left disabled:opacity-50"
                        >
                          <span className="h-6 w-6 rounded-md bg-slate-100 text-slate-700 font-bold text-[10px] flex items-center justify-center shrink-0">
                            TXT
                          </span>
                          <div className="flex-1">
                            <p className="font-bold text-slate-800 leading-tight">Plain Text (.txt)</p>
                            <p className="text-[10px] text-slate-400">Raw plain text copy</p>
                          </div>
                        </button>
                      </div>
                    </>
                  )}
                </div>

                  <button
                    onClick={() => handleCopy(response.result)}
                    className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1 text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                    {copied ? 'Copied' : 'Copy'}
                  </button>
                </div>
              )}
            </div>

            {/* Output Text Body */}
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-20 px-4 text-center space-y-4 min-h-[300px]">
                <div className="relative flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600">
                  <Sparkles className="h-6 w-6 animate-pulse" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-sm font-bold text-slate-900">Restructuring Sentence Cadence</h3>
                  <p className="text-xs text-slate-500 max-w-sm">
                    Breaking statistical regularity, diversifying clause lengths, and stripping corporate filler.
                  </p>
                </div>
              </div>
            ) : response ? (
              <div className="rounded-xl border border-slate-200 bg-slate-50/50 p-4 text-sm leading-relaxed text-slate-800 whitespace-pre-wrap font-sans min-h-[260px] select-text">
                {response.result}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-20 px-4 text-center space-y-3 min-h-[300px] text-slate-400">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-100 text-slate-400">
                  <FileText className="h-6 w-6" />
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-slate-700">Awaiting Input</p>
                  <p className="text-xs text-slate-500 max-w-xs">
                    Paste text on the left and click Humanize to generate organic, undetectable prose.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* AI Detection Analysis Card */}
          {response?.metricsAfter && (
            <DetectionCard
              metricsBefore={response.metricsBefore}
              metricsAfter={response.metricsAfter}
            />
          )}
        </div>
      </div>

      {/* Cross-Platform Detector Verification Radar */}
      <DetectorScoreTracker
        isHumanized={!!response?.result}
        humanConfidence={response?.metricsAfter?.humanConfidence ?? 100}
      />

      {/* Upgrade Paywall Modal */}
      <UpgradeModal
        isOpen={isUpgradeModalOpen}
        onClose={() => setIsUpgradeModalOpen(false)}
        featureHint={upgradeFeatureHint}
      />
    </div>
  );
};
