import React, { useState } from 'react';
import {
  X,
  Server,
  CheckCircle2,
  Copy,
  Check,
  ExternalLink,
  Terminal,
  ShieldCheck,
  FileCode,
  FolderArchive,
  Layers,
  ArrowRight,
} from 'lucide-react';

interface HostingerDeployModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HostingerDeployModal: React.FC<HostingerDeployModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeOption, setActiveOption] = useState<'nodejs' | 'static' | 'vps'>('nodejs');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl rounded-3xl border border-slate-200 bg-white p-6 sm:p-8 shadow-2xl space-y-6 max-h-[92vh] overflow-y-auto">
        {/* Dismiss Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 rounded-full p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-800 transition-colors cursor-pointer"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Modal Header */}
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-2xl bg-[#673DE6] flex items-center justify-center text-white shadow-md shadow-[#673DE6]/25">
              <Server className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight text-slate-900">
                  Host on Hostinger
                </h2>
                <span className="rounded-full bg-[#673DE6]/10 text-[#673DE6] border border-[#673DE6]/30 px-2.5 py-0.5 text-[10px] font-bold uppercase">
                  Ready to Deploy
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Complete deployment package prepared: `.htaccess`, `ecosystem.config.cjs`, and dynamic port support configured.
              </p>
            </div>
          </div>
        </div>

        {/* Deployment Method Switcher */}
        <div className="grid grid-cols-3 gap-2 rounded-2xl border border-slate-200 bg-slate-100 p-1">
          <button
            type="button"
            onClick={() => setActiveOption('nodejs')}
            className={`rounded-xl py-2 px-3 text-xs font-bold transition-all cursor-pointer text-center ${
              activeOption === 'nodejs'
                ? 'bg-white text-[#673DE6] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>Option 1: Node.js (hPanel)</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveOption('static')}
            className={`rounded-xl py-2 px-3 text-xs font-bold transition-all cursor-pointer text-center ${
              activeOption === 'static'
                ? 'bg-white text-[#673DE6] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>Option 2: Shared (.htaccess)</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveOption('vps')}
            className={`rounded-xl py-2 px-3 text-xs font-bold transition-all cursor-pointer text-center ${
              activeOption === 'vps'
                ? 'bg-white text-[#673DE6] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>Option 3: VPS (Nginx + PM2)</span>
          </button>
        </div>

        {/* Content Panel */}
        {activeOption === 'nodejs' && (
          <div className="space-y-4 text-xs">
            <div className="rounded-2xl border border-purple-100 bg-purple-50/60 p-4 space-y-2">
              <span className="font-bold text-[#673DE6] block text-sm">
                Recommended: Hostinger Cloud & Business Web Hosting (Node.js App)
              </span>
              <p className="text-slate-600 leading-relaxed">
                Hostinger's built-in Node.js feature executes your Express backend and serves the React frontend together seamlessly on your custom domain.
              </p>
            </div>

            <div className="space-y-3">
              {/* Step 1 */}
              <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
                <div className="flex items-center gap-2 font-bold text-slate-800">
                  <span className="h-5 w-5 rounded-full bg-slate-900 text-white text-[11px] flex items-center justify-center font-mono">1</span>
                  <span>Upload Files via Hostinger File Manager</span>
                </div>
                <p className="text-slate-600 pl-7">
                  Log in to <strong>hPanel → Websites → File Manager</strong>. Upload the project files into your domain directory. You do not need to upload `node_modules` (they install automatically).
                </p>
              </div>

              {/* Step 2 */}
              <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
                <div className="flex items-center gap-2 font-bold text-slate-800">
                  <span className="h-5 w-5 rounded-full bg-slate-900 text-white text-[11px] flex items-center justify-center font-mono">2</span>
                  <span>Configure Node.js in Hostinger hPanel</span>
                </div>
                <div className="pl-7 space-y-2">
                  <p className="text-slate-600">
                    Go to <strong>Advanced → Node.js</strong> in hPanel and set:
                  </p>
                  <ul className="list-disc list-inside space-y-1 text-slate-700 bg-white p-3 rounded-lg border border-slate-200 font-mono text-[11px]">
                    <li><strong>Node.js version:</strong> 18.x or 20.x</li>
                    <li><strong>Application root:</strong> /</li>
                    <li><strong>Application startup file:</strong> server.js (or app.js or index.js)</li>
                    <li><strong>Environment:</strong> Production</li>
                  </ul>
                  <p className="text-[11px] text-emerald-700 font-semibold bg-emerald-50 p-2 rounded-lg border border-emerald-200">
                    ✓ Pre-compiled `server.js`, `app.js`, and `index.js` are included to eliminate any "Entry file not found" errors!
                  </p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
                <div className="flex items-center gap-2 font-bold text-slate-800">
                  <span className="h-5 w-5 rounded-full bg-slate-900 text-white text-[11px] flex items-center justify-center font-mono">3</span>
                  <span>Set Environment Variables & Run Build</span>
                </div>
                <div className="pl-7 space-y-2">
                  <p className="text-slate-600">
                    In the Node.js settings, add your Gemini API Key in <strong>Environment Variables</strong>:
                  </p>
                  <div className="flex items-center justify-between bg-slate-900 text-emerald-400 p-2.5 rounded-lg font-mono text-[11px]">
                    <span>GEMINI_API_KEY=your_key_here</span>
                    <button
                      onClick={() => handleCopy('GEMINI_API_KEY=your_key_here', 'env')}
                      className="text-white hover:text-slate-300 cursor-pointer"
                    >
                      {copiedKey === 'env' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                    </button>
                  </div>
                  <p className="text-slate-600">
                    In the hPanel Console / Terminal, run:
                  </p>
                  <div className="flex items-center justify-between bg-slate-900 text-slate-100 p-2.5 rounded-lg font-mono text-[11px]">
                    <span>npm install && npm run build</span>
                    <button
                      onClick={() => handleCopy('npm install && npm run build', 'build_cmd')}
                      className="text-white hover:text-slate-300 cursor-pointer"
                    >
                      {copiedKey === 'build_cmd' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                    </button>
                  </div>
                </div>
              </div>

              {/* Step 4 */}
              <div className="p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/70 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0" />
                  <span className="font-bold text-emerald-900">
                    Click "Start Application" in hPanel — your website is immediately live!
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeOption === 'static' && (
          <div className="space-y-4 text-xs">
            <div className="rounded-2xl border border-blue-100 bg-blue-50/60 p-4 space-y-1">
              <span className="font-bold text-blue-900 block text-sm">
                Hostinger Shared Hosting (public_html with .htaccess)
              </span>
              <p className="text-slate-600 leading-relaxed">
                If you have Hostinger Shared Hosting (Premium or Single), upload the pre-built static bundle with the pre-configured `.htaccess` file.
              </p>
            </div>

            <div className="space-y-2">
              <p className="font-bold text-slate-800">Steps to deploy static build:</p>
              <ol className="list-decimal list-inside space-y-2 text-slate-700 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <li>Run <strong>npm run build</strong> to compile the production bundle into <strong>dist/</strong>.</li>
                <li>The `.htaccess` file (with SPA routing and Gzip compression) is automatically copied into <strong>dist/</strong>.</li>
                <li>In Hostinger hPanel File Manager, open your domain's <strong>public_html</strong> directory.</li>
                <li>Upload all contents from the <strong>dist/</strong> folder into <strong>public_html</strong>.</li>
                <li>Your website opens with instant speed and zero 404 page refresh errors.</li>
              </ol>
            </div>
          </div>
        )}

        {activeOption === 'vps' && (
          <div className="space-y-4 text-xs">
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 space-y-2">
              <span className="font-bold text-slate-900 block text-sm">
                Hostinger VPS (Ubuntu + PM2 + Nginx)
              </span>
              <p className="text-slate-600">
                The included `ecosystem.config.cjs` manages your app process with auto-restart and zero downtime on Hostinger VPS.
              </p>
            </div>

            <div className="space-y-2">
              <span className="font-bold text-slate-700 block">Deploy Commands:</span>
              <div className="bg-slate-950 text-slate-100 p-4 rounded-xl font-mono text-[11px] space-y-2 overflow-x-auto">
                <p className="text-slate-400"># 1. Install & Build</p>
                <p>npm install && npm run build</p>
                <p className="text-slate-400"># 2. Start with PM2</p>
                <p>npm install -g pm2</p>
                <p>pm2 start ecosystem.config.cjs</p>
                <p>pm2 save</p>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-1.5 text-slate-500">
            <FileCode className="h-4 w-4 text-[#673DE6]" />
            <span>Full instructions saved in <strong>HOSTINGER_DEPLOYMENT_GUIDE.md</strong></span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-slate-900 text-white font-bold px-5 py-2 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
