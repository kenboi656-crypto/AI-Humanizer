import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { LoginForm } from './auth/LoginForm';
import { SignupForm } from './auth/SignupForm';
import { ForgotPasswordForm } from './auth/ForgotPasswordForm';
import { EmailVerification } from './auth/EmailVerification';
import { BrandLogo } from './BrandLogo';
import { X, CheckCircle2 } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'signup';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'login',
}) => {
  const {
    firebaseUser,
    isEmailVerified,
    signIn,
    signUp,
    signInWithGoogle,
    sendPasswordReset,
    resendEmailVerification,
    refreshAuthState,
    logout,
  } = useAuth();

  const [mode, setMode] = useState<'login' | 'signup' | 'forgot' | 'verify'>(initialMode);

  if (!isOpen) return null;

  const handleLoginSubmit = async (email: string, pass: string, _remember: boolean) => {
    await signIn(email, pass);
    onClose();
  };

  const handleGoogleSubmit = async () => {
    await signInWithGoogle();
    onClose();
  };

  const handleSignupSubmit = async (name: string, email: string, pass: string) => {
    await signUp(name, email, pass);
    setMode('verify');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/50 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="relative w-full max-w-md rounded-3xl border border-slate-200/90 bg-white p-6 sm:p-8 shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          aria-label="Close authentication modal"
          className="absolute right-4 top-4 rounded-xl p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors cursor-pointer"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Modal Brand Lockup */}
        <div className="text-center space-y-2 mb-6">
          <div className="flex justify-center">
            <BrandLogo size="md" showText={false} />
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            {mode === 'login' && 'Sign In to Your Account'}
            {mode === 'signup' && 'Create Your Free Account'}
            {mode === 'forgot' && 'Reset Account Password'}
            {mode === 'verify' && 'Verify Your Email'}
          </h2>
          <p className="text-xs text-slate-500 max-w-xs mx-auto">
            {mode === 'login' && 'Access Raheel Humanize Text with 0.0% AI guarantee.'}
            {mode === 'signup' && 'Get instant access to authentic human prose rewriter.'}
            {mode === 'forgot' && "Enter your email to receive a password reset link."}
            {mode === 'verify' && 'Confirm your email to complete registration.'}
          </p>
        </div>

        {/* Views */}
        {mode === 'login' && (
          <LoginForm
            onLogin={handleLoginSubmit}
            onGoogleLogin={handleGoogleSubmit}
            onSwitchToSignup={() => setMode('signup')}
            onSwitchToForgot={() => setMode('forgot')}
          />
        )}

        {mode === 'signup' && (
          <SignupForm
            onSignup={handleSignupSubmit}
            onGoogleLogin={handleGoogleSubmit}
            onSwitchToLogin={() => setMode('login')}
          />
        )}

        {mode === 'forgot' && (
          <ForgotPasswordForm
            onSendResetEmail={sendPasswordReset}
            onSwitchToLogin={() => setMode('login')}
          />
        )}

        {mode === 'verify' && (
          <EmailVerification
            email={firebaseUser?.email || ''}
            isVerified={isEmailVerified}
            onResend={resendEmailVerification}
            onCheckStatus={refreshAuthState}
            onLogout={logout}
            onProceed={onClose}
          />
        )}
      </div>
    </div>
  );
};
