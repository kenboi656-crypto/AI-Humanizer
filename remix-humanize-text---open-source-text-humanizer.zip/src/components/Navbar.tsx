import React from 'react';
import { Crown, Sparkles, LogIn, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { BrandLogo } from './BrandLogo';

export type NavTab = 'pipeline' | 'detector' | 'image-detector' | 'youtube' | 'translator' | 'auth';

interface NavbarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  onOpenToolsCenter?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, onOpenToolsCenter }) => {
  const { user, isAuthenticated } = useAuth();
  const isPakistani = user ? user.countryCode === '+92' || user.isPakistani : false;
  const isPaid = user?.hasPaid || user?.plan === 'pro';

  return (
    <header className="sticky top-0 z-30 w-full border-b border-slate-200/80 bg-white/80 backdrop-blur-md transition-all duration-200">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        {/* Zone 1: Single element brand mark */}
        <div
          onClick={() => setActiveTab('pipeline')}
          className="flex items-center gap-3 cursor-pointer select-none group"
        >
          <BrandLogo size="sm" showText={true} />
        </div>

        {/* Zone 2: Navigation Links (Clean text links with hover indicators, single-line) */}
        <nav className="hidden lg:flex items-center gap-1 bg-slate-100/70 p-1 rounded-xl border border-slate-200/60">
          <button
            onClick={() => setActiveTab('pipeline')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'pipeline'
                ? 'bg-white text-indigo-600 shadow-xs shadow-slate-200/50'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            Humanizer
          </button>

          <button
            onClick={() => setActiveTab('detector')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'detector'
                ? 'bg-white text-indigo-600 shadow-xs shadow-slate-200/50'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            Text Detector
          </button>

          <button
            onClick={() => setActiveTab('image-detector')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'image-detector'
                ? 'bg-white text-indigo-600 shadow-xs shadow-slate-200/50'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            Image AI Detector
          </button>

          <button
            onClick={() => setActiveTab('youtube')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'youtube'
                ? 'bg-white text-indigo-600 shadow-xs shadow-slate-200/50'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            YouTube Summarizer
          </button>

          <button
            onClick={() => setActiveTab('translator')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'translator'
                ? 'bg-white text-indigo-600 shadow-xs shadow-slate-200/50'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            Doc Translator
          </button>

          {onOpenToolsCenter && (
            <button
              onClick={onOpenToolsCenter}
              className="px-3.5 py-1.5 text-xs font-semibold rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-white/50 transition-all whitespace-nowrap cursor-pointer"
            >
              All Tools
            </button>
          )}
        </nav>

        {/* Zone 3: Actions & Account Status */}
        <div className="flex items-center gap-3">
          {/* Trust Marker: 0.0% Bypass */}
          <div className="hidden xl:flex items-center gap-1.5 text-xs text-slate-500 font-medium">
            <span className="flex h-2 w-2 rounded-full bg-emerald-500" />
            <span className="tabular-nums">0.0%</span> AI Detection Rate
          </div>

          {/* User Account / Sign In */}
          {isAuthenticated && user ? (
            <div className="flex items-center gap-2">
              {isPakistani ? (
                <div className="hidden sm:inline-flex items-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50/80 px-2.5 py-1 text-xs font-semibold text-emerald-800">
                  <span className="text-sm">🇵🇰</span>
                  <span className="whitespace-nowrap">Pakistan Lifetime Free</span>
                </div>
              ) : isPaid ? (
                <div className="hidden sm:inline-flex items-center gap-1.5 rounded-lg border border-amber-200 bg-amber-50/80 px-2.5 py-1 text-xs font-semibold text-amber-800">
                  <Crown className="h-3.5 w-3.5 text-amber-600" />
                  <span className="whitespace-nowrap">Pro Active</span>
                </div>
              ) : null}

              <button
                onClick={() => setActiveTab('auth')}
                className={`flex items-center gap-2 rounded-xl border p-1.5 sm:px-3 sm:py-1.5 text-xs font-medium transition-all cursor-pointer ${
                  activeTab === 'auth'
                    ? 'border-indigo-500 bg-indigo-50/60 text-indigo-700'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 shadow-2xs'
                }`}
                title="Account Settings"
              >
                <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-gradient-to-br from-indigo-600 to-purple-600 text-white text-xs font-bold shadow-xs">
                  {user.name.charAt(0).toUpperCase()}
                </div>
                <div className="hidden sm:flex flex-col text-left">
                  <span className="font-semibold text-slate-800 leading-tight truncate max-w-[100px]">
                    {user.name.split(' ')[0]}
                  </span>
                  <span className="text-[10px] text-slate-500 leading-tight">
                    {isPakistani ? 'Lifetime Free' : isPaid ? 'Pro Plan' : 'Free Trial'}
                  </span>
                </div>
              </button>
            </div>
          ) : (
            <button
              onClick={() => setActiveTab('auth')}
              className="flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-slate-800 active:scale-[0.98] transition-all cursor-pointer whitespace-nowrap"
            >
              <LogIn className="h-3.5 w-3.5" />
              <span>Sign In</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
