import React from 'react';
import {
  PanelLeftClose,
  PanelLeftOpen,
  Sparkles,
  ShieldCheck,
  ImageIcon,
  Youtube,
  Languages,
  LayoutGrid,
  Crown,
  Terminal,
  Puzzle,
  User,
  ExternalLink,
  Server,
} from 'lucide-react';
import { NavTab } from './Navbar';
import { useAuth } from '../context/AuthContext';
import { BrandLogo } from './BrandLogo';

interface SidebarProps {
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onOpenToolsCenter: () => void;
  onOpenUpgradeModal: () => void;
  onOpenApiConsole: () => void;
  onOpenPlugins: () => void;
  onOpenHostingerModal?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isCollapsed,
  onToggleCollapse,
  activeTab,
  onSelectTab,
  onOpenToolsCenter,
  onOpenUpgradeModal,
  onOpenApiConsole,
  onOpenPlugins,
  onOpenHostingerModal,
}) => {
  const { user, isAuthenticated } = useAuth();
  const isPakistani = user ? user.countryCode === '+92' || user.isPakistani : false;
  const isPaid = user?.hasPaid || user?.plan === 'pro';

  return (
    <aside
      className={`fixed top-0 left-0 z-40 h-screen border-r border-slate-200/80 bg-white/95 backdrop-blur-md transition-all duration-300 flex flex-col justify-between ${
        isCollapsed ? 'w-20' : 'w-64'
      }`}
    >
      {/* Brand Header */}
      <div className="border-b border-slate-100 p-4">
        <div className="flex items-center justify-between">
          <div
            onClick={() => onSelectTab('pipeline')}
            className={`flex items-center cursor-pointer overflow-hidden ${
              isCollapsed ? 'justify-center w-full' : 'gap-3'
            }`}
          >
            <BrandLogo size={isCollapsed ? 'sm' : 'sm'} showText={!isCollapsed} />
          </div>

          {!isCollapsed && (
            <button
              onClick={onToggleCollapse}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 transition-colors cursor-pointer"
              title="Collapse Sidebar"
            >
              <PanelLeftClose className="h-4 w-4" />
            </button>
          )}
        </div>

        {isCollapsed && (
          <div className="mt-2 flex justify-center">
            <button
              onClick={onToggleCollapse}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 transition-colors cursor-pointer"
              title="Expand Sidebar"
            >
              <PanelLeftOpen className="h-4 w-4" />
            </button>
          </div>
        )}
      </div>

      {/* Navigation Groups */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
        {/* Core Capabilities */}
        <div className="space-y-1">
          {!isCollapsed && (
            <span className="px-3 text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
              Core Capabilities
            </span>
          )}

          <button
            onClick={() => onSelectTab('pipeline')}
            className={`w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'pipeline'
                ? 'bg-indigo-600 text-white shadow-xs shadow-indigo-600/30'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            } ${isCollapsed ? 'justify-center px-0' : ''}`}
            title="Text Humanizer"
          >
            <Sparkles className={`h-4 w-4 shrink-0 ${activeTab === 'pipeline' ? 'text-white' : 'text-indigo-600'}`} />
            {!isCollapsed && <span>Text Humanizer</span>}
          </button>

          <button
            onClick={() => onSelectTab('detector')}
            className={`w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'detector'
                ? 'bg-indigo-600 text-white shadow-xs shadow-indigo-600/30'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            } ${isCollapsed ? 'justify-center px-0' : ''}`}
            title="AI Text Detector"
          >
            <ShieldCheck className={`h-4 w-4 shrink-0 ${activeTab === 'detector' ? 'text-white' : 'text-emerald-600'}`} />
            {!isCollapsed && <span>AI Text Detector</span>}
          </button>

          <button
            onClick={() => onSelectTab('image-detector')}
            className={`w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'image-detector'
                ? 'bg-indigo-600 text-white shadow-xs shadow-indigo-600/30'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            } ${isCollapsed ? 'justify-center px-0' : ''}`}
            title="Image AI Detector"
          >
            <ImageIcon className={`h-4 w-4 shrink-0 ${activeTab === 'image-detector' ? 'text-white' : 'text-purple-600'}`} />
            {!isCollapsed && <span>Image AI Detector</span>}
          </button>
        </div>

        {/* Intelligence Tools */}
        <div className="space-y-1">
          {!isCollapsed && (
            <span className="px-3 text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
              Intelligence Suite
            </span>
          )}

          <button
            onClick={() => onSelectTab('youtube')}
            className={`w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'youtube'
                ? 'bg-indigo-600 text-white shadow-xs shadow-indigo-600/30'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            } ${isCollapsed ? 'justify-center px-0' : ''}`}
            title="YouTube Summarizer"
          >
            <Youtube className={`h-4 w-4 shrink-0 ${activeTab === 'youtube' ? 'text-white' : 'text-rose-500'}`} />
            {!isCollapsed && <span>YouTube Summarizer</span>}
          </button>

          <button
            onClick={() => onSelectTab('translator')}
            className={`w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'translator'
                ? 'bg-indigo-600 text-white shadow-xs shadow-indigo-600/30'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            } ${isCollapsed ? 'justify-center px-0' : ''}`}
            title="Doc Translator"
          >
            <Languages className={`h-4 w-4 shrink-0 ${activeTab === 'translator' ? 'text-white' : 'text-sky-600'}`} />
            {!isCollapsed && <span>Doc Translator</span>}
          </button>

          <button
            onClick={onOpenToolsCenter}
            className={`w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-all cursor-pointer ${
              isCollapsed ? 'justify-center px-0' : ''
            }`}
            title="All Tools Hub"
          >
            <LayoutGrid className="h-4 w-4 text-indigo-500 shrink-0" />
            {!isCollapsed && <span>Tools Hub (8+ Tools)</span>}
          </button>
        </div>

        {/* Developer & Ecosystem */}
        <div className="space-y-1">
          {!isCollapsed && (
            <span className="px-3 text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
              Developers & Extensions
            </span>
          )}

          <button
            onClick={onOpenApiConsole}
            className={`w-full flex items-center gap-3 rounded-xl px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer ${
              isCollapsed ? 'justify-center px-0' : ''
            }`}
            title="REST API Console"
          >
            <Terminal className="h-4 w-4 text-slate-500 shrink-0" />
            {!isCollapsed && <span>API Console</span>}
          </button>

          <button
            onClick={onOpenPlugins}
            className={`w-full flex items-center gap-3 rounded-xl px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer ${
              isCollapsed ? 'justify-center px-0' : ''
            }`}
            title="Browser Plugins & Integrations"
          >
            <Puzzle className="h-4 w-4 text-slate-500 shrink-0" />
            {!isCollapsed && <span>Plugins & Webhook</span>}
          </button>

          {onOpenHostingerModal && (
            <button
              onClick={onOpenHostingerModal}
              className={`w-full flex items-center gap-3 rounded-xl px-3 py-2 text-xs font-bold text-[#673DE6] bg-purple-50/70 hover:bg-purple-100 transition-colors cursor-pointer border border-purple-200/60 ${
                isCollapsed ? 'justify-center px-0' : ''
              }`}
              title="Hostinger Cloud / Web Hosting Guide"
            >
              <Server className="h-4 w-4 text-[#673DE6] shrink-0" />
              {!isCollapsed && <span>Host on Hostinger</span>}
            </button>
          )}
        </div>
      </div>

      {/* Bottom Footer Section */}
      <div className="border-t border-slate-100 p-3 space-y-2 bg-slate-50/70">
        {/* Pro Plan Card / Upgrade */}
        <button
          onClick={onOpenUpgradeModal}
          className={`w-full flex items-center gap-3 rounded-xl p-2.5 text-xs font-semibold transition-all cursor-pointer ${
            isPaid || isPakistani
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-200/70 text-amber-900 hover:bg-amber-500/15'
          } ${isCollapsed ? 'justify-center p-2' : ''}`}
          title={isPakistani ? 'Pakistani Lifetime Free' : isPaid ? 'Pro Membership Active' : 'Upgrade to Pro'}
        >
          <Crown className={`h-4 w-4 shrink-0 ${isPakistani ? 'text-emerald-600' : 'text-amber-600'}`} />
          {!isCollapsed && (
            <div className="flex items-center justify-between w-full">
              <span className="truncate">
                {isPakistani ? 'Pakistan Free Tier' : isPaid ? 'Pro Active' : 'Upgrade Pro'}
              </span>
              <span className="rounded-md bg-white px-1.5 py-0.5 text-[10px] font-bold text-slate-700 shadow-2xs">
                {isPakistani ? '🇵🇰' : isPaid ? 'PRO' : '$3.99'}
              </span>
            </div>
          )}
        </button>

        {/* User Account Button */}
        <button
          onClick={() => onSelectTab('auth')}
          className={`w-full flex items-center gap-3 rounded-xl px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer ${
            activeTab === 'auth' ? 'bg-slate-200/60 font-semibold' : ''
          } ${isCollapsed ? 'justify-center px-0' : ''}`}
          title={isAuthenticated && user ? `Account: ${user.name}` : 'Sign In'}
        >
          {isAuthenticated && user ? (
            <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-slate-900 text-white text-[10px] font-bold">
              {user.name.charAt(0).toUpperCase()}
            </div>
          ) : (
            <User className="h-4 w-4 text-slate-500 shrink-0" />
          )}
          {!isCollapsed && (
            <span className="truncate">
              {isAuthenticated && user ? user.name.split(' ')[0] : 'Sign In / Register'}
            </span>
          )}
        </button>
      </div>
    </aside>
  );
};
