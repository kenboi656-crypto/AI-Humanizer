import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Check,
  Sparkles,
  X,
  CreditCard,
  Lock,
  Building,
  User,
  ShieldCheck,
  Zap,
  CheckCircle2,
  HelpCircle,
  Clock,
  ArrowRight,
  Copy,
  ExternalLink,
  Smartphone,
  Wallet,
  Send,
} from 'lucide-react';
import { doc, setDoc } from 'firebase/firestore';
import { db, auth } from '../services/firebase';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  featureHint?: string;
}

export const UpgradeModal: React.FC<UpgradeModalProps> = ({ isOpen, onClose, featureHint }) => {
  const { upgradePlan, user } = useAuth();
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annually'>('monthly');
  const [isProcessing, setIsProcessing] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState<'plans' | 'checkout'>('plans');
  const [selectedPlanForCheckout, setSelectedPlanForCheckout] = useState<'pro' | 'enterprise'>('pro');
  const [paymentMethod, setPaymentMethod] = useState<'sadapay' | 'card' | 'paypal' | 'gpay'>('sadapay');
  const [activationSuccess, setActivationSuccess] = useState(false);

  // SadaPay Receiver Details
  const sadapayDetails = {
    accountTitle: 'Raheel Niaz',
    accountNumber: '03000358949',
    bankType: 'SadaPay',
    bankFullName: 'SadaPay (Microfinance Bank / EMI)',
    iban: 'PK00SADA00000003000358949',
    whatsappNumber: '923000358949',
  };

  // SadaPay Sender Input State
  const [transactionId, setTransactionId] = useState('');
  const [senderName, setSenderName] = useState('');
  const [copiedField, setCopiedField] = useState<'number' | 'title' | 'iban' | null>(null);

  if (!isOpen) return null;

  const isPakistani = user ? user.countryCode === '+92' || user.isPakistani : false;
  const currentPlan = user?.plan || 'free';

  // Pricing Matrix with exact limits, billing, and PKR equivalents
  const pricing = {
    pro: {
      name: 'Pro Scholar & Student',
      monthlyPrice: '$4.99',
      annualMonthlyEquiv: '$2.99',
      annualTotal: '$35.88',
      monthlyPkr: 'Rs. 1,400 PKR',
      annualPkr: 'Rs. 9,900 PKR',
      monthlyPeriod: 'Billed monthly · Cancel anytime',
      annualPeriod: 'Billed annually ($35.88/yr · Rs. 9,900) · Save 40% (2 Months Free)',
      wordsPerRun: '3,000 words per run',
      dailyLimit: 'Unlimited daily runs',
      aiGuarantee: 'Strict 0.0% AI & 0% Plagiarism Guaranteed',
      modes: 'All 3 Modes (Simple, Standard, Enhanced)',
      readability: 'All Levels (Normal, High School, University, PhD)',
      purposes: 'All Purposes (Academic, Essay, Business, Legal, Marketing, Story)',
      tones: 'All Tones (Natural, Casual, Conversational)',
      ocr: 'PDF & Document Extraction + Image OCR',
    },
    enterprise: {
      name: 'Institutional & Researcher',
      monthlyPrice: '$14.99',
      annualMonthlyEquiv: '$8.99',
      annualTotal: '$107.88',
      monthlyPkr: 'Rs. 4,200 PKR',
      annualPkr: 'Rs. 29,900 PKR',
      monthlyPeriod: 'Billed monthly · Cancel anytime',
      annualPeriod: 'Billed annually ($107.88/yr · Rs. 29,900) · Save 40%',
      wordsPerRun: '12,000 words per document',
      dailyLimit: 'Unlimited high-speed runs',
      aiGuarantee: 'Strict 0.0% AI & 0% Plagiarism + Forensic Audit Certificate',
      modes: 'All 3 Modes + Custom Style Models',
      readability: 'All Levels + Custom Scholarly Presets',
      purposes: 'All 10+ Scholarly & Corporate Purposes',
      tones: 'All Tones + Enterprise Ghostwriting Tuning',
      ocr: 'Bulk PDF & Batch File Processor (Up to 50 files)',
      extra: '5 Researcher Team Seats & REST API Key Access',
    },
  };

  const handleCopy = (text: string, type: 'number' | 'title' | 'iban') => {
    navigator.clipboard.writeText(text);
    setCopiedField(type);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleStartCheckout = (plan: 'pro' | 'enterprise') => {
    setSelectedPlanForCheckout(plan);
    setCheckoutStep('checkout');
  };

  const handleCompletePayment = async () => {
    setIsProcessing(true);

    try {
      // Record payment receipt in Firestore if user is logged in
      const userId = user?.id || auth.currentUser?.uid || `guest_${Date.now()}`;
      const paymentReceiptId = `pay_${Date.now()}`;
      const amount =
        paymentMethod === 'sadapay'
          ? billingCycle === 'monthly'
            ? selectedPlanForCheckout === 'pro'
              ? pricing.pro.monthlyPkr
              : pricing.enterprise.monthlyPkr
            : selectedPlanForCheckout === 'pro'
            ? pricing.pro.annualPkr
            : pricing.enterprise.annualPkr
          : billingCycle === 'monthly'
          ? selectedPlanForCheckout === 'pro'
            ? pricing.pro.monthlyPrice
            : pricing.enterprise.monthlyPrice
          : selectedPlanForCheckout === 'pro'
          ? pricing.pro.annualTotal
          : pricing.enterprise.annualTotal;

      if (auth.currentUser) {
        const paymentDocRef = doc(db, 'users', auth.currentUser.uid, 'payments', paymentReceiptId);
        await setDoc(paymentDocRef, {
          id: paymentReceiptId,
          userId: auth.currentUser.uid,
          plan: selectedPlanForCheckout,
          billingCycle,
          amount,
          currency: paymentMethod === 'sadapay' ? 'PKR' : 'USD',
          paymentMethod,
          receivingBank: sadapayDetails.bankType,
          receivingAccountTitle: sadapayDetails.accountTitle,
          receivingAccountNumber: sadapayDetails.accountNumber,
          transactionReference: transactionId || `Direct_${paymentMethod}`,
          status: 'completed',
          createdAt: new Date().toISOString(),
        });
      }
    } catch (err) {
      console.warn('Firestore payment record save:', err);
    }

    setTimeout(() => {
      upgradePlan(selectedPlanForCheckout, billingCycle);
      setIsProcessing(false);
      setActivationSuccess(true);
      setTimeout(() => {
        setActivationSuccess(false);
        setCheckoutStep('plans');
        onClose();
      }, 1800);
    }, 1000);
  };

  const getWhatsAppLink = () => {
    const planName = selectedPlanForCheckout === 'pro' ? 'Pro Scholar' : 'Institutional / Enterprise';
    const amount =
      billingCycle === 'monthly'
        ? selectedPlanForCheckout === 'pro'
          ? pricing.pro.monthlyPkr
          : pricing.enterprise.monthlyPkr
        : selectedPlanForCheckout === 'pro'
        ? pricing.pro.annualPkr
        : pricing.enterprise.annualPkr;

    const message = encodeURIComponent(
      `Assalam-o-Alaikum Raheel Niaz!\n\nI have sent payment of *${amount}* for the *${planName}* (${billingCycle}) to your SadaPay Account *03000358949*.\n\n*Transaction ID / TID:* ${
        transactionId || 'Sent Screenshot'
      }\n*Sender Name:* ${senderName || user?.name || 'Customer'}\n*My Email / ID:* ${
        user?.email || 'Customer'
      }\n\nPlease activate my Undetectable AI Humanizer account.`
    );

    return `https://wa.me/${sadapayDetails.whatsappNumber}?text=${message}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl rounded-3xl border border-slate-200 bg-white p-6 sm:p-8 shadow-2xl space-y-6 max-h-[92vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={() => {
            setCheckoutStep('plans');
            onClose();
          }}
          className="absolute top-5 right-5 rounded-full p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-800 transition-colors cursor-pointer"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center space-y-2 max-w-xl mx-auto">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-purple-600 text-white shadow-md shadow-indigo-500/20">
            <Sparkles className="h-6 w-6" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900">
            {checkoutStep === 'checkout'
              ? 'Complete Your Subscription'
              : 'Unlock 100% Undetectable Human Writing'}
          </h2>

          {featureHint ? (
            <div className="inline-block rounded-full bg-amber-50 border border-amber-200 px-4 py-1 text-xs font-bold text-amber-800">
              👑 {featureHint} · Unlocked with Pro
            </div>
          ) : (
            <p className="text-xs text-slate-500">
              Zero Plagiarism and 0.0% AI Detection Guaranteed. Bypasses ZeroGPT, Turnitin, GPTZero & Copyleaks.
            </p>
          )}
        </div>

        {/* Pakistani Exemption & Receiving Account Banner */}
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50/80 p-3.5 text-xs text-emerald-900 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start sm:items-center gap-3">
            <span className="text-2xl shrink-0">🇵🇰</span>
            <div>
              <strong className="block font-bold">Direct SadaPay / Raast Receiving Account Integrated:</strong>
              <span>
                Account Title: <strong className="font-mono text-emerald-950">Raheel Niaz</strong> · SadaPay: <strong className="font-mono text-emerald-950">03000358949</strong>. Free lifetime access for verified Pakistani numbers (+92).
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => handleCopy(sadapayDetails.accountNumber, 'number')}
            className="shrink-0 flex items-center gap-1.5 self-start sm:self-auto rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 font-bold text-[11px] transition-colors cursor-pointer"
          >
            {copiedField === 'number' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
            <span>{copiedField === 'number' ? 'Copied 03000358949' : 'Copy SadaPay'}</span>
          </button>
        </div>

        {checkoutStep === 'plans' ? (
          <>
            {/* Billing Cycle Switcher: Monthly vs Annual (Save 40%) */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-1">
              <div className="inline-flex rounded-xl border border-slate-200 bg-slate-100 p-1">
                <button
                  type="button"
                  onClick={() => setBillingCycle('monthly')}
                  className={`rounded-lg px-5 py-2 text-xs font-bold transition-all cursor-pointer ${
                    billingCycle === 'monthly'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Monthly Billing
                </button>
                <button
                  type="button"
                  onClick={() => setBillingCycle('annually')}
                  className={`flex items-center gap-1.5 rounded-lg px-5 py-2 text-xs font-bold transition-all cursor-pointer ${
                    billingCycle === 'annually'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <span>Annual Billing</span>
                  <span className="rounded-full bg-emerald-600 text-white px-2 py-0.5 text-[10px] font-extrabold uppercase">
                    Save 40%
                  </span>
                </button>
              </div>
            </div>

            {/* 3-Tier Grid with Clear Limitations and Features */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 items-stretch pt-2">
              {/* TIER 1: Free Trial */}
              <div className="rounded-2xl border border-slate-200 bg-white p-5 flex flex-col justify-between space-y-4 hover:border-slate-300 transition-colors">
                <div className="space-y-3">
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                      TRIAL / GUEST
                    </span>
                    <h3 className="text-lg font-extrabold text-slate-900">Standard Preview</h3>
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl font-extrabold text-slate-900 font-mono">$0</span>
                      <span className="text-xs text-slate-500 font-medium">/forever</span>
                    </div>
                    <p className="text-[11px] text-slate-500 font-medium">1 Free Humanization Run</p>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-slate-100 text-xs text-slate-600">
                    <span className="font-bold text-slate-800 block mb-1">Included & Limits:</span>
                    <ul className="space-y-1.5">
                      <li className="flex items-start gap-2">
                        <Check className="h-3.5 w-3.5 text-slate-400 shrink-0 mt-0.5" />
                        <span>Up to 250 words per run</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-3.5 w-3.5 text-slate-400 shrink-0 mt-0.5" />
                        <span>Simple Mode only</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-3.5 w-3.5 text-slate-400 shrink-0 mt-0.5" />
                        <span>Normal Everyday Readability</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-3.5 w-3.5 text-slate-400 shrink-0 mt-0.5" />
                        <span>Natural Standard Tone</span>
                      </li>
                      <li className="flex items-start gap-2 text-slate-400">
                        <X className="h-3.5 w-3.5 shrink-0 mt-0.5 text-rose-400" />
                        <span>No PDF OCR or Audio Transcribe</span>
                      </li>
                      <li className="flex items-start gap-2 text-slate-400">
                        <X className="h-3.5 w-3.5 shrink-0 mt-0.5 text-rose-400" />
                        <span>Advanced Modes Locked</span>
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="pt-2">
                  <span className="w-full block text-center rounded-xl bg-slate-100 py-2.5 text-xs font-bold text-slate-600">
                    {currentPlan === 'free' ? 'Current Free Plan' : 'Free Tier'}
                  </span>
                </div>
              </div>

              {/* TIER 2: Pro Scholar (Most Popular) */}
              <div className="relative rounded-2xl border-2 border-indigo-600 bg-white p-5 flex flex-col justify-between space-y-4 shadow-xl shadow-indigo-500/10 hover:shadow-indigo-500/20 transition-all">
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-indigo-600 to-purple-600 px-3.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-white shadow-md">
                  Most Popular · 0% AI Guarantee
                </div>

                <div className="space-y-3">
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold text-indigo-600 uppercase tracking-wider block">
                      INDIVIDUAL SCHOLAR
                    </span>
                    <h3 className="text-lg font-extrabold text-slate-900">{pricing.pro.name}</h3>
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl font-extrabold text-slate-900 font-mono">
                        {billingCycle === 'monthly' ? pricing.pro.monthlyPrice : pricing.pro.annualMonthlyEquiv}
                      </span>
                      <span className="text-xs text-slate-500 font-medium">/month</span>
                    </div>
                    <div className="text-[11px] text-slate-500 font-medium">
                      {billingCycle === 'annually' ? pricing.pro.annualPeriod : pricing.pro.monthlyPeriod}
                    </div>
                    <div className="text-[11px] text-emerald-700 font-bold bg-emerald-50 rounded-md px-2 py-0.5 mt-1">
                      SadaPay Direct: {billingCycle === 'monthly' ? pricing.pro.monthlyPkr : pricing.pro.annualPkr}
                    </div>
                  </div>

                  <div className="space-y-1.5 pt-2 border-t border-slate-100 text-xs text-slate-700">
                    <span className="font-bold text-slate-900 block mb-1">Full Power Unlocked:</span>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2">
                        <Check className="h-3.5 w-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span><strong>3,000 words</strong> per run (Unlimited daily runs)</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-3.5 w-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span><strong>Strict 0.0% AI & 0% Plagiarism</strong> Guarantee</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-3.5 w-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>All 3 Modes (Simple, Standard & Enhanced)</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-3.5 w-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>High School, University & PhD Readability</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-3.5 w-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>Casual & Conversational Burstiness Tones</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-3.5 w-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>PDF & Image OCR Text Extraction Suite</span>
                      </li>
                    </ul>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleStartCheckout('pro')}
                  className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-purple-600 py-3 text-xs font-bold text-white shadow-md shadow-indigo-500/20 hover:opacity-95 transition-opacity cursor-pointer"
                >
                  <span>
                    {billingCycle === 'monthly'
                      ? `Subscribe Monthly (${pricing.pro.monthlyPrice}/mo)`
                      : `Subscribe Annually (${pricing.pro.annualTotal}/yr · Save 40%)`}
                  </span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>

              {/* TIER 3: Institutional / Team */}
              <div className="rounded-2xl border border-slate-200 bg-white p-5 flex flex-col justify-between space-y-4 hover:border-slate-300 transition-colors">
                <div className="space-y-3">
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold text-purple-600 uppercase tracking-wider block">
                      INSTITUTIONAL / TEAM
                    </span>
                    <h3 className="text-lg font-extrabold text-slate-900">{pricing.enterprise.name}</h3>
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl font-extrabold text-slate-900 font-mono">
                        {billingCycle === 'monthly'
                          ? pricing.enterprise.monthlyPrice
                          : pricing.enterprise.annualMonthlyEquiv}
                      </span>
                      <span className="text-xs text-slate-500 font-medium">/month</span>
                    </div>
                    <div className="text-[11px] text-slate-500 font-medium">
                      {billingCycle === 'annually'
                        ? pricing.enterprise.annualPeriod
                        : pricing.enterprise.monthlyPeriod}
                    </div>
                    <div className="text-[11px] text-purple-700 font-bold bg-purple-50 rounded-md px-2 py-0.5 mt-1">
                      SadaPay Direct: {billingCycle === 'monthly' ? pricing.enterprise.monthlyPkr : pricing.enterprise.annualPkr}
                    </div>
                  </div>

                  <div className="space-y-1 pt-2 border-t border-slate-100 text-xs text-slate-700">
                    <span className="font-bold text-slate-900 block mb-1">Institutional Scale:</span>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2">
                        <Check className="h-3.5 w-3.5 text-purple-600 shrink-0 mt-0.5" />
                        <span><strong>Up to 12,000 words</strong> per document</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-3.5 w-3.5 text-purple-600 shrink-0 mt-0.5" />
                        <span>Bulk PDF & DOCX Batch Processor</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-3.5 w-3.5 text-purple-600 shrink-0 mt-0.5" />
                        <span>5 Team & Student Researcher Seats</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-3.5 w-3.5 text-purple-600 shrink-0 mt-0.5" />
                        <span>Full REST API Key & Webhook Access</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-3.5 w-3.5 text-purple-600 shrink-0 mt-0.5" />
                        <span>Turnitin Certified Forensic Export</span>
                      </li>
                    </ul>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleStartCheckout('enterprise')}
                  className="w-full flex items-center justify-center gap-2 rounded-xl bg-slate-900 hover:bg-slate-800 py-3 text-xs font-bold text-white transition-colors cursor-pointer"
                >
                  <span>
                    {billingCycle === 'monthly'
                      ? `Subscribe Monthly (${pricing.enterprise.monthlyPrice}/mo)`
                      : `Subscribe Annually (${pricing.enterprise.annualTotal}/yr · Save 40%)`}
                  </span>
                </button>
              </div>
            </div>
          </>
        ) : (
          /* Step 2: Checkout & Direct SadaPay Transfer Hub */
          <div className="max-w-xl mx-auto space-y-5 pt-2">
            {/* Selected Plan Summary Bar */}
            <div className="rounded-2xl border border-indigo-200 bg-indigo-50/50 p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-700">
                  Selected Plan
                </span>
                <button
                  type="button"
                  onClick={() => setCheckoutStep('plans')}
                  className="text-xs text-indigo-600 underline font-semibold cursor-pointer"
                >
                  Change Plan
                </button>
              </div>
              <div className="flex items-baseline justify-between">
                <span className="text-base font-extrabold text-slate-900">
                  {selectedPlanForCheckout === 'pro'
                    ? pricing.pro.name
                    : pricing.enterprise.name}
                </span>
                <div className="text-right">
                  <span className="text-lg font-extrabold font-mono text-indigo-600 block">
                    {billingCycle === 'monthly'
                      ? selectedPlanForCheckout === 'pro'
                        ? `${pricing.pro.monthlyPrice} / mo`
                        : `${pricing.enterprise.monthlyPrice} / mo`
                      : selectedPlanForCheckout === 'pro'
                      ? `${pricing.pro.annualTotal} / yr`
                      : `${pricing.enterprise.annualTotal} / yr`}
                  </span>
                  <span className="text-xs font-bold text-emerald-700 font-mono">
                    {billingCycle === 'monthly'
                      ? selectedPlanForCheckout === 'pro'
                        ? pricing.pro.monthlyPkr
                        : pricing.enterprise.monthlyPkr
                      : selectedPlanForCheckout === 'pro'
                      ? pricing.pro.annualPkr
                      : pricing.enterprise.annualPkr}
                  </span>
                </div>
              </div>
              <p className="text-[11px] text-slate-500">
                {billingCycle === 'annually'
                  ? 'Billed annually with 40% discount applied.'
                  : 'Billed monthly. Cancel anytime with 1 click.'}
              </p>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block">
                  Select Payment Method
                </label>
                <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                  ⚡ SadaPay Verified Account Active
                </span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {/* SadaPay Button */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('sadapay')}
                  className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-center gap-1.5 cursor-pointer transition-all ${
                    paymentMethod === 'sadapay'
                      ? 'border-[#FF6584] bg-gradient-to-b from-[#FFF5F7] to-white text-[#E03A62] shadow-sm ring-2 ring-[#FF6584]/30'
                      : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-white'
                  }`}
                >
                  <div className="h-4 w-4 rounded-full bg-[#FF6584] flex items-center justify-center text-[10px] text-white font-extrabold">
                    S
                  </div>
                  <span>SadaPay</span>
                </button>

                {/* Card Button */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-center gap-1.5 cursor-pointer transition-all ${
                    paymentMethod === 'card'
                      ? 'border-indigo-600 bg-indigo-50/50 text-indigo-900 shadow-xs ring-2 ring-indigo-500/20'
                      : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-white'
                  }`}
                >
                  <CreditCard className="h-4 w-4" />
                  <span>Card</span>
                </button>

                {/* PayPal Button */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('paypal')}
                  className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-center gap-1.5 cursor-pointer transition-all ${
                    paymentMethod === 'paypal'
                      ? 'border-indigo-600 bg-indigo-50/50 text-indigo-900 shadow-xs ring-2 ring-indigo-500/20'
                      : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-white'
                  }`}
                >
                  <span className="font-extrabold text-blue-600">P</span>
                  <span>PayPal</span>
                </button>

                {/* Google Pay Button */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('gpay')}
                  className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-center gap-1.5 cursor-pointer transition-all ${
                    paymentMethod === 'gpay'
                      ? 'border-indigo-600 bg-indigo-50/50 text-indigo-900 shadow-xs ring-2 ring-indigo-500/20'
                      : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-white'
                  }`}
                >
                  <span className="font-extrabold text-slate-800">G</span>
                  <span>Google Pay</span>
                </button>
              </div>
            </div>

            {/* SADAPAY RECEIVING ACCOUNT INTEGRATION VIEW */}
            {paymentMethod === 'sadapay' && (
              <div className="space-y-4">
                {/* Visual SadaPay Card Preview */}
                <div className="relative overflow-hidden rounded-2xl bg-gradient-to-tr from-[#1E293B] via-[#0F172A] to-[#334155] p-5 text-white shadow-xl border border-slate-700/60 space-y-4">
                  {/* Card Background Glow */}
                  <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-[#FF6584]/25 blur-2xl pointer-events-none" />
                  <div className="absolute -left-8 -bottom-8 h-32 w-32 rounded-full bg-teal-500/20 blur-2xl pointer-events-none" />

                  <div className="flex items-center justify-between relative z-10">
                    <div className="flex items-center gap-2">
                      <div className="h-7 w-7 rounded-lg bg-[#FF6584] flex items-center justify-center font-black text-sm text-white shadow-md">
                        S
                      </div>
                      <span className="font-extrabold tracking-wider text-sm text-white">SadaPay</span>
                      <span className="text-[10px] bg-white/10 px-2 py-0.5 rounded-full font-mono text-slate-300">
                        Raast Instant
                      </span>
                    </div>
                    <span className="text-[10px] uppercase font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      Receiving Active
                    </span>
                  </div>

                  {/* Account Number & Title */}
                  <div className="space-y-1 relative z-10 pt-1">
                    <span className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold block">
                      Account Number (Mobile Wallet)
                    </span>
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono text-2xl font-black tracking-widest text-white drop-shadow-sm">
                        {sadapayDetails.accountNumber}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleCopy(sadapayDetails.accountNumber, 'number')}
                        className="flex items-center gap-1 rounded-lg bg-white/10 hover:bg-white/20 px-2.5 py-1 text-xs font-bold text-white transition-colors cursor-pointer border border-white/10"
                      >
                        {copiedField === 'number' ? (
                          <>
                            <Check className="h-3.5 w-3.5 text-emerald-400" />
                            <span>Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="h-3.5 w-3.5" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Bottom Row: Account Title & Bank Type */}
                  <div className="flex items-end justify-between pt-2 border-t border-white/10 relative z-10">
                    <div className="space-y-0.5">
                      <span className="text-[9px] uppercase tracking-wider text-slate-400 block font-semibold">
                        Account Title
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-100">
                          {sadapayDetails.accountTitle}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleCopy(sadapayDetails.accountTitle, 'title')}
                          className="text-[10px] text-[#FF6584] hover:underline flex items-center gap-0.5 cursor-pointer font-semibold"
                        >
                          {copiedField === 'title' ? 'Copied' : 'Copy'}
                        </button>
                      </div>
                    </div>

                    <div className="text-right space-y-0.5">
                      <span className="text-[9px] uppercase tracking-wider text-slate-400 block font-semibold">
                        Bank Type
                      </span>
                      <span className="font-bold text-xs text-slate-200">
                        {sadapayDetails.bankType}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Instructions & Amount Info */}
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-3 text-xs text-slate-700">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                    <span className="font-bold text-slate-800">Payable Amount:</span>
                    <span className="font-mono font-extrabold text-sm text-emerald-700">
                      {billingCycle === 'monthly'
                        ? selectedPlanForCheckout === 'pro'
                          ? pricing.pro.monthlyPkr
                          : pricing.enterprise.monthlyPkr
                        : selectedPlanForCheckout === 'pro'
                        ? pricing.pro.annualPkr
                        : pricing.enterprise.annualPkr}
                      {' '}({billingCycle === 'monthly'
                        ? selectedPlanForCheckout === 'pro'
                          ? pricing.pro.monthlyPrice
                          : pricing.enterprise.monthlyPrice
                        : selectedPlanForCheckout === 'pro'
                        ? pricing.pro.annualTotal
                        : pricing.enterprise.annualTotal})
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    Open your <strong>SadaPay, NayaPay, Easypaisa, JazzCash</strong>, or any Pakistani Bank App. Select <strong>Send Money → SadaPay / Raast</strong>, enter Account Number <strong className="font-mono text-slate-900">03000358949</strong>, and verify Title appears as <strong className="text-slate-900">Raheel Niaz</strong>.
                  </p>

                  {/* Transaction ID & Sender Name Form */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-700 block">
                        Transaction ID (TID / Ref #)
                      </label>
                      <input
                        type="text"
                        value={transactionId}
                        onChange={(e) => setTransactionId(e.target.value)}
                        placeholder="e.g. 984572314"
                        className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-mono text-slate-800 focus:border-indigo-500 focus:outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-700 block">
                        Sender Account Name
                      </label>
                      <input
                        type="text"
                        value={senderName}
                        onChange={(e) => setSenderName(e.target.value)}
                        placeholder="e.g. Your Name"
                        className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-800 focus:border-indigo-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Send Proof via WhatsApp Button */}
                  <div className="pt-1">
                    <a
                      href={getWhatsAppLink()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full flex items-center justify-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white py-2.5 text-xs font-bold transition-colors cursor-pointer"
                    >
                      <Send className="h-3.5 w-3.5" />
                      <span>Send Screenshot / Proof to Raheel Niaz on WhatsApp</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                </div>
              </div>
            )}

            {/* Standard Card Inputs */}
            {paymentMethod === 'card' && (
              <div className="space-y-3 p-4 rounded-xl border border-slate-200 bg-slate-50">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block">
                    Card Number
                  </label>
                  <input
                    type="text"
                    defaultValue="•••• •••• •••• 4242"
                    readOnly
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-mono text-slate-800 focus:outline-none"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block">
                      Expires
                    </label>
                    <input
                      type="text"
                      defaultValue="12/28"
                      readOnly
                      className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-mono text-slate-800 focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block">
                      CVC
                    </label>
                    <input
                      type="text"
                      defaultValue="•••"
                      readOnly
                      className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-mono text-slate-800 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* PayPal / Google Pay Notices */}
            {(paymentMethod === 'paypal' || paymentMethod === 'gpay') && (
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 text-xs text-slate-600 text-center space-y-1">
                <p className="font-semibold text-slate-800">
                  {paymentMethod === 'paypal' ? 'PayPal Express Checkout' : 'Google Pay Instant'}
                </p>
                <p className="text-[11px]">
                  Click the button below to authorize the secure transaction.
                </p>
              </div>
            )}

            {/* Complete Payment Button */}
            <button
              type="button"
              onClick={handleCompletePayment}
              disabled={isProcessing}
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-purple-600 py-3.5 text-xs font-bold text-white shadow-lg shadow-indigo-500/25 hover:opacity-95 transition-opacity cursor-pointer disabled:opacity-50"
            >
              {isProcessing ? (
                <>
                  <span className="h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin" />
                  <span>Processing Secure Checkout...</span>
                </>
              ) : activationSuccess ? (
                <>
                  <CheckCircle2 className="h-4 w-4 text-emerald-300" />
                  <span>Subscription Activated Successfully!</span>
                </>
              ) : (
                <>
                  <Lock className="h-3.5 w-3.5" />
                  <span>
                    Confirm Payment & Activate{' '}
                    {selectedPlanForCheckout === 'pro' ? 'Pro Scholar' : 'Institutional'} Plan (
                    {paymentMethod === 'sadapay'
                      ? billingCycle === 'monthly'
                        ? selectedPlanForCheckout === 'pro'
                          ? pricing.pro.monthlyPkr
                          : pricing.enterprise.monthlyPkr
                        : selectedPlanForCheckout === 'pro'
                        ? pricing.pro.annualPkr
                        : pricing.enterprise.annualPkr
                      : billingCycle === 'monthly'
                      ? selectedPlanForCheckout === 'pro'
                        ? pricing.pro.monthlyPrice
                        : pricing.enterprise.monthlyPrice
                      : selectedPlanForCheckout === 'pro'
                      ? pricing.pro.annualTotal
                      : pricing.enterprise.annualTotal}
                    )
                  </span>
                </>
              )}
            </button>
          </div>
        )}

        {/* Security & Guarantee Trust Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500">
          <div className="flex items-center gap-1.5">
            <Lock className="h-3.5 w-3.5 text-slate-400" />
            <span>256-bit SSL encrypted checkout · SadaPay & Raast Direct</span>
          </div>
          <div className="flex items-center gap-1.5 text-emerald-600 font-semibold">
            <ShieldCheck className="h-3.5 w-3.5" />
            <span>100% Money-back guarantee if Turnitin or ZeroGPT flags your text</span>
          </div>
        </div>
      </div>
    </div>
  );
};
