import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { LoginPage } from '../pages/Login';
import { SignupPage } from '../pages/Signup';
import { ForgotPasswordPage } from '../pages/ForgotPassword';
import { VerifyEmailPage } from '../pages/VerifyEmail';
import { BrandLogo } from './BrandLogo';
import {
  User,
  Mail,
  ShieldCheck,
  LogOut,
  Sparkles,
  Crown,
  CheckCircle2,
  AlertCircle,
  Building,
  CreditCard,
  Edit3,
  Copy,
  Check,
  RefreshCw,
  Lock,
} from 'lucide-react';

interface AuthPageProps {
  onSuccessRedirect?: () => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ onSuccessRedirect }) => {
  const {
    user,
    firebaseUser,
    isAuthenticated,
    isEmailVerified,
    signIn,
    signUp,
    signInWithGoogle,
    sendPasswordReset,
    resendEmailVerification,
    refreshAuthState,
    logout,
    updateProfile,
  } = useAuth();

  const [authView, setAuthView] = useState<'login' | 'signup' | 'forgot' | 'verify'>('login');
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // Edit Profile modal state
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editName, setEditName] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [profileMsg, setProfileMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleSignUpSubmit = async (name: string, email: string, pass: string) => {
    await signUp(name, email, pass);
    setAuthView('verify');
  };

  const handleLoginSubmit = async (email: string, pass: string, _remember: boolean) => {
    await signIn(email, pass);
    if (onSuccessRedirect) onSuccessRedirect();
  };

  const handleGoogleSubmit = async () => {
    await signInWithGoogle();
    if (onSuccessRedirect) onSuccessRedirect();
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setIsSavingProfile(true);
    setProfileMsg(null);
    try {
      await updateProfile({
        name: editName.trim() || user.name,
        phone: editPhone.trim(),
      });
      setProfileMsg({ type: 'success', text: 'Profile updated successfully.' });
      setTimeout(() => {
        setIsEditingProfile(false);
        setProfileMsg(null);
      }, 1500);
    } catch (err: any) {
      setProfileMsg({ type: 'error', text: err.message || 'Failed to update profile.' });
    } finally {
      setIsSavingProfile(false);
    }
  };

  // If user is authenticated, render the Account & Security Dashboard
  if (isAuthenticated && user) {
    const isPak = user.countryCode === '+92' || user.isPakistani;
    const isPro = user.hasPaid || user.plan === 'pro';

    return (
      <div className="space-y-6 max-w-5xl mx-auto animate-in fade-in duration-200">
        {/* Email Verification Banner if unverified */}
        {!isEmailVerified && (
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 rounded-2xl border border-amber-300 bg-amber-50/90 p-4 shadow-xs">
            <div className="flex items-center gap-3">
              <AlertCircle className="h-5 w-5 text-amber-600 shrink-0" />
              <div>
                <p className="text-xs font-bold text-amber-900">Your email address is unverified</p>
                <p className="text-[11px] text-amber-700">
                  Please verify <span className="font-semibold">{user.email}</span> to secure your account.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={async () => {
                  await resendEmailVerification();
                  alert('Verification email sent!');
                }}
                className="rounded-xl border border-amber-300 bg-white px-3 py-1.5 text-xs font-bold text-amber-900 hover:bg-amber-100/50 transition-colors cursor-pointer"
              >
                Resend Email
              </button>
              <button
                type="button"
                onClick={async () => {
                  const verified = await refreshAuthState();
                  if (verified) alert('Email confirmed verified!');
                  else alert('Not yet verified. Please click the link in your email first.');
                }}
                className="flex items-center gap-1 rounded-xl bg-amber-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-amber-700 transition-colors cursor-pointer"
              >
                <RefreshCw className="h-3 w-3" />
                Check Status
              </button>
            </div>
          </div>
        )}

        {/* Profile Header Hero */}
        <div className="rounded-3xl border border-slate-200/90 bg-white p-6 sm:p-8 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-indigo-50 border border-indigo-100 text-indigo-700 font-extrabold text-2xl shadow-xs shrink-0">
                {user.name ? user.name.charAt(0).toUpperCase() : 'U'}
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">{user.name}</h1>
                  {isEmailVerified && (
                    <span className="flex items-center gap-1 rounded-md bg-emerald-50 border border-emerald-200 px-2 py-0.5 text-[10px] font-bold text-emerald-700">
                      <ShieldCheck className="h-3 w-3 text-emerald-600" />
                      Verified
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500 font-medium">{user.email}</p>
                <p className="text-[11px] font-mono text-slate-400">UID: {user.uid}</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={() => {
                  setEditName(user.name);
                  setEditPhone(user.phone || '');
                  setIsEditingProfile(true);
                }}
                className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
              >
                <Edit3 className="h-3.5 w-3.5 text-slate-500" />
                Edit Profile
              </button>

              <button
                type="button"
                onClick={logout}
                className="flex items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-2 text-xs font-bold text-rose-700 hover:bg-rose-100 transition-colors cursor-pointer"
              >
                <LogOut className="h-3.5 w-3.5 text-rose-600" />
                Sign Out
              </button>
            </div>
          </div>
        </div>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Subscription & Entitlement Details */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Subscription Tier
              </h3>
              <span
                className={`flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-bold ${
                  isPak
                    ? 'bg-emerald-100 text-emerald-800'
                    : isPro
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-slate-100 text-slate-700'
                }`}
              >
                {isPak ? '🇵🇰 Lifetime Free' : isPro ? '👑 Pro Active' : 'Free Trial'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Role</span>
                <span className="font-bold text-slate-800 uppercase font-mono">{user.role}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Humanized Runs</span>
                <span className="font-bold text-indigo-600">{user.humanizationsUsed || 0} times</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Member Since</span>
                <span className="font-semibold text-slate-700">{new Date(user.createdAt).toLocaleDateString()}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Security Model</span>
                <span className="font-semibold text-emerald-700">Firebase Auth ABAC</span>
              </div>
            </div>
          </div>

          {/* Official Payment Receiving Account Card */}
          <div className="rounded-2xl border border-indigo-200 bg-gradient-to-br from-indigo-50/70 via-white to-slate-50 p-5 space-y-4 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-indigo-100">
              <div className="flex items-center gap-2">
                <Building className="h-4 w-4 text-indigo-600" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-950">
                  Official Receiving Account
                </h3>
              </div>
              <span className="flex items-center gap-1 rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800">
                <CheckCircle2 className="h-3 w-3" /> SadaPay Verified
              </span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              For manual bank transfers, Pro subscription activations, and payment settlements:
            </p>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-white border border-slate-200">
                <div>
                  <span className="text-[10px] font-bold uppercase text-slate-400 block">Account Title</span>
                  <span className="font-bold text-slate-900">Raheel Niaz</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy('Raheel Niaz', 'title')}
                  className="flex items-center gap-1 px-2 py-1 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-semibold transition-colors cursor-pointer"
                >
                  {copiedField === 'title' ? <Check className="h-3 w-3 text-emerald-600" /> : <Copy className="h-3 w-3" />}
                  {copiedField === 'title' ? 'Copied' : 'Copy'}
                </button>
              </div>

              <div className="flex items-center justify-between p-2.5 rounded-xl bg-white border border-slate-200">
                <div>
                  <span className="text-[10px] font-bold uppercase text-slate-400 block">Account Number / IBAN</span>
                  <span className="font-mono font-bold text-indigo-700">03000358949</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy('03000358949', 'number')}
                  className="flex items-center gap-1 px-2 py-1 rounded-md bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-[11px] font-semibold transition-colors cursor-pointer"
                >
                  {copiedField === 'number' ? <Check className="h-3 w-3 text-emerald-600" /> : <Copy className="h-3 w-3 text-indigo-600" />}
                  {copiedField === 'number' ? 'Copied' : 'Copy'}
                </button>
              </div>

              <div className="flex items-center justify-between p-2.5 rounded-xl bg-white border border-slate-200">
                <div>
                  <span className="text-[10px] font-bold uppercase text-slate-400 block">Bank Type</span>
                  <span className="font-semibold text-slate-800">SadaPay (Raast Instant)</span>
                </div>
                <span className="text-[10px] font-bold text-slate-500 font-mono">0% Transfer Fee</span>
              </div>
            </div>
          </div>
        </div>

        {/* Edit Profile Modal */}
        {isEditingProfile && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
            <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
              <h3 className="text-base font-bold text-slate-900">Update Account Information</h3>

              {profileMsg && (
                <div
                  className={`p-3 rounded-xl text-xs font-semibold ${
                    profileMsg.type === 'success'
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-rose-50 text-rose-800 border border-rose-200'
                  }`}
                >
                  {profileMsg.text}
                </div>
              )}

              <form onSubmit={handleSaveProfile} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Display Name</label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-sm text-slate-800 focus:border-indigo-500 focus:bg-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Phone Number</label>
                  <input
                    type="tel"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    placeholder="+92 300 0358949"
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-sm text-slate-800 focus:border-indigo-500 focus:bg-white focus:outline-none"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsEditingProfile(false)}
                    className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSavingProfile}
                    className="rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white hover:bg-indigo-700 disabled:opacity-50 transition-colors cursor-pointer"
                  >
                    {isSavingProfile ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    );
  }

  // If user is unauthenticated, render the modern authentication page
  return (
    <div className="py-6 sm:py-10 animate-in fade-in duration-200">
      {authView === 'login' && (
        <LoginPage
          onLogin={handleLoginSubmit}
          onGoogleLogin={handleGoogleSubmit}
          onSwitchToSignup={() => setAuthView('signup')}
          onSwitchToForgot={() => setAuthView('forgot')}
        />
      )}

      {authView === 'signup' && (
        <SignupPage
          onSignup={handleSignUpSubmit}
          onGoogleLogin={handleGoogleSubmit}
          onSwitchToLogin={() => setAuthView('login')}
        />
      )}

      {authView === 'forgot' && (
        <ForgotPasswordPage
          onSendResetEmail={sendPasswordReset}
          onSwitchToLogin={() => setAuthView('login')}
        />
      )}

      {authView === 'verify' && (
        <VerifyEmailPage
          email={firebaseUser?.email || ''}
          isVerified={isEmailVerified}
          onResend={resendEmailVerification}
          onCheckStatus={refreshAuthState}
          onLogout={logout}
          onProceed={() => {
            if (onSuccessRedirect) onSuccessRedirect();
            else setAuthView('login');
          }}
        />
      )}
    </div>
  );
};
