import React from 'react';
import { Sparkles, ShieldCheck, LayoutGrid, ArrowRight } from 'lucide-react';
import { NavTab } from './Navbar';

interface LearningJourneyHeaderProps {
  onSelectTab: (tab: NavTab) => void;
  onOpenToolsCenter: () => void;
}

export const LearningJourneyHeader: React.FC<LearningJourneyHeaderProps> = ({
  onSelectTab,
  onOpenToolsCenter,
}) => {
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <section className="space-y-4 mb-6">
      {/* Editorial Title & Quick Action */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div className="space-y-1">
          <div className="text-xs font-semibold text-indigo-600 tracking-wide uppercase">
            {getGreeting()} · Workspace Ready
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
            AI Humanization & Forensic Detection Hub
          </h2>
        </div>

        <button
          type="button"
          onClick={onOpenToolsCenter}
          className="self-start sm:self-auto inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 shadow-2xs hover:border-slate-300 hover:text-slate-900 transition-colors cursor-pointer"
        >
          <LayoutGrid className="h-4 w-4 text-indigo-600" />
          <span>All Tools Hub</span>
        </button>
      </div>

      {/* 3 Core Action Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card 1: AI Humanizer */}
        <div
          onClick={() => onSelectTab('pipeline')}
          className="group relative flex flex-col justify-between rounded-2xl border border-slate-200/80 bg-white p-5 hover:border-indigo-500 hover:shadow-md hover:shadow-indigo-500/5 transition-all duration-200 cursor-pointer"
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                <Sparkles className="h-5 w-5" />
              </div>
              <div className="text-right">
                <div className="text-sm font-bold text-emerald-600 tabular-nums">0.0% AI</div>
                <div className="text-[11px] text-slate-400">Target score</div>
              </div>
            </div>

            <div>
              <h3 className="text-base font-semibold text-slate-900 group-hover:text-indigo-600 transition-colors">
                AI Text Humanizer
              </h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Transform robotic syntax into organic human prose that passes ZeroGPT and Turnitin.
              </p>
            </div>
          </div>

          <div className="mt-5 flex items-center justify-between pt-3 border-t border-slate-100 text-xs font-semibold text-indigo-600">
            <span>Start humanizing</span>
            <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Card 2: AI Detector */}
        <div
          onClick={() => onSelectTab('detector')}
          className="group relative flex flex-col justify-between rounded-2xl border border-slate-200/80 bg-white p-5 hover:border-slate-400 hover:shadow-md hover:shadow-slate-500/5 transition-all duration-200 cursor-pointer"
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-800 group-hover:bg-slate-900 group-hover:text-white transition-colors">
                <ShieldCheck className="h-5 w-5" />
              </div>
              <div className="text-right">
                <div className="text-sm font-bold text-slate-700 tabular-nums">Multi-Model</div>
                <div className="text-[11px] text-slate-400">Statistical audit</div>
              </div>
            </div>

            <div>
              <h3 className="text-base font-semibold text-slate-900 group-hover:text-slate-700 transition-colors">
                Forensic AI Detector
              </h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Run deep perplexity and burstiness checks to inspect AI probabilities across paragraphs.
              </p>
            </div>
          </div>

          <div className="mt-5 flex items-center justify-between pt-3 border-t border-slate-100 text-xs font-semibold text-slate-700">
            <span>Scan text</span>
            <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Card 3: Tools Center */}
        <div
          onClick={onOpenToolsCenter}
          className="group relative flex flex-col justify-between rounded-2xl border border-slate-200/80 bg-white p-5 hover:border-purple-500 hover:shadow-md hover:shadow-purple-500/5 transition-all duration-200 cursor-pointer"
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-50 text-purple-600 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                <LayoutGrid className="h-5 w-5" />
              </div>
              <div className="text-right">
                <div className="text-sm font-bold text-purple-700 tabular-nums">8+ Engines</div>
                <div className="text-[11px] text-slate-400">Academic & Work</div>
              </div>
            </div>

            <div>
              <h3 className="text-base font-semibold text-slate-900 group-hover:text-purple-600 transition-colors">
                Productivity Suite
              </h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Access YouTube summarizer, document translator, study notes, and flashcard generators.
              </p>
            </div>
          </div>

          <div className="mt-5 flex items-center justify-between pt-3 border-t border-slate-100 text-xs font-semibold text-purple-600">
            <span>Open suite</span>
            <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>
      </div>
    </section>
  );
};
