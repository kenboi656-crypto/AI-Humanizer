import React from 'react';

interface BrandLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showText?: boolean;
  textClassName?: string;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  size = 'md',
  className = '',
  showText = false,
  textClassName = '',
}) => {
  const sizeMap = {
    xs: { box: 'w-6 h-6', icon: 24, font: 'text-sm' },
    sm: { box: 'w-8 h-8', icon: 32, font: 'text-base' },
    md: { box: 'w-10 h-10', icon: 40, font: 'text-lg' },
    lg: { box: 'w-12 h-12', icon: 48, font: 'text-xl' },
    xl: { box: 'w-16 h-16', icon: 64, font: 'text-2xl' },
  };

  const currentSize = sizeMap[size] || sizeMap.md;

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Precision 3D Vector Emblem */}
      <div
        className={`relative ${currentSize.box} shrink-0 rounded-2xl p-[1.5px] bg-gradient-to-br from-indigo-500 via-purple-600 to-sky-400 shadow-md shadow-indigo-500/20 group hover:shadow-indigo-500/35 transition-all duration-300`}
      >
        <div className="w-full h-full rounded-[14px] bg-slate-950 flex items-center justify-center overflow-hidden relative">
          {/* Subtle ambient glow behind emblem */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-500/30 via-purple-500/10 to-transparent" />

          {/* SVG Brand Mark: Interlocking Human Quill & Neural Matrix Ribbon */}
          <svg
            viewBox="0 0 64 64"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-4/5 h-4/5 relative z-10 drop-shadow-[0_2px_8px_rgba(99,102,241,0.5)]"
          >
            <defs>
              <linearGradient id="primaryGrad" x1="8" y1="8" x2="56" y2="56" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#818CF8" />
                <stop offset="45%" stopColor="#6366F1" />
                <stop offset="100%" stopColor="#A855F7" />
              </linearGradient>
              <linearGradient id="accentGrad" x1="16" y1="48" x2="48" y2="16" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#38BDF8" />
                <stop offset="50%" stopColor="#818CF8" />
                <stop offset="100%" stopColor="#F472B6" />
              </linearGradient>
              <linearGradient id="goldQuillGrad" x1="32" y1="12" x2="32" y2="40" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#FDE047" />
                <stop offset="100%" stopColor="#F59E0B" />
              </linearGradient>
            </defs>

            {/* Organic Flow Ribbon (Left loop - Human touch) */}
            <path
              d="M14 36C14 23.85 23.85 14 36 14C45 14 50 20 48 28C46 36 38 42 30 42C23 42 19 37 20 31C21 25 26 21 32 21C38 21 42 25 41 29"
              stroke="url(#primaryGrad)"
              strokeWidth="4.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Neural Transform Curve (Right upward wave - AI to Human synthesis) */}
            <path
              d="M26 50C34 50 42 46 47 38C52 30 50 20 44 14"
              stroke="url(#accentGrad)"
              strokeWidth="4"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Central Precision Fountain Quill Point */}
            <path
              d="M32 10L36 24L32 30L28 24L32 10Z"
              fill="url(#goldQuillGrad)"
              stroke="#FFF"
              strokeWidth="0.8"
            />
            {/* Center Quill Slit & Breather Hole */}
            <line x1="32" y1="14" x2="32" y2="24" stroke="#78350F" strokeWidth="1" strokeLinecap="round" />
            <circle cx="32" cy="24" r="1.2" fill="#78350F" />

            {/* Spark of authenticity */}
            <circle cx="48" cy="18" r="2" fill="#38BDF8" className="animate-pulse" />
            <circle cx="16" cy="42" r="1.8" fill="#F472B6" />
          </svg>
        </div>
      </div>

      {showText && (
        <div className="flex flex-col min-w-0">
          <div className="flex items-center gap-1.5">
            <span className={`font-extrabold tracking-tight text-slate-900 ${currentSize.font} ${textClassName}`}>
              Raheel
            </span>
            <span className={`font-extrabold bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent ${currentSize.font} ${textClassName}`}>
              Humanize
            </span>
          </div>
          <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-1">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            0.0% AI Verified
          </span>
        </div>
      )}
    </div>
  );
};
