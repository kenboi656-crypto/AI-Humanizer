import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User } from 'firebase/auth';
import {
  signUpWithEmail,
  loginWithEmail,
  loginWithGoogle,
  sendResetEmail,
  sendVerificationEmail,
  logoutUser,
  reloadAuthUser,
  onAuthChange,
} from '../firebase/auth';
import {
  getUserProfile,
  createUserProfile,
  syncGoogleUserProfile,
  updateUserProfile,
  UserProfileData,
} from '../services/userService';

export type UserProfile = UserProfileData;

export interface AuthContextType {
  // State
  user: UserProfile | null;
  firebaseUser: User | null;
  loading: boolean;
  isAuthenticated: boolean;
  isEmailVerified: boolean;
  canHumanize: boolean;
  remainingFreeTries: number;

  // Primary Modular Auth Actions
  signUp: (name: string, email: string, pass: string) => Promise<User>;
  signIn: (email: string, pass: string, remember?: boolean) => Promise<User>;
  signInWithGoogle: () => Promise<User>;
  sendPasswordReset: (email: string) => Promise<void>;
  resendEmailVerification: () => Promise<void>;
  refreshAuthState: () => Promise<boolean>;
  logout: () => Promise<void>;
  updateProfile: (updates: Partial<UserProfile>) => Promise<void>;

  // Backwards-Compatible Helpers
  registerUser: (data: {
    name: string;
    email: string;
    phone?: string;
    countryCode?: string;
    username?: string;
    password?: string;
  }) => Promise<{ requiresOtp: boolean; demoOtp: string }>;
  loginUser: (identifier: string, password?: string) => Promise<boolean>;
  socialLogin: (provider: 'google' | 'facebook') => Promise<void>;
  upgradeToPro: () => void;
  upgradePlan: (plan: 'pro' | 'enterprise', billingCycle: 'monthly' | 'annually') => void;
  recordHumanization: (words: number) => void;
  pendingRegistration: any | null;
}

const STORAGE_CACHE_KEY = 'raheel_auth_user_v2';
const FREE_TRIES_KEY = 'raheel_free_tries_count';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [user, setUser] = useState<UserProfile | null>(() => {
    try {
      const cached = localStorage.getItem(STORAGE_CACHE_KEY);
      if (cached) return JSON.parse(cached);
    } catch (e) {
      console.warn('Failed reading cached user profile:', e);
    }
    return null;
  });

  const [loading, setLoading] = useState<boolean>(true);
  const [freeTries, setFreeTries] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(FREE_TRIES_KEY);
      return saved ? parseInt(saved, 10) : 3;
    } catch {
      return 3;
    }
  });

  // Centralized Firebase Auth Observer
  useEffect(() => {
    const unsubscribe = onAuthChange(async (fbUser) => {
      setFirebaseUser(fbUser);
      if (fbUser) {
        try {
          let profile = await getUserProfile(fbUser.uid);
          if (!profile) {
            // Profile missing: auto-create safely
            profile = await createUserProfile(fbUser);
          } else {
            // Update emailVerified in profile if changed
            if (profile.emailVerified !== fbUser.emailVerified) {
              await updateUserProfile(fbUser.uid, { emailVerified: fbUser.emailVerified });
              profile.emailVerified = fbUser.emailVerified;
            }
          }
          setUser(profile);
          localStorage.setItem(STORAGE_CACHE_KEY, JSON.stringify(profile));
        } catch (err) {
          console.error('Error synchronizing user profile from Firestore:', err);
        }
      } else {
        setUser(null);
        localStorage.removeItem(STORAGE_CACHE_KEY);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Primary Signup
  const signUp = useCallback(async (name: string, email: string, pass: string): Promise<User> => {
    const fbUser = await signUpWithEmail(email, pass, name);
    // Create initial profile in Firestore
    const profile = await createUserProfile(fbUser, { name, email });
    setUser(profile);
    localStorage.setItem(STORAGE_CACHE_KEY, JSON.stringify(profile));
    return fbUser;
  }, []);

  // Primary SignIn
  const signIn = useCallback(async (email: string, pass: string): Promise<User> => {
    const fbUser = await loginWithEmail(email, pass);
    let profile = await getUserProfile(fbUser.uid);
    if (!profile) {
      profile = await createUserProfile(fbUser);
    }
    setUser(profile);
    localStorage.setItem(STORAGE_CACHE_KEY, JSON.stringify(profile));
    return fbUser;
  }, []);

  // Google Sign-In
  const signInWithGoogle = useCallback(async (): Promise<User> => {
    const fbUser = await loginWithGoogle();
    const profile = await syncGoogleUserProfile(fbUser);
    setUser(profile);
    localStorage.setItem(STORAGE_CACHE_KEY, JSON.stringify(profile));
    return fbUser;
  }, []);

  // Password Reset
  const sendPasswordReset = useCallback(async (email: string): Promise<void> => {
    await sendResetEmail(email);
  }, []);

  // Resend Email Verification
  const resendEmailVerification = useCallback(async (): Promise<void> => {
    if (!firebaseUser) throw new Error('No authenticated user session found.');
    await sendVerificationEmail(firebaseUser);
  }, [firebaseUser]);

  // Refresh Verification State
  const refreshAuthState = useCallback(async (): Promise<boolean> => {
    if (!firebaseUser) return false;
    const reloaded = await reloadAuthUser(firebaseUser);
    setFirebaseUser(reloaded);
    if (reloaded.emailVerified && user) {
      const updated = { ...user, emailVerified: true };
      setUser(updated);
      localStorage.setItem(STORAGE_CACHE_KEY, JSON.stringify(updated));
      await updateUserProfile(reloaded.uid, { emailVerified: true });
      return true;
    }
    return reloaded.emailVerified;
  }, [firebaseUser, user]);

  // Logout
  const logout = useCallback(async (): Promise<void> => {
    await logoutUser();
    setUser(null);
    setFirebaseUser(null);
    localStorage.removeItem(STORAGE_CACHE_KEY);
  }, []);

  // Update Profile
  const updateProfile = useCallback(
    async (updates: Partial<UserProfile>): Promise<void> => {
      if (!user) return;
      const updated = { ...user, ...updates };
      setUser(updated);
      localStorage.setItem(STORAGE_CACHE_KEY, JSON.stringify(updated));
      await updateUserProfile(user.uid, updates);
    },
    [user]
  );

  // Backwards compatibility methods
  const registerUser = useCallback(
    async (data: {
      name: string;
      email: string;
      phone?: string;
      countryCode?: string;
      username?: string;
      password?: string;
    }) => {
      if (data.password) {
        await signUp(data.name, data.email, data.password);
      }
      return { requiresOtp: false, demoOtp: '123456' };
    },
    [signUp]
  );

  const loginUser = useCallback(
    async (identifier: string, password?: string) => {
      if (!password) return false;
      await signIn(identifier, password);
      return true;
    },
    [signIn]
  );

  const socialLogin = useCallback(
    async (provider: 'google' | 'facebook') => {
      if (provider === 'google') {
        await signInWithGoogle();
      }
    },
    [signInWithGoogle]
  );

  const upgradeToPro = useCallback(() => {
    if (!user) return;
    const updated: UserProfile = {
      ...user,
      plan: 'pro',
      hasPaid: true,
      billingCycle: 'monthly',
    };
    setUser(updated);
    localStorage.setItem(STORAGE_CACHE_KEY, JSON.stringify(updated));
    updateUserProfile(user.uid, { plan: 'pro', hasPaid: true, billingCycle: 'monthly' }).catch(console.error);
  }, [user]);

  const upgradePlan = useCallback(
    (plan: 'pro' | 'enterprise', billingCycle: 'monthly' | 'annually') => {
      if (!user) return;
      const updated: UserProfile = {
        ...user,
        plan,
        hasPaid: true,
        billingCycle,
      };
      setUser(updated);
      localStorage.setItem(STORAGE_CACHE_KEY, JSON.stringify(updated));
      updateUserProfile(user.uid, { plan, hasPaid: true, billingCycle }).catch(console.error);
    },
    [user]
  );

  const recordHumanization = useCallback(
    (words: number) => {
      if (!user) {
        setFreeTries((prev) => {
          const next = Math.max(0, prev - 1);
          localStorage.setItem(FREE_TRIES_KEY, next.toString());
          return next;
        });
        return;
      }

      const updated: UserProfile = {
        ...user,
        humanizationsUsed: (user.humanizationsUsed || 0) + 1,
        humanizedWordsCount: (user.humanizedWordsCount || 0) + words,
      };
      setUser(updated);
      localStorage.setItem(STORAGE_CACHE_KEY, JSON.stringify(updated));
      updateUserProfile(user.uid, {
        humanizationsUsed: updated.humanizationsUsed,
        humanizedWordsCount: updated.humanizedWordsCount,
      }).catch(console.error);
    },
    [user]
  );

  const isPakistani = user ? user.countryCode === '+92' || user.isPakistani : false;
  const isPaid = user?.hasPaid || user?.plan === 'pro' || user?.plan === 'enterprise';
  const isProOrPakistani = isPakistani || isPaid;
  const canHumanize = isProOrPakistani || freeTries > 0;
  const isEmailVerified = !!(firebaseUser?.emailVerified || user?.emailVerified);

  return (
    <AuthContext.Provider
      value={{
        user,
        firebaseUser,
        loading,
        isAuthenticated: !!firebaseUser || !!user,
        isEmailVerified,
        canHumanize,
        remainingFreeTries: freeTries,
        signUp,
        signIn,
        signInWithGoogle,
        sendPasswordReset,
        resendEmailVerification,
        refreshAuthState,
        logout,
        updateProfile,
        registerUser,
        loginUser,
        socialLogin,
        upgradeToPro,
        upgradePlan,
        recordHumanization,
        pendingRegistration: null,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
