/**
 * Maps technical Firebase Authentication error codes to user-friendly, safe messages.
 * Never exposes internal stack traces or technical secrets.
 */
export function formatAuthError(error: unknown): string {
  if (!error) return 'An unexpected error occurred. Please try again.';

  const err = error as { code?: string; message?: string };
  const code = err.code || '';

  switch (code) {
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found':
      return 'The email or password you entered is incorrect.';

    case 'auth/email-already-in-use':
      return 'An account with this email address already exists. Please log in instead.';

    case 'auth/weak-password':
      return 'Please choose a stronger password with at least 12 characters, uppercase, lowercase, numbers, and symbols.';

    case 'auth/invalid-email':
      return 'Please enter a valid email address.';

    case 'auth/user-disabled':
      return 'This account has been temporarily disabled. Please contact support.';

    case 'auth/too-many-requests':
      return 'Too many unsuccessful attempts. For your security, access is temporarily locked. Please wait a moment and try again.';

    case 'auth/network-request-failed':
      return 'A network error occurred. Please check your internet connection and try again.';

    case 'auth/popup-closed-by-user':
      return 'Sign-in cancelled. The Google popup was closed before completing authentication.';

    case 'auth/popup-blocked':
      return 'The sign-in popup was blocked by your browser. Please allow popups for this site and try again.';

    case 'auth/cancelled-popup-request':
      return 'Another sign-in window is already open. Please complete or close it first.';

    case 'auth/requires-recent-login':
      return 'This sensitive operation requires recent authentication. Please log in again to continue.';

    case 'auth/expired-action-code':
      return 'This verification or password reset link has expired. Please request a new one.';

    case 'auth/invalid-action-code':
      return 'The verification link is invalid or has already been used.';

    case 'auth/operation-not-allowed':
      return 'This sign-in method is currently disabled. Please contact support.';

    default:
      // Return safe message without internal details
      if (err.message && !err.message.includes('Firebase:') && !err.message.includes('auth/')) {
        return err.message;
      }
      return 'Authentication could not be completed. Please try again in a few moments.';
  }
}
