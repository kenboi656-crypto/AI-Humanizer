import React from 'react';
import { EmailVerification } from '../components/auth/EmailVerification';
import { BrandLogo } from '../components/BrandLogo';

interface VerifyEmailPageProps {
  email: string;
  isVerified: boolean;
  onResend: () => Promise<void>;
  onCheckStatus: () => Promise<boolean>;
  onLogout: () => void;
  onProceed?: () => void;
}

export const VerifyEmailPage: React.FC<VerifyEmailPageProps> = ({
  email,
  isVerified,
  onResend,
  onCheckStatus,
  onLogout,
  onProceed,
}) => {
  return (
    <div className="w-full max-w-md mx-auto">
      <div className="rounded-3xl border border-slate-200/90 bg-white p-6 sm:p-8 shadow-xs space-y-6">
        <div className="flex justify-center mb-1">
          <BrandLogo size="md" showText={false} />
        </div>
        <EmailVerification
          email={email}
          isVerified={isVerified}
          onResend={onResend}
          onCheckStatus={onCheckStatus}
          onLogout={onLogout}
          onProceed={onProceed}
        />
      </div>
    </div>
  );
};
