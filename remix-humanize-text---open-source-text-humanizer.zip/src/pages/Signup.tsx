import React from 'react';
import { SignupForm } from '../components/auth/SignupForm';
import { BrandLogo } from '../components/BrandLogo';
import { ShieldCheck, CheckCircle2 } from 'lucide-react';

interface SignupPageProps {
  onSignup: (name: string, email: string, pass: string) => Promise<void>;
  onGoogleLogin: () => Promise<void>;
  onSwitchToLogin: () => void;
}

export const SignupPage: React.FC<SignupPageProps> = ({
  onSignup,
  onGoogleLogin,
  onSwitchToLogin,
}) => {
  return (
    <div className="w-full max-w-md mx-auto">
      <div className="rounded-3xl border border-slate-200/90 bg-white p-6 sm:p-8 shadow-xs space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="flex justify-center mb-1">
            <BrandLogo size="md" showText={false} />
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Create Your Account
          </h2>
          <p className="text-xs text-slate-500 max-w-xs mx-auto">
            Get instant access to authentic human prose rewriting, PDF export, and detector bypass.
          </p>
        </div>

        {/* Feature proofs */}
        <div className="flex items-center justify-center gap-3 text-[11px] font-semibold text-slate-600 bg-slate-50/70 p-2.5 rounded-xl border border-slate-100">
          <span className="flex items-center gap-1 text-emerald-700">
            <CheckCircle2 className="h-3 w-3 text-emerald-600" />
            100% Free Trial
          </span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span className="flex items-center gap-1 text-emerald-700">
            <CheckCircle2 className="h-3 w-3 text-emerald-600" />
            Zero-Trust Cloud Storage
          </span>
        </div>

        {/* Form */}
        <SignupForm
          onSignup={onSignup}
          onGoogleLogin={onGoogleLogin}
          onSwitchToLogin={onSwitchToLogin}
        />
      </div>
    </div>
  );
};
