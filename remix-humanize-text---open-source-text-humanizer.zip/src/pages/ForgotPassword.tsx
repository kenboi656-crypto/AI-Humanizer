import React from 'react';
import { ForgotPasswordForm } from '../components/auth/ForgotPasswordForm';
import { BrandLogo } from '../components/BrandLogo';

interface ForgotPasswordPageProps {
  onSendResetEmail: (email: string) => Promise<void>;
  onSwitchToLogin: () => void;
}

export const ForgotPasswordPage: React.FC<ForgotPasswordPageProps> = ({
  onSendResetEmail,
  onSwitchToLogin,
}) => {
  return (
    <div className="w-full max-w-md mx-auto">
      <div className="rounded-3xl border border-slate-200/90 bg-white p-6 sm:p-8 shadow-xs space-y-6">
        <div className="flex justify-center mb-1">
          <BrandLogo size="md" showText={false} />
        </div>
        <ForgotPasswordForm
          onSendResetEmail={onSendResetEmail}
          onSwitchToLogin={onSwitchToLogin}
        />
      </div>
    </div>
  );
};
