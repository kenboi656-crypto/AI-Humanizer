import React from 'react';
import { LoginForm } from '../components/auth/LoginForm';
import { BrandLogo } from '../components/BrandLogo';
import { ShieldCheck, Sparkles, CheckCircle2 } from 'lucide-react';

interface LoginPageProps {
  onLogin: (email: string, pass: string, remember: boolean) => Promise<void>;
  onGoogleLogin: () => Promise<void>;
  onSwitchToSignup: () => void;
  onSwitchToForgot: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  onLogin,
  onGoogleLogin,
  onSwitchToSignup,
  onSwitchToForgot,
}) => {
  return (
    <div className="w-full max-w-md mx-auto">
      <div className="rounded-3xl border border-slate-200/90 bg-white p-6 sm:p-8 shadow-xs space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="flex justify-center mb-1">
            <BrandLogo size="md" showText={false} />
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Sign In to Your Account
          </h2>
          <p className="text-xs text-slate-500 max-w-xs mx-auto">
            Access Raheel Humanize Text with 0.0% AI detection bypass guarantee and enterprise export.
          </p>
        </div>

        {/* Feature proofs */}
        <div className="flex items-center justify-center gap-3 text-[11px] font-semibold text-slate-600 bg-slate-50/70 p-2.5 rounded-xl border border-slate-100">
          <span className="flex items-center gap-1 text-emerald-700">
            <CheckCircle2 className="h-3 w-3 text-emerald-600" />
            ZeroGPT Cleared
          </span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span className="flex items-center gap-1 text-emerald-700">
            <CheckCircle2 className="h-3 w-3 text-emerald-600" />
            Turnitin Safe
          </span>
        </div>

        {/* Form */}
        <LoginForm
          onLogin={onLogin}
          onGoogleLogin={onGoogleLogin}
          onSwitchToSignup={onSwitchToSignup}
          onSwitchToForgot={onSwitchToForgot}
        />
      </div>
    </div>
  );
};
