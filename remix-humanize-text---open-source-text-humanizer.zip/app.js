// Hostinger Application Entry Point: app.js
import './server.js';
