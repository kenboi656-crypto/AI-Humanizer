// Hostinger Application Entry Point: index.js
import './server.js';
