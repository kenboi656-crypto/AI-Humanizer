// Hostinger Application Entry Point: main.js
import './server.js';
